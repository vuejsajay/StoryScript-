<!DOCTYPE html>
<html lang="en">

<head>
  <!-- META SECTION -->
  <title>Story Script - Signup</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="icon" href="assets/img/funnel-map-icon.png" type="image/x-icon" />
  <!-- END META SECTION -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
	<!-- Custom CSS -->
	<link href="assets/css/signup-css/signup.css" rel="stylesheet" />

</head>

<body>
	<div class="container">
	  <div class="signup-box">
	  	<div class="signup-header">
	  		<img src="assets/img/funnel-map-icon.png">
	  		<span>Welcome To <strong>Story Script</strong></span>
	  	</div>
	  	<div class="signup-body">
	  		<div class="body-title">Create A Free Account </div>
	  		<div class="form-wrapper">
			    <form class="signupForm" id="signupForm" action="admin/welcome-wizard/step1.php" autocomplete="off" method="POST">
						<div class="input-group">
							<span class="input-group-addon"><i class="fa fa-user"></i></span>
							<input type="text" class="form-control" name="fullname" placeholder="Full Name" required>
						</div>
						<div class="input-group">
							<span class="input-group-addon"><i class="fa fa-envelope"></i></span>
							<input  type="email" class="form-control" name="email" placeholder="Email" required>
						</div>
						<button class="btn-submit" type="submit">Sign Up With Email <i class="fa fa-angle-double-right"></i></button>
						<div class="signupOr">
							<div class="col-xs-12" style="padding: 0">
								<hr class="hrOr">
							</div>
						</div>
					</form>
				</div> 
	  		<a href='#' class="btn-fb-signup">
	  			<i class="fa fa-facebook" aria-hidden="true"></i>
	  			<span>Sign Up With Facebook</span>
	  		</a>
	  		<div class="signupOr">
					<div class="col-xs-12" style="padding: 0">
						<hr class="hrOr">
					</div>
				</div>
				<div class='signup-footer'>
					Already A Member? <a href="login-page.php">Click To Login</a>
				</div>
	  	</div>
		</div>
	</div>
	<!-- SCRIPT -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="../../assets/js/signup-js/signup.js"></script>
</body>