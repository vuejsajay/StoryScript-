<div class="modal fade" id="funnelSharingInfoModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
        <h4 class="modal-title"><i class="fa fa-share-alt"></i>FUNNEL SHARING INFO</h4>
      </div>
      <div class="modal-body text-center">
        <div class="funnel-name">
          <img src="../../assets/img/funnel-icons/colored/optin-funnel.png"> [FUNNEL NAME GOES HERE]
        </div>
        <p>Has Been Shared With These <span class="emails-cnt">5</span> Emails Below</p>
        <div class="table-wrapper">
          <table class="table table-striped text-left" id="emails">
            <thead>
              <tr>
                <th>#</th>
                <th>User Name</th>
                <th>Email</th>
                <th>Resend</th>
              </tr>
            </thead>            
            <tbody>
              <?php
                $contacts = [
                  ["userName" => "Sam Smith",
                  "email" => "sam.smith@gmail.com"],
                  ["userName" => "David Joe",
                  "email" => "sam.smith@gmail.com"],
                  ["userName" => "Rachael Smith",
                  "email" => "sam.smith@gmail.com"],
                  ["userName" => "John Doe",
                  "email" => "sam.smith@gmail.com"],
                  ["userName" => "Ella Sam",
                  "email" => "sam.smith@gmail.com"],
                ];

                foreach($contacts as $contact){
              ?>
              <tr>
                <td class="index"></td>
                <td><?php echo $contact['userName'];?></td>
                <td><?php echo $contact['email'];?></td>
                <td class="action-btns"><a href="#" class="action-btn resend-btn" data-toggle="popover" data-placement="auto top" data-content="<strong>Share With A User</strong>" data-html="true" data-trigger="hover" data-container="body"><i class="fa fa-paper-plane"></i></a></td>
              </tr>
              <?php }?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>