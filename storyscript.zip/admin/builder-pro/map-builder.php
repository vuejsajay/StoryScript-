<!DOCTYPE html>
<html lang="en">

<head>
  <!-- META SECTION -->
  <title>Funnel Map - Builder</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="icon" href="../../assets/img/funnel-map-icon.png" type="image/x-icon" />
  <!-- END META SECTION -->
  
  <!-- Bootstrap -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.css" />
  <!-- Font Awesome -->
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
  <!-- iCheck -->
  <link href="../../assets/libs/css/icheck/skins/all.css" rel="stylesheet">
  <!-- mCustomScrollBar -->
  <link href="../../assets/libs/css/mcustomscrollbar/jquery.mCustomScrollbar.css" rel="stylesheet">
  <!-- ColorPicker -->
  <link href="../../assets/libs/css/colorpicker/css/colorpicker.css" rel="stylesheet">
  <!-- Cropper -->
  <link href="../../assets/libs/css/cropper.css" rel="stylesheet">
  <!-- Custom CSS -->
  <link href="../../assets/css/admin-css/builder-css/edit-funnel.css" rel="stylesheet" />
  <link href="../../assets/css/admin-css/builder-pro-css/edit-funnel.css" rel="stylesheet" />
  <link href="../../assets/css/admin-css/builder-css/style.css" rel="stylesheet"/>
  <link href="../../assets/css/admin-css/builder-css/upload-demo.css" rel="stylesheet"/>
  <!-- Custom CSS End -->
</head>
<body>
  <div class="editor-view">
    <div class="header" id="header">
      <div class="dropdown show">
        <a class="btn back-btn" href="../business-record-pro/summary.php" role="button">
          <i class="fa fa-chevron-left"></i>
          <span>Exit</span>
        </a>
      </div>
      <div class="funnel-info">
        <div class="funnel-name">
          <img class="funnel-map-icon" src="../../assets/img/funnel-map-icon.png">
          Funnel Name Here
        </div>
        <div class="business-name"><i class="fa fa-suitcase"></i>Real Strategic Inc.</div>
      </div>
      <div class="header-center" style="visibility: hidden">
        <div id="drpicker" class="dtrange "><i class="fa fa-calendar"></i><span></span><i class="fa fa-caret-down"></i></div>
        <div class="dropdown code-btn-wrapper">
          <button class="code-btn header-btn" data-toggle="dropdown">
            <i class="fa fa-code"></i>
            <span>CODE</span>
            <i class="fa fa-caret-down"></i>
          </button>
          <div class="dropdown-menu">
            <textarea class="tracking-code"><script>
              (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
                m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
                })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
                ga('create', 'UA-xxxxxx-1', 'auto');
                ga('send', 'pageview');
              </script>
            </textarea>
          <button class="copy-btn" data-clipboard-target='.tracking-code' data-name="Code"><i class="fa fa-copy"></i>Copy</button>
          </div>
        </div>
      </div>
      <div class="right-buttons">
        <ul class="nav nav-tabs map-live-toggle">
          <li class="map-btn active" data-toggle="tab">
            <img class="normal-icon" src="../../assets/img/funnel-map-icon-grey.png">
            <img class="active-icon" src="../../assets/img/logo-icon-white.png">
            <span>MAP</span>
          </li>
          <li class="live-btn" data-toggle="tab"><i class="fa fa-area-chart"></i><span>LIVE</span></li>
        </ul>
        <div class="help-video help-video-container no-padding">
          <div class="line header-btn">
            <i class="fa fa-play-circle-o"></i>
            <span>HELP</span>
            <i class="fa fa-caret-down" aria-hidden="true"></i>
          </div>
          <div class="video-wrapper video-container" style="display:none">
            <div class="embed-responsive embed-responsive-16by9">
              <iframe width="495" height="278" class="yvideo stopped" src="https://www.youtube.com/embed/LBqkg-UMIok?autoplay=0" frameborder="0" allowfullscreen></iframe>
            </div>
            <div class="clearfix"></div>
          </div>
        </div>
        <div class="dropdown show save-dropdown">
          <a class="save-btn" role="button" id="saveDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fa fa-check"></i>
            <span>SAVE</span>
            <i class="fa fa-caret-down"></i>
          </a>
          <div class="dropdown-menu" aria-labelledby="saveDropdown">
            <a class="dropdown-item save-map" href="#" data-message="Your Changes Have Been Saved Successfully"><i class="fa fa-check"></i>Save Funnel Map</a>
            <a class="dropdown-item" id="saveTemplateBtn"><i class="fa fa-floppy-o"></i>Save As Template</a>
          </div>
        </div>
      </div>
    </div>
    <div class="analytics-info-wrapper">
      <ul>
        <li class="analytic-item">
          <img src="../../assets/img/analytics-visitors.png">
          <div class="text-wrapper">
            <div class="analytic-num">200</div>
            <div class="analytic-desc">Unique Visitors</div>
          </div>
        </li>
        <li><div class="separator"></div></li>
        <li class="analytic-item">
          <img src="../../assets/img/analytics-clicks.png">
          <div class="text-wrapper">
            <div class="analytic-num">100</div>
            <div class="analytic-desc">Unique Clicks</div>
          </div>
        </li>
        <li><div class="separator"></div></li>
        <li class="analytic-item">
          <img src="../../assets/img/analytics-apps.png">
          <div class="text-wrapper">
            <div class="analytic-num">50</div>
            <div class="analytic-desc">Applications</div>
          </div>
        </li>
        <li><div class="separator"></div></li>
        <li class="analytic-item">
          <img src="../../assets/img/analytics-sales.png">
          <div class="text-wrapper">
            <div class="analytic-num">50</div>
            <div class="analytic-desc">Sales</div>
          </div>
        </li>
        <li class="sep"><div class="separator"></div></li>
        <li class="analytic-item">
          <img src="../../assets/img/analytics-revenue.png">
          <div class="text-wrapper">
            <div class="analytic-num">$50,000</div>
            <div class="analytic-desc">Revenue</div>
          </div>
        </li>
      </ul>
    </div>
    <div class="page-content-wrapper">
      <div class="line">
        <div class="slider">
          <i class="fa fa-angle-up"></i>
        </div>
      </div>
      <div id="sidebar-wrapper" style="left:0px;">
        <div class="page-setting-tab setting-tab">
          <div class="page-setting-title setting-title">
            <span><i class="fa fa-file-text"></i>PAGE SETTINGS</span>
            <a href="#" class="title-buttons close-sidebar-button"><i class="fa fa-times-circle-o"></i></a>
            <a href="#help-modal" class="title-buttons help-button" data-toggle="modal"><i class="fa fa-question-circle"></i></a>
          </div>
          <div class="tab-content setting-tab-content">
            <div class="setting-slide-panel setup-panel">
              <div class="setting-slide-header">
                <i class="fa fa-cog"></i> Setup
                <span class="setting-expand-panel"><i class="fa fa-angle-up"></i></span>
              </div>
              <div class="setting-slide-content active" style="display: block;">
                <span class="field-lbl">
                  Page Name
                  <span class="setting-input-count"><span class="updateCounter">24</span> / 25</span>
                </span>
                <input type="text" class="setting-input counter-input" id="pageName" maxlength="25" placeholder="Ex: Teeth Whitening">
                <span class="field-lbl">Page Description<i class="fa fa-question-circle" data-trigger="hover" data-toggle="popover" data-container="body" data-placement="right" data-html="true" data-content="<span style='color:#333 !important; font-size:13px !important; line-height:8px; font-weight:700 !important;'>Popover Text</span>" data-original-title="" title=""></i></span>
                <input type="text" class="setting-input desc-input" id="pageDescription" placeholder="Ex: Lead Magnet">
                <span class="field-lbl">Page URL</span>
                <input type="text" class="setting-input" id="pageURL" placeholder="Ex: www.mySite.com/page">
                <a href="#" class="create-page-image-btn rounded-btn"><i class="fa fa-picture-o"></i> Create Page Image</a>
              </div>
            </div>
            <div class="setting-slide-panel analytics-tracking-panel">
              <div class="setting-slide-header">
                <i class="fa fa-code"></i> Analytics Tracking
                <span class="setting-expand-panel"><i class="fa fa-angle-down"></i></span>
              </div>
              <div class="setting-slide-content">
                <ul class="nav analytics-tracking-tabs nav-tabs" role="tablist">
                  <li role="presentation" class="active">
                    <a href="#embed-codes-tab" aria-controls="embed-codes-tab" role="tab" data-toggle="tab" aria-expanded="true"> Emb.Codes</a>
                  </li>
                  <li role="presentation" class="">
                    <a href="#params-tab" aria-controls="params-tab" role="tab" data-toggle="tab" aria-expanded="false"> Parameters</a>
                  </li>
                  <li role="presentation" class="">
                    <a href="#goals-tab" aria-controls="goals-tab" role="tab" data-toggle="tab" aria-expanded="false"> Goals</a>
                  </li>
                </ul>
                <div class="tab-content analytics-tracking-content">
                  <div role="tabpanel" class="tab-pane active" id="embed-codes-tab">
                    <span class="field-lbl"><i class="fa fa-code"></i>Embed Code<i class="fa fa-question-circle" data-trigger="hover" data-toggle="popover" data-container="body" data-placement="right" data-html="true" data-content="<span style='color:#333 !important; font-size:13px !important; line-height:8px; font-weight:700 !important;'>Popover Text</span>" data-original-title="" title=""></i></span>
                    <div class="embed-code-div">
                      <textarea class="embed-code-textarea" rows="12" cols="80"><script type="text/javascript">
                      window.onload = function() {
                      window.funnelytics.events.trigger("video", {
                          video: "Upsell Video",
                      }, function() {
                          // continue with process..
                      });
                      };
                      </script></textarea>
                      <button class="copy-btn" data-clipboard-target='.embed-code-textarea' data-name="Code">
                        <i class="fa fa-files-o"></i>COPY
                      </button>
                    </div>
                  </div>
                  <div role=tabpanel" class="tab-pane" id="params-tab">
                    <span class="field-lbl"><i class="fa fa-bars"></i>URL Parameters<i class="fa fa-question-circle" data-trigger="hover" data-toggle="popover" data-container="body" data-placement="right" data-html="true" data-content="<span style='color:#333 !important; font-size:13px !important; line-height:8px; font-weight:700 !important;'>Popover Text</span>" data-original-title="" title=""></i></span>
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th scope="col">Key</th>
                          <th scope="col">Value</th>
                          <th scope="col">URL</th>
                          <th scope="col"><i class="fa fa-cog"></i></th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Paid</td>
                          <td>Yes</td>
                          <td>Contain</td>
                          <td>
                            <div class="dropdown">
                              <i class="fa fa-cog" id="action-edit-btn" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></i>
                              <ul class="dropdown-menu" aria-labelledby="action-edit-btn">
                                <li class='edit-nav-item'><a href="#"><i class="fa fa-edit"></i> Edit</a></li>
                                <li class="delete-nav-item"><a href="#"><i class="fa fa-trash"></i> Delete</a></li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>firstname</td>
                          <td>John</td>
                          <td>Contain</td>
                          <td>
                            <div class="dropdown">
                              <i class="fa fa-cog" id="action-edit-btn" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></i>
                              <ul class="dropdown-menu" aria-labelledby="action-edit-btn">
                                <li><a href="#" class="edit-nav-item"><i class="fa fa-edit"></i> Edit</a></li>
                                <li><a href="#"><i class="fa fa-trash"></i> Delete</a></li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>lastname</td>
                          <td>Smith</td>
                          <td>Doesn't Contain</td>
                          <td>
                            <div class="dropdown">
                              <i class="fa fa-cog" id="action-edit-btn" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></i>
                              <ul class="dropdown-menu" aria-labelledby="action-edit-btn">
                                <li><a href="#"  class="edit-nav-item"><i class="fa fa-edit"></i> Edit</a></li>
                                <li><a href="#" ><i class="fa fa-trash"></i> Delete</a></li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                    <div class="add-dropdown add-param-dropdown">
                      <a href="#" class="create-new-param-btn create-btn rounded-btn"><i class="fa fa-plus"></i> New Parameter <i class="fa fa-caret-down"></i></a>
                      <div class="add-dropdown-content">
                        <div class="row">
                          <div class="col-xs-6">
                            <span class="field-lbl">Key</span>
                            <input type="text" class="setting-input" id='key-input' placeholder="Ex: Paid">
                          </div>
                          <div class="col-xs-6">
                            <span class="field-lbl">Value</span>
                            <input type="text" class="setting-input" id='value-input' placeholder="Ex: YES">
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-xs-12">
                            <span class="field-lbl">URL</span>
                            <select class="setting-input" id='contain-select'>
                              <option>Contain</option>
                              <option>Doesn't Contain</option>
                            </select>
                          </div>
                        </div>
                        <button class="add-btn">
                          <i class="fa fa-check"></i>
                          <span class="btn-txt">ADD</span>
                        </button>
                      </div>
                    </div>
                    <div class="add-dropdown edit-param-dropdown">
                      <div class="add-dropdown-content">
                        <div class="row">
                          <div class="col-xs-6">
                            <span class="field-lbl">Key</span>
                            <input type="text" class="setting-input" id='key-input' placeholder="Ex: Paid">
                          </div>
                          <div class="col-xs-6">
                            <span class="field-lbl">Value</span>
                            <input type="text" class="setting-input" id='value-input' placeholder="Ex: YES">
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-xs-12">
                            <span class="field-lbl">URL</span>
                            <select class="setting-input" id='contain-select'>
                              <option>Contain</option>
                              <option>Doesn't Contain</option>
                            </select>
                          </div>
                        </div>
                        <button class="add-btn">
                          <i class="fa fa-check"></i>
                          <span class="btn-txt">SAVE</span>
                        </button>
                      </div>
                    </div>
                  </div>
                  <div role=tabpanel" class="tab-pane" id="goals-tab">
                    <div class="ps-inline-item">
                      <span><i class="fa fa-crosshairs"></i>This Is A Goal</span>
                      <div class="onoffswitch pull-right">
                        <input type="checkbox" name="onoffswitch" class="onoffswitch-checkbox" id="goalSwitcher" checked="">
                        <label class="onoffswitch-label" for="goalSwitcher">
                          <span class="onoffswitch-inner"></span>
                          <span class="onoffswitch-switch"></span>
                        </label>
                      </div>
                      <i class="fa fa-question-circle pull-right" data-trigger="hover" data-toggle="popover" data-container="body" data-placement="right" data-html="true" data-content="<span style='color:#333 !important; font-size:13px !important; line-height:8px; font-weight:700 !important;'>Popover Text</span>" data-original-title="" title=""></i>
                    </div>
                    <div class="switching-content">
                      <table class="table table-striped">
                        <thead>
                          <tr>
                            <th scope="col">Key</th>
                            <th scope="col">Value</th>
                            <th scope="col">Type</th>
                            <th scope="col"><i class="fa fa-cog"></i></th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>Sales Page</td>
                            <td>$29</td>
                            <td>Lead</td>
                            <td>
                              <div class="dropdown">
                                <i class="fa fa-cog" id="action-edit-btn" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></i>
                                <ul class="dropdown-menu" aria-labelledby="action-edit-btn">
                                  <li><a href="#"  class="edit-nav-item"><i class="fa fa-edit"></i> Edit</a></li>
                                  <li><a href="#" ><i class="fa fa-trash"></i> Delete</a></li>
                                </ul>
                              </div>
                            </td>
                          </tr>
                          <tr>
                            <td>Order</td>
                            <td>$30</td>
                            <td>Sale</td>
                            <td>
                              <div class="dropdown">
                                <i class="fa fa-cog" id="action-edit-btn" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></i>
                                <ul class="dropdown-menu" aria-labelledby="action-edit-btn">
                                  <li><a href="#"  class="edit-nav-item"><i class="fa fa-edit"></i> Edit</a></li>
                                  <li><a href="#" ><i class="fa fa-trash"></i> Delete</a></li>
                                </ul>
                              </div>
                            </td>
                          </tr>
                          <tr>
                            <td>Rep Page</td>
                            <td>$40</td>
                            <td>Application</td>
                            <td>
                              <div class="dropdown">
                                <i class="fa fa-cog" id="action-edit-btn" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></i>
                                <ul class="dropdown-menu" aria-labelledby="action-edit-btn">
                                  <li><a href="#"  class="edit-nav-item"><i class="fa fa-edit"></i> Edit</a></li>
                                  <li><a href="#" ><i class="fa fa-trash"></i> Delete</a></li>
                                </ul>
                              </div>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                      <div class="add-dropdown  add-goal-dropdown">
                        <a href="#" class="create-new-goal-btn create-btn rounded-btn"><i class="fa fa-plus"></i> New Goal <i class="fa fa-caret-down"></i></a>
                        <div class="add-dropdown-content">
                          <div class="row">
                            <div class="col-xs-6">
                              <span class="field-lbl">Name</span>
                              <input type="text" id="name-input" class="setting-input" placeholder="Ex: Sales P">
                            </div>
                            <div class="col-xs-6">
                              <span class="field-lbl">Value</span>
                              <div class="input-group">
                                <span class="input-group-addon">$</span>
                                <input type="text" class="setting-input" id="value-input">
                              </div>
                            </div>
                          </div>
                          <div class="row">
                            <div class="col-xs-12">
                              <span class="field-lbl">Goal Type</span>
                              <select class="setting-input" id="type-select">
                                <option>Lead</option>
                                <option>Sale</option>
                                <option>Application</option>
                              </select>
                            </div>
                          </div>
                          <div class="row">
                            <div class="col-xs-12">
                              <span class="field-lbl">Source</span>
                              <select class="setting-input" id="source-select">
                                <option>Lead</option>
                                <option>Sale</option>
                                <option>Application</option>
                              </select>
                            </div>
                          </div>
                          <button class="add-btn">
                            <i class="fa fa-check"></i>ADD
                          </button>
                        </div>
                      </div>
                      <div class="add-dropdown  edit-goal-dropdown">
                        <div class="add-dropdown-content">
                          <div class="row">
                            <div class="col-xs-6">
                              <span class="field-lbl">Name</span>
                              <input type="text" id="name-input" class="setting-input" placeholder="Ex: Sales P">
                            </div>
                            <div class="col-xs-6">
                              <span class="field-lbl">Value</span>
                              <div class="input-group">
                                <span class="input-group-addon">$</span>
                                <input type="text" class="setting-input" id="value-input">
                              </div>
                            </div>
                          </div>
                          <div class="row">
                            <div class="col-xs-12">
                              <span class="field-lbl">Goal Type</span>
                              <select class="setting-input" id="type-select">
                                <option>Lead</option>
                                <option>Sale</option>
                                <option>Application</option>
                              </select>
                            </div>
                          </div>
                          <div class="row">
                            <div class="col-xs-12">
                              <span class="field-lbl">Source</span>
                              <select class="setting-input" id="edit-source-select">
                                <option>Lead</option>
                                <option>Sale</option>
                                <option>Application</option>
                              </select>
                            </div>
                          </div>
                          <button class="add-btn">
                            <i class="fa fa-check"></i>SAVE
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="setting-slide-panel notes-panel">
              <div class="setting-slide-header">
                <i class="fa fa-file"></i> Notes
                <span class="setting-expand-panel"><i class="fa fa-angle-down"></i></span>
              </div>
              <div class="setting-slide-content">
                <div class="notes-list scrollable">
                  <div class="note-item">
                    <span class="note-date"><i class="fa fa-calendar"></i>12/15/17</span>
                    <span class="note-content"><i class="fa fa-file"></i>Note Goes Here and it can be long more than 1 line.</span>
                  </div>
                  <div class="note-item">
                    <span class="note-date"><i class="fa fa-calendar"></i>12/15/17</span>
                    <span class="note-content"><i class="fa fa-file"></i>Note Goes Here and it can be long more than 1 line.</span>
                  </div>
                  <div class="note-item">
                    <span class="note-date"><i class="fa fa-calendar"></i>12/15/17</span>
                    <span class="note-content"><i class="fa fa-file"></i>Note Goes Here and it can be long more than 1 line.</span>
                  </div>
                  <div class="note-item">
                    <span class="note-date"><i class="fa fa-calendar"></i>12/15/17</span>
                    <span class="note-content"><i class="fa fa-file"></i>Note Goes Here and it can be long more than 1 line.</span>
                  </div>
                </div>
                <div class="add-dropdown">
                  <a href="#" class="create-new-note-btn create-btn rounded-btn"><i class="fa fa-plus"></i> Add New Note <i class="fa fa-caret-down"></i></a>
                  <div class="add-dropdown-content">
                    <div class="row">
                      <div class="col-xs-12">
                        <textarea class="note-textarea" rows="8" cols="80" placeholder="Type In Your Note"></textarea>
                      </div>
                    </div>
                    <button class="add-btn">
                      <i class="fa fa-check"></i>ADD
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div class="setting-slide-panel thumbs-panel">
              <div class="setting-slide-header">
                <i class="fa fa-picture-o"></i> Thumbnails
                <span class="setting-expand-panel"><i class="fa fa-angle-down"></i></span>
              </div>
              <div class="setting-slide-content">
                <div class="thumbs-list scrollable">
                  <img class="thumb-img" src="../../assets/img/page-thumbs/001-Generic.svg">
                  <img class="thumb-img" src="../../assets/img/page-thumbs/002-Download.svg">
                  <img class="thumb-img" src="../../assets/img/page-thumbs/003-OPT-IN.svg">
                  <img class="thumb-img" src="../../assets/img/page-thumbs/004-Order-Page.svg">
                  <img class="thumb-img" src="../../assets/img/page-thumbs/005-Sales-Page.svg">
                  <img class="thumb-img" src="../../assets/img/page-thumbs/006-Sales-Video.svg">
                  <img class="thumb-img" src="../../assets/img/page-thumbs/007-Calendar.svg">
                  <img class="thumb-img" src="../../assets/img/page-thumbs/008-Survey.svg">
                  <img class="thumb-img" src="../../assets/img/page-thumbs/009-Upsell.svg">
                  <img class="thumb-img" src="../../assets/img/page-thumbs/010-Webinar.svg">
                  <img class="thumb-img" src="../../assets/img/page-thumbs/011-Webinar-Replay.svg">
                  <img class="thumb-img" src="../../assets/img/page-thumbs/012-Blog-Post.svg">
                  <img class="thumb-img" src="../../assets/img/page-thumbs/013-Members-Area.svg">
                  <img class="thumb-img" src="../../assets/img/page-thumbs/014-Thank-you.svg">
                  <img class="thumb-img" src="../../assets/img/page-thumbs/015-Popup.svg">
                </div>
                <a href="#" class="custom-thumb-btn rounded-btn"><i class="fa fa-cloud-upload"></i> Custom Thumbnail</a>
                <form id="imgForm" style="display:none;">
                  <input name="imageField" type="file" accept="image/tiff,image/jpeg,image/gif,image/x-png" />
                </form>
              </div>
            </div>
          </div>
        </div>
        <div class="traffic-setting-tab setting-tab">
          <div class="traffic-setting-title setting-title">
            <span><i class="fa fa-users"></i>TRAFFIC SETTINGS</span>
            <a href="#" class="title-buttons close-sidebar-button"><i class="fa fa-times-circle-o"></i></a>
            <a href="#help-modal" class="title-buttons help-button" data-toggle="modal"><i class="fa fa-question-circle"></i></a>
          </div>
          <div class="tab-content setting-tab-content">
            <div class="traffic-setting-slide-panel setting-slide-panel setup-panel">
              <div class="setting-slide-header">
                <i class="fa fa-cog"></i> Setup
                <span class="setting-expand-panel"><i class="fa fa-angle-up"></i></span>
              </div>
              <div class="setting-slide-content active" style="display: block;">
                <span class="field-lbl">
                  Item Name
                  <span class="setting-input-count"><span class="updateCounter">24</span> / 25</span>
                </span>
                <input type="text" class="setting-input counter-input" id="itemName" maxlength="25" placeholder="Email">

                <span class="field-lbl">Item Description</span>
                <input type="text" class="setting-input item-description-input desc-input" id="itemDescription" placeholder="Item Description Here..">

                <span class="field-lbl">Item URL</span>
                <input type="text" class="setting-input" id="itemURL" placeholder="Ex: www.FB.com/AdURL">
                <a href="#" class="create-item-image-btn rounded-btn"><i class="fa fa-picture-o"></i> Create Item Image</a>
              </div>
            </div>
            <div class="setting-slide-panel analytics-tracking-panel">
              <div class="setting-slide-header">
                <i class="fa fa-code"></i> Analytics Tracking
                <span class="setting-expand-panel"><i class="fa fa-angle-down"></i></span>
              </div>
              <div class="setting-slide-content">
                <span class="field-lbl">UTM Marketing Source <i class="fa fa-question-circle" data-trigger="hover" data-toggle="popover" data-container="body" data-placement="right" data-html="true" data-content="<div style='color:#333 !important; font-size:13px !important; line-height:15px !important; font-weight:600 !important;'>The source parameter allows you to track where the
                traffic originated from. The parameter added to your url is <strong>utm_source</strong>. Sources you may track could be
                facebook, google, bing, inbound.org, or the name of an email list.<br><br>
                Example: <strong>&utm_source=twitter</strong></div>" data-original-title="" title="" ></i></span>
                <input type="text" class="setting-input utm-input" id="utm_source" placeholder="eg. google, Social">
                <span class="field-lbl">UTM Medium Type <i class="fa fa-question-circle" data-trigger="hover" data-toggle="popover" data-container="body" data-placement="right" data-html="true" data-content="<div style='color:#333 !important; font-size:13px !important; line-height:15px; font-weight:600 !important;'>The medium parameter tracks what type of traffic the visitor originated from – cpc, email, social, referral, display, etc. The parameter is <strong>utm_medium_</strong><br><br>
                Example: <strong>&utm_medium=ppc</strong></div>" data-original-title="" title=""></i></span>
                <input type="text" class="setting-input utm-input" id="utm_medium" placeholder="eg. PPC, Blog Post">
                <span class="field-lbl">UTM Campaign <i class="fa fa-question-circle" data-trigger="hover" data-toggle="popover" data-container="body" data-placement="right" data-html="true" data-content="<div style='color:#333 !important; font-size:13px !important; line-height:15px; font-weight:600 !important;'>The campaign name parameter allows you to track the performance of a specific campaign. For example, you can use the campaign parameter to differentiate traffic between different Facebook Ad campaigns or email campaigns. (See more on naming conventions below on The parameter is <strong>utm_campaign.</strong><br><br>
                Example: <strong>&utm_campaign=example-campaign</strong></div>" data-original-title="" title=""></i></span>
                <input type="text" class="setting-input utm-input" id="utm_campaign" placeholder="eg. summer_sale">
                <span class="field-lbl">UTM Term <i class="fa fa-question-circle" data-trigger="hover" data-toggle="popover" data-container="body" data-placement="right" data-html="true" data-content="<div style='color:#333 !important; font-size:13px !important; line-height:15px; font-weight:600 !important;'>The keyword parameter allows you to track which keyword term a website visitor came from. This parameter is specifically used for paid search ads. The parameter is <strong>utm_term</strong>.<br><br>Example: <strong>**&utm_term=growth+hacking+tactics</strong></div>" data-original-title="" title="" ></i></span>
                <input type="text" class="setting-input utm-input" id="utm_term" placeholder="Identify the paid keywords">
                <span class="field-lbl">UTM Content <i class="fa fa-question-circle" data-trigger="hover" data-toggle="popover" data-container="body" data-placement="right" data-html="true" data-content="<div style='color:#333 !important; font-size:13px !important; line-height:15px; font-weight:600 !important;'>In case you have multiple links pointing to the same URL (such as an email with two CTA buttons), this code will help you track which link was clicked. The parameter is <strong>utm_content</strong>.<br><br>Example: <strong>&utm_content=navlink</strong>
                </div>" data-original-title="" title=""></i></span>
                <input type="text" class="setting-input utm-input" id="utm_content" placeholder="Use to differentiate ads">
                <span class="field-lbl">UTM URL</span>
                <textarea class="utm-url-textarea"  id="utmURL" rows="5" placeholder="Ex: ?utm_source=newsletter&utm_medium=email&utm_campaign=spring_sale&utm_term=paid&utm_content=newsletter"></textarea>
                <a href="#" class="copy-utm-url-btn rounded-btn copy-btn" data-clipboard-target='.utm-url-textarea' data-name="UTM URL"><i class="fa fa-files-o"></i> Copy UTM URL </a>
              </div>
            </div>
            <div class="traffic-setting-slide-panel setting-slide-panel notes-panel">
              <div class="setting-slide-header">
                <i class="fa fa-file"></i> Notes
                <span class="setting-expand-panel"><i class="fa fa-angle-down"></i></span>
              </div>
              <div class="setting-slide-content">
                <div class="notes-list scrollable">
                  <div class="note-item">
                    <span class="note-date"><i class="fa fa-calendar"></i>12/15/17</span>
                    <span class="note-content"><i class="fa fa-file"></i>Note Goes Here and it can be long more than 1 line.</span>
                  </div>
                  <div class="note-item">
                    <span class="note-date"><i class="fa fa-calendar"></i>12/15/17</span>
                    <span class="note-content"><i class="fa fa-file"></i>Note Goes Here and it can be long more than 1 line.</span>
                  </div>
                  <div class="note-item">
                    <span class="note-date"><i class="fa fa-calendar"></i>12/15/17</span>
                    <span class="note-content"><i class="fa fa-file"></i>Note Goes Here and it can be long more than 1 line.</span>
                  </div>
                  <div class="note-item">
                    <span class="note-date"><i class="fa fa-calendar"></i>12/15/17</span>
                    <span class="note-content"><i class="fa fa-file"></i>Note Goes Here and it can be long more than 1 line.</span>
                  </div>
                </div>
                <div class="add-dropdown">
                  <a href="#" class="create-new-note-btn create-btn rounded-btn"><i class="fa fa-plus"></i> Add New Note <i class="fa fa-caret-down"></i></a>
                  <div class="add-dropdown-content">
                    <div class="row">
                      <div class="col-xs-12">
                        <textarea class="note-textarea" rows="8" cols="80" placeholder="Type In Your Note"></textarea>
                      </div>
                    </div>
                    <button class="add-btn">
                      <i class="fa fa-check"></i>ADD
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div class="traffic-setting-slide-panel setting-slide-panel thumbs-panel">
              <div class="setting-slide-header">
                <i class="fa fa-picture-o"></i> Thumbnails
                <span class="setting-expand-panel"><i class="fa fa-angle-down"></i></span>
              </div>
              <div class="setting-slide-content">
                <div class="thumbs-list scrollable">
                  <img class="thumb-img" src="../../assets/img/traffic-icons/001-Source.png">
                  <img class="thumb-img" src="../../assets/img/traffic-icons/002-Search.png">
                  <img class="thumb-img" src="../../assets/img/traffic-icons/003-Adwards.png">
                  <img class="thumb-img" src="../../assets/img/traffic-icons/004-Banner-Ad.png">
                  <img class="thumb-img" src="../../assets/img/traffic-icons/005-Video-Ad.png">
                  <img class="thumb-img" src="../../assets/img/traffic-icons/006-Email.png">
                  <img class="thumb-img" src="../../assets/img/traffic-icons/007-Gmail.png">
                  <img class="thumb-img" src="../../assets/img/traffic-icons/008-Facebook.png">
                  <img class="thumb-img" src="../../assets/img/traffic-icons/009-Messenger.png">
                  <img class="thumb-img" src="../../assets/img/traffic-icons/010-Instagram.png">
                  <img class="thumb-img" src="../../assets/img/traffic-icons/011-Linkedin.png">
                  <img class="thumb-img" src="../../assets/img/traffic-icons/012-Reddit.png">
                  <img class="thumb-img" src="../../assets/img/traffic-icons/013-Twitter.png">
                  <img class="thumb-img" src="../../assets/img/traffic-icons/014-Report.png">
                  <img class="thumb-img" src="../../assets/img/traffic-icons/015-Affiliate.png">
                  <img class="thumb-img" src="../../assets/img/traffic-icons/016-Chat-Box.png">
                  <img class="thumb-img" src="../../assets/img/traffic-icons/017-Direct-Email.png">
                  <img class="thumb-img" src="../../assets/img/traffic-icons/018-Google-maps.png">
                  <img class="thumb-img" src="../../assets/img/traffic-icons/019-Blog-Post.png">
                  <img class="thumb-img" src="../../assets/img/traffic-icons/020-Online-Meeting.png">
                  <img class="thumb-img" src="../../assets/img/traffic-icons/021-Snapchat.png">
                </div>
                <a href="#" class="custom-thumb-btn rounded-btn"><i class="fa fa-cloud-upload"></i> Custom Thumbnail</a>
                <form id="imgForm2" style="display:none;">
                  <input name="imageField" type="file" accept="image/tiff,image/jpeg,image/gif,image/x-png" />
                </form>
              </div>
            </div>
          </div>
        </div>
        <div class="action-setting-tab setting-tab">
          <div class="action-setting-title setting-title">
            <span><i class="fa fa-bolt"></i>ACTION SETTINGS</span>
            <a href="#" class="title-buttons close-sidebar-button"><i class="fa fa-times-circle-o"></i></a>
            <a href="#help-modal" class="title-buttons help-button" data-toggle="modal"><i class="fa fa-question-circle"></i></a>
          </div>
          <div class="tab-content setting-tab-content">
            <div class="setting-slide-panel setup-panel">
              <div class="setting-slide-header">
                <i class="fa fa-cog"></i> Setup
                <span class="setting-expand-panel"><i class="fa fa-angle-up"></i></span>
              </div>
              <div class="setting-slide-content active" style="display: block;">
                <span class="field-lbl">
                  Action Name
                  <span class="setting-input-count"><span class="updateCounter">24</span> / 25</span>
                </span>
                <input type="text" class="setting-input counter-input" id="actionName" maxlength=25>
                <span class="field-lbl">Action Description<i class="fa fa-question-circle" data-trigger="hover" data-toggle="popover" data-container="body" data-placement="right" data-html="true" data-content="<span style='color:#333 !important; font-size:13px !important; line-height:8px; font-weight:700 !important;'>Popover Text</span>" data-original-title="" title=""></i></span>
                <input type="text" class="setting-input desc-input" id="actionDescription" placeholder="Ex: clicked play">
              </div>
            </div>
            <div class="setting-slide-panel analytics-tracking-panel">
              <div class="setting-slide-header">
                <i class="fa fa-code"></i> Analytics Tracking
                <span class="setting-expand-panel"><i class="fa fa-angle-down"></i></span>
              </div>
              <div class="setting-slide-content">
                <div class="tab-content analytics-tracking-content">
                  <span class="field-lbl"><i class="fa fa-bars"></i>Tracking Elements<i class="fa fa-question-circle" data-trigger="hover" data-toggle="popover" data-container="body" data-placement="right" data-html="true" data-content="<span style='color:#333 !important; font-size:13px !important; line-height:8px; font-weight:700 !important;'>Popover Text</span>" data-original-title="" title=""></i></span>
                  <table class="table table-striped">
                    <thead>
                      <tr>
                        <th scope="col">Key</th>
                        <th scope="col">Value</th>
                        <th scope="col"><i class="fa fa-cog"></i></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>video</td>
                        <td>Upsell Video</td>                   
                        <td>
                          <div class="dropdown">
                            <i class="fa fa-cog" id="action-edit-btn" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></i>
                            <ul class="dropdown-menu" aria-labelledby="action-edit-btn">
                              <li><a href="#"  class="edit-nav-item"><i class="fa fa-edit"></i> Edit</a></li>
                              <li><a href="#" ><i class="fa fa-trash"></i> Delete</a></li>
                            </ul>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td>offer</td>
                        <td>Downsell Video</td>
                        <td>
                          <div class="dropdown">
                            <i class="fa fa-cog" id="action-edit-btn" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></i>
                            <ul class="dropdown-menu" aria-labelledby="action-edit-btn">
                              <li><a href="#"  class="edit-nav-item"><i class="fa fa-edit"></i> Edit</a></li>
                              <li><a href="#" ><i class="fa fa-trash"></i> Delete</a></li>
                            </ul>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <div class="add-dropdown add-element-dropdown">
                    <a href="#" class="create-btn rounded-btn" id="create-new-tracking-elm-btn"><i class="fa fa-plus"></i> New Tracking Element <i class="fa fa-caret-down"></i></a>
                    <div class="add-dropdown-content">
                      <div class="row">
                        <div class="col-xs-6">
                          <span class="field-lbl">Key</span>
                          <input type="text" class="setting-input" id="key-input" placeholder="Ex: Paid">
                        </div>
                        <div class="col-xs-6">
                          <span class="field-lbl">Value</span>
                          <input type="text" class="setting-input" id="value-input"placeholder="Ex: YES">
                        </div>
                      </div>
                      <button class="add-btn">
                        <i class="fa fa-check"></i>ADD
                      </button>
                    </div>
                  </div>
                  <div class="add-dropdown edit-element-dropdown">
                    <div class="add-dropdown-content">
                      <div class="row">
                        <div class="col-xs-6">
                          <span class="field-lbl">Key</span>
                          <input type="text" class="setting-input" id="key-input" placeholder="Ex: Paid">
                        </div>
                        <div class="col-xs-6">
                          <span class="field-lbl">Value</span>
                          <input type="text" class="setting-input" id="value-input"placeholder="Ex: YES">
                        </div>
                      </div>
                      <button class="add-btn">
                        <i class="fa fa-check"></i>SAVE
                      </button>
                    </div>
                  </div>
                  <div class="embed-code-div">
                    <textarea class="embed-code-textarea action-embed-code" rows="12" cols="80">&lt;script type="text/javascript"&gt;
                    window.onload = function() {
                    window.funnelytics.events.trigger('video', {
                        video: 'Upsell Video',
                    }, function() {
                        // continue with process..
                    });
                    };
                    &lt;/script&gt;</textarea>
                    <button class="copy-btn" data-clipboard-target='.action-embed-code' data-name='Code'>
                      <i class="fa fa-files-o" data-clipboard-target=".embed-code-textarea"></i>COPY
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div class="setting-slide-panel notes-panel">
              <div class="setting-slide-header">
                <i class="fa fa-file"></i> Notes
                <span class="setting-expand-panel"><i class="fa fa-angle-down"></i></span>
              </div>
              <div class="setting-slide-content">
                <div class="notes-list scrollable">
                  <div class="note-item">
                    <span class="note-date"><i class="fa fa-calendar"></i>12/15/17</span>
                    <span class="note-content"><i class="fa fa-file"></i>Note Goes Here and it can be long more than 1 line.</span>
                  </div>
                  <div class="note-item">
                    <span class="note-date"><i class="fa fa-calendar"></i>12/15/17</span>
                    <span class="note-content"><i class="fa fa-file"></i>Note Goes Here and it can be long more than 1 line.</span>
                  </div>
                  <div class="note-item">
                    <span class="note-date"><i class="fa fa-calendar"></i>12/15/17</span>
                    <span class="note-content"><i class="fa fa-file"></i>Note Goes Here and it can be long more than 1 line.</span>
                  </div>
                  <div class="note-item">
                    <span class="note-date"><i class="fa fa-calendar"></i>12/15/17</span>
                    <span class="note-content"><i class="fa fa-file"></i>Note Goes Here and it can be long more than 1 line.</span>
                  </div>
                </div>
                <div class="add-dropdown">
                  <a href="#" class="create-new-note-btn create-btn rounded-btn"><i class="fa fa-plus"></i> Add New Note <i class="fa fa-caret-down"></i></a>
                  <div class="add-dropdown-content">
                    <div class="row">
                      <div class="col-xs-12">
                        <textarea class="note-textarea" rows="8" cols="80" placeholder="Type In Your Note"></textarea>
                      </div>
                    </div>
                    <button class="add-btn">
                      <i class="fa fa-check"></i>ADD
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div class="setting-slide-panel thumbs-panel">
              <div class="setting-slide-header">
                <i class="fa fa-picture-o"></i> Thumbnails
                <span class="setting-expand-panel"><i class="fa fa-angle-down"></i></span>
              </div>
              <div class="setting-slide-content">
                <div class="thumbs-list scrollable">
                  <img class="thumb-img" src="../../assets/img/action-icons/001-Generic-event.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/009-Retargeting-Pixel.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/002-Purchase.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/003-Watch-video.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/004-Add-to-cart.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/005-Complete-form.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/006-Scroll.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/007-Click-Button.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/008-Popup.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/001-Replied-To-Email.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/002-Call-Contact.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/003-Dropped-Pixel.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/004-Attended-Webinar.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/005-Watched-Replay.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/006-Clicked-Email-Link.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/007-Clicked-Link.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/008-Opted-In.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/009-Posted-Comment.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/010-Registered.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/011-Scheduled-Call.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/012-Booked-Meeting.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/013-Tagged-Contact.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/014-Add-To-Calendar.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/015-Add-To-Campaign.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/016-Add-To-Autoresponder.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/017-Shared-Content.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/018-Called-In.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/019-Voice-Broadcast.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/020-SMS-Text-Message.png">
                  <img class="thumb-img" src="../../assets/img/action-icons/021-Email-Sequence.png">
                </div>
                <a href="#" class="custom-thumb-btn rounded-btn"><i class="fa fa-cloud-upload"></i> Custom Thumbnail</a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="delete-link-btn" onclick="onClickDeleteLink()">
        <img src="../../assets/img/trash-bin.png" class="btn-icon">
      </div>
      <div class="floating-buttons-container">
        <div class="menu-title">Pages</div>
        <button type="button" class="floating-btn left-menu-page-btn">
          <img src="../../assets/img/left-menu-page.png" alt="" class="btn-icon">
          <img src="../../assets/img/left-menu-page-active.png" alt="" class="active-btn-icon">
          <p>Pages</p>
        </button>
        <div class="side-tab-content page-tab">
          <div class="colred-side-container"></div>
          <div class="content-side">
            <div class="content-side-title">
              <div class="searchWrapper"><input type="search" class="" placeholder="Search" aria-controls="LatestBanners"><i class="fa fa-search searchIcon"></i></div>
              <a class="content-side-header-btn floating-help-btn" href='#help-modal' data-toggle='modal'><i class="fa fa-question"></i></a>
              <span class="content-side-header-btn close-btn"><i class="fa fa-times"></i></span>
            </div>
            <div class="tab-content content-side-tabcontent">
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/page-thumbs/001-Generic.svg" class="nav-item-icon">
                  <p class="nav-item-txt">Generic</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/page-thumbs/002-Download.svg" class="nav-item-icon">
                  <p class="nav-item-txt">Download</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/page-thumbs/003-OPT-IN.svg" class="nav-item-icon">
                  <p class="nav-item-txt">Optin</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/page-thumbs/004-Order-Page.svg" class="nav-item-icon">
                  <p class="nav-item-txt">Order Page</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/page-thumbs/005-Sales-Page.svg" class="nav-item-icon">
                  <p class="nav-item-txt">Sales Page</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/page-thumbs/006-Sales-Video.svg" class="nav-item-icon">
                  <p class="nav-item-txt">Sales Video</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/page-thumbs/007-Calendar.svg" class="nav-item-icon">
                  <p class="nav-item-txt">Calendar</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/page-thumbs/008-Survey.svg" class="nav-item-icon">
                  <p class="nav-item-txt">Survey</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/page-thumbs/009-Upsell.svg" class="nav-item-icon">
                  <p class="nav-item-txt">Upsell</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/page-thumbs/010-Webinar.svg" class="nav-item-icon">
                  <p class="nav-item-txt">Webniar</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/page-thumbs/011-Webinar-Replay.svg" class="nav-item-icon">
                  <p class="nav-item-txt">Webinar Replay</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/page-thumbs/012-Blog-Post.svg" class="nav-item-icon">
                  <p class="nav-item-txt">Blog Post</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/page-thumbs/013-Members-Area.svg" class="nav-item-icon">
                  <p class="nav-item-txt">Members Area</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/page-thumbs/014-Thank-you.svg" class="nav-item-icon">
                  <p class="nav-item-txt">Thank You</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/page-thumbs/015-Popup.svg" class="nav-item-icon">
                  <p class="nav-item-txt">Popup</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="menu-title">Traffic</div>
        <button type="button" class="floating-btn left-menu-traffic-btn">
          <img src="../../assets/img/left-menu-traffic.png" alt="" class="btn-icon">
          <img src="../../assets/img/left-menu-traffic-active.png" alt="" class="active-btn-icon">
          <p>Traffic</p>
        </button>
        <div class="side-tab-content traffic-tab">
          <div class="colred-side-container"></div>
          <div class="content-side">
            <div class="content-side-title">
              <div class="searchWrapper"><input type="search" class="" placeholder="Search" aria-controls="LatestBanners"><i class="fa fa-search searchIcon"></i></div>
              <a class="content-side-header-btn floating-help-btn" href='#help-modal' data-toggle='modal'><i class="fa fa-question"></i></a>
              <span class="content-side-header-btn close-btn"><i class="fa fa-times"></i></span>
            </div>
            <div class="tab-content content-side-tabcontent">
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/traffic-icons/001-Source.png" class="nav-item-icon">
                  <p class="nav-item-txt">Source</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/traffic-icons/002-Search.png" class="nav-item-icon">
                  <p class="nav-item-txt">Search</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/traffic-icons/003-Adwards.png" class="nav-item-icon">
                  <p class="nav-item-txt">Adwards</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/traffic-icons/004-Banner-Ad.png" class="nav-item-icon">
                  <p class="nav-item-txt">Banner Ad</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/traffic-icons/005-Video-Ad.png" class="nav-item-icon">
                  <p class="nav-item-txt">Video Ad</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/traffic-icons/006-Email.png" class="nav-item-icon">
                  <p class="nav-item-txt">Email</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/traffic-icons/007-Gmail.png" class="nav-item-icon">
                  <p class="nav-item-txt">Gmail</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/traffic-icons/008-Facebook.png" class="nav-item-icon">
                  <p class="nav-item-txt">Facebook</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/traffic-icons/009-Messenger.png" class="nav-item-icon">
                  <p class="nav-item-txt">Messenger</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/traffic-icons/010-Instagram.png" class="nav-item-icon">
                  <p class="nav-item-txt">Instagram</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/traffic-icons/011-Linkedin.png" class="nav-item-icon">
                  <p class="nav-item-txt">Linkedin</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/traffic-icons/012-Reddit.png" class="nav-item-icon">
                  <p class="nav-item-txt">Reddit</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/traffic-icons/013-Twitter.png" class="nav-item-icon">
                  <p class="nav-item-txt">Twitter</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/traffic-icons/014-Report.png" class="nav-item-icon">
                  <p class="nav-item-txt">Report</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/traffic-icons/015-Affiliate.png" class="nav-item-icon">
                  <p class="nav-item-txt">Affiliate</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/traffic-icons/015-Affiliate.png" class="nav-item-icon">
                  <p class="nav-item-txt">Affiliate</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/traffic-icons/016-Chat-Box.png" class="nav-item-icon">
                  <p class="nav-item-txt">Chat Box</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/traffic-icons/017-Direct-Email.png" class="nav-item-icon">
                  <p class="nav-item-txt">Direct Email</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/traffic-icons/018-Google-maps.png" class="nav-item-icon">
                  <p class="nav-item-txt">Google Maps</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/traffic-icons/019-Blog-Post.png" class="nav-item-icon">
                  <p class="nav-item-txt">Blog Post</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/traffic-icons/020-Online-Meeting.png" class="nav-item-icon">
                  <p class="nav-item-txt">Online Meeting</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/traffic-icons/021-Snapchat.png" class="nav-item-icon">
                  <p class="nav-item-txt">Snapchat</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="menu-title">Actions</div>
        <button type="button" class="floating-btn left-menu-action-btn">
          <img src="../../assets/img/left-menu-action.png" alt="" class="btn-icon">
          <img src="../../assets/img/left-menu-action-active.png" alt="" class="active-btn-icon">
          <p>Actions</p>
        </button>
        <div class="side-tab-content action-tab">
          <div class="colred-side-container">
          </div>

          <div class="content-side">
            <div class="content-side-title">
              <div class="searchWrapper"><input type="search" class="" placeholder="Search" aria-controls="LatestBanners"><i class="fa fa-search searchIcon"></i></div>
              <a class="content-side-header-btn floating-help-btn" href='#help-modal' data-toggle='modal'><i class="fa fa-question"></i></a>
              <span class="content-side-header-btn close-btn"><i class="fa fa-times"></i></span>
            </div>
            <div class="tab-content content-side-tabcontent">
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/text-element.png" class="nav-item-icon">
                  <p class="nav-item-txt">Add Text Box</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/001-Generic-event.png" class="nav-item-icon">
                  <p class="nav-item-txt">Generic Event</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/009-Retargeting-Pixel.png" class="nav-item-icon">
                  <p class="nav-item-txt">Retargeting Pixel</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/002-Purchase.png" class="nav-item-icon">
                  <p class="nav-item-txt">Purchased</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/003-Watch-video.png" class="nav-item-icon">
                  <p class="nav-item-txt">Watched Video</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/004-Add-to-cart.png" class="nav-item-icon">
                  <p class="nav-item-txt">Added To Cart</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/005-Complete-form.png" class="nav-item-icon">
                  <p class="nav-item-txt">Completed Form</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/006-Scroll.png" class="nav-item-icon">
                  <p class="nav-item-txt">Scrolled</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/007-Click-Button.png" class="nav-item-icon">
                  <p class="nav-item-txt">Clicked Button</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/008-Popup.png" class="nav-item-icon">
                  <p class="nav-item-txt">Viewed Popup</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/001-Replied-To-Email.png" class="nav-item-icon">
                  <p class="nav-item-txt">Replied To Email</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/002-Call-Contact.png" class="nav-item-icon">
                  <p class="nav-item-txt">Call Contact</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/003-Dropped-Pixel.png" class="nav-item-icon">
                  <p class="nav-item-txt">Dropped Pixel</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/004-Attended-Webinar.png" class="nav-item-icon">
                  <p class="nav-item-txt">Attended Webinar</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/005-Watched-Replay.png" class="nav-item-icon">
                  <p class="nav-item-txt">Watched Replay</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/006-Clicked-Email-Link.png" class="nav-item-icon">
                  <p class="nav-item-txt">Clicked Email Link</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/007-Clicked-Link.png" class="nav-item-icon">
                  <p class="nav-item-txt">Clicked Link</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/008-Opted-In.png" class="nav-item-icon">
                  <p class="nav-item-txt">Opted In</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/009-Posted-Comment.png" class="nav-item-icon">
                  <p class="nav-item-txt">Posted Comment</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/010-Registered.png" class="nav-item-icon">
                  <p class="nav-item-txt">Registered</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/011-Scheduled-Call.png" class="nav-item-icon">
                  <p class="nav-item-txt">Scheduled Call</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/012-Booked-Meeting.png" class="nav-item-icon">
                  <p class="nav-item-txt">Booked Meeting</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/013-Tagged-Contact.png" class="nav-item-icon">
                  <p class="nav-item-txt">Tagged Contact</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/014-Add-To-Calendar.png" class="nav-item-icon">
                  <p class="nav-item-txt">Add To Calendar</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/015-Add-To-Campaign.png" class="nav-item-icon">
                  <p class="nav-item-txt">Add To Campaign</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/016-Add-To-Autoresponder.png" class="nav-item-icon">
                  <p class="nav-item-txt">Add To Autoresponder</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/017-Shared-Content.png" class="nav-item-icon">
                  <p class="nav-item-txt">Shared Content</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/018-Called-In.png" class="nav-item-icon">
                  <p class="nav-item-txt">Called In</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/019-Voice-Broadcast.png" class="nav-item-icon">
                  <p class="nav-item-txt">Sent Voice Broadcost</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/020-SMS-Text-Message.png" class="nav-item-icon">
                  <p class="nav-item-txt">Sent SMS Text</p>
                </div>
              </div>
              <div class="nav-item">
                <div class="nav-item-container">
                  <img src="../../assets/img/action-icons/021-Email-Sequence.png" class="nav-item-icon">
                  <p class="nav-item-txt">Email Sequence</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="menu-title">Templates</div>
        <button type="button" class="floating-btn left-menu-funnel-btn">
          <img src="../../assets/img/left-menu-funnel.png" alt="" class="btn-icon">
          <img src="../../assets/img/left-menu-funnel-active.png" alt="" class="active-btn-icon">
          <p>Funnels</p>
        </button>
        <div class="side-tab-content funnel-tab">
          <div class="colred-side-container">
          </div>
          <div class="content-side">
            <div class="content-side-title">
              <div class="searchWrapper"><input type="search" class="" placeholder="Search" aria-controls="LatestBanners"><i class="fa fa-search searchIcon"></i></div>
              <a class="content-side-header-btn floating-help-btn" href='#help-modal' data-toggle='modal'><i class="fa fa-question"></i></a>
              <span class="content-side-header-btn close-btn"><i class="fa fa-times"></i></span>
            </div>
            <div class="tab-content content-side-tabcontent">
              <div class="nav-item" data-trigger="hover" data-toggle="popover" data-container="body" data-placement="auto right" data-html="true" data-content="<img src='../../assets/img/sampleTemplate.png' style='width: 340px'>">
                <div class="nav-item-container">
                  <img src="../../assets/img/funnel-template.png" class="nav-item-icon">
                  <p class="nav-item-txt">Sample Template</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="action-buttons">
        <div class="btn zoom-in-btn" onclick="onClickZoomIn()" data-trigger="hover" data-toggle="popover" data-container="body" data-placement="right" data-html="true" data-content="<span style='color:#333 !important; font-size:13px !important; line-height:8px; font-weight:700 !important;'>Zoom In 20%</span>">
          <img src="../../assets/img/zoom-in.png" class="btn-icon">
          <img src="../../assets/img/zoom-in-hover.png" class="btn-icon-hover">
        </div>
        <div class="btn zoom-out-btn" onclick="onClickZoomOut()" data-trigger="hover" data-toggle="popover" data-container="body" data-placement="right" data-html="true" data-content="<span style='color:#333 !important; font-size:13px !important; line-height:8px; font-weight:700 !important;'>Zoom Out 20%</span>">
          <img src="../../assets/img/zoom-out.png" class="btn-icon">
          <img src="../../assets/img/zoom-out-hover.png" class="btn-icon-hover">
        </div>
        <div class="btn multiselect-btn" onclick="onToggleMultiSelection()" data-trigger="hover" data-toggle="popover" data-container="body" data-placement="right" data-html="true" data-content="<span style='color:#333 !important; font-size:13px !important; line-height:8px; font-weight:700 !important;'>Select Elements</span>">
          <img src="../../assets/img/select-elements.png" class="btn-icon">
          <img src="../../assets/img/select-elements-active.png" class="btn-icon-active">
        </div>
      </div>
      <div id="edit-div"></div>
      <div class="">
      </div>
      <div class="dropdown-menu setting-menu page-setting-menu">
        <div class="dropdown-item" onclick="onClickEditPage()" data-trigger="hover" data-toggle="popover" data-container="body" data-placement="bottom" data-html="true" data-content="<span style='color:#333 !important; font-size:13px !important; line-height:8px; font-weight:700 !important;'>Setting</span>">
          <img src="../../assets/img/gear-blue.png">
        </div>
        <div class="dropdown-item" onclick="onClickPreviewPage()" data-trigger="hover" data-toggle="popover" data-container="body" data-placement="bottom" data-html="true" data-content="<span style='color:#333 !important; font-size:13px !important; line-height:8px; font-weight:700 !important;'>Preview</span>">
          <img src="../../assets/img/eye-blue.png">
        </div>
        <div class="dropdown-item" onclick="onClickDeletePage()" data-trigger="hover" data-toggle="popover" data-container="body" data-placement="bottom" data-html="true" data-content="<span style='color:#333 !important; font-size:13px !important; line-height:8px; font-weight:700 !important;'>Delete</span>">
          <img src="../../assets/img/trash-bin-blue.png">
        </div>
      </div>
      <div class="dropdown-menu setting-menu action-setting-menu">
        <div class="dropdown-item" onclick="onClickEditPage()" data-trigger="hover" data-toggle="popover" data-container="body" data-placement="bottom" data-html="true" data-content="<span style='color:#333 !important; font-size:13px !important; line-height:8px; font-weight:700 !important;'>Setting</span>">
          <img src="../../assets/img/gear-orange.png">
        </div>       
        <div class="dropdown-item" onclick="onClickDeletePage()" data-trigger="hover" data-toggle="popover" data-container="body" data-placement="bottom" data-html="true" data-content="<span style='color:#333 !important; font-size:13px !important; line-height:8px; font-weight:700 !important;'>Delete</span>">
          <img src="../../assets/img/trash-bin-orange.png">
        </div>
      </div>
      <div class="dropdown-menu setting-menu traffic-setting-menu">
        <div class="dropdown-item" onclick="onClickEditPage()" data-trigger="hover" data-toggle="popover" data-container="body" data-placement="bottom" data-html="true" data-content="<span style='color:#333 !important; font-size:13px !important; line-height:8px; font-weight:700 !important;'>Setting</span>">
          <img src="../../assets/img/gear-teal.png">
        </div>       
        <div class="dropdown-item" onclick="onClickDeletePage()" data-trigger="hover" data-toggle="popover" data-container="body" data-placement="bottom" data-html="true" data-content="<span style='color:#333 !important; font-size:13px !important; line-height:8px; font-weight:700 !important;'>Delete</span>">
          <img src="../../assets/img/trash-bin-teal.png">
        </div>
      </div>
      <div class="dropdown-menu setting-menu text-setting-menu">
        <div class="dropdown-item" id="colorSelector">
          <img src="../../assets/img/brush.png">
        </div>
        <select class="dropdown-item font-size-select" onchange="onChangeFontSize()">
          <option>8</option>
          <option>9</option>
          <option>10</option>
          <option>11</option>
          <option>12</option>
          <option selected>14</option>
          <option>16</option>
          <option>18</option>
          <option>20</option>
          <option>22</option>
          <option>24</option>
          <option>26</option>
          <option>28</option>
          <option>36</option>
          <option>48</option>
          <option>60</option>
        </select>
        <div class="dropdown-item" onclick="onClickDeletePage()">
          <img src="../../assets/img/trash-bin-grey.png">
        </div>
      </div>
    </div>
  </div>

  <!-- DELETE LINK MODAL START-->
  <div id="deleteLinkModal" class="warning-dialog modal fade" role="dialog">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        </div>
        <div class="modal-body">
          <div class="modal-title">
              <img src="../../assets/img/warning.png">WARNING!
          </div>
          <div>
              <p> Are You Sure You Want To Delete This Connection Between <span class="page-name1">[Page Name]</span> & <span class="page-name2">[Page Name]</span>?</p>
          </div>
          <button class="confirm-btn" data-dismiss="modal" onclick="onDeleteLink()">
              <img src="../../assets/img/delete.svg"> 
              <span>YES! DELETE THIS CONNECTION</span>
          </button>
        </div>
      </div>
    </div>
  </div>
  <!-- DELETE LINK MODAL END-->
  <!-- DELETE CARD MODAL START-->
  <div id="deleteCardModal" class="warning-dialog modal fade" role="dialog">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        </div>
        <div class="modal-body">
          <div class="modal-title">
              <img src="../../assets/img/warning.png">WARNING!
          </div>
          <div >
              <p> Are You Sure You Want To Completely Remove <span class='page-name'>[ Page Name ]</span> From Your Funnel?</p>
          </div>
          <button class="confirm-btn" data-dismiss="modal" onclick="onDeleteCard()">
              <img src="../../assets/img/delete.svg">
              <span>YES! DELETE THIS&nbsp</span><span class='card-type'> PAGE</span>
          </button>
        </div>
      </div>
    </div>
  </div>
  <!-- DELETE CARD MODAL END-->
  <!-- Delete Selection Modal -->
  <div id="deleteSelectionkModal" class="warning-dialog modal fade" role="dialog">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="onCancelDeleteSelection()"><span aria-hidden="true">&times;</span></button>
        </div>
        <div class="modal-body">
          <div class="modal-title">
              <img src="../../assets/img/warning.png">WARNING!
          </div>
          <div>
              <p> Are You Sure You Want To Delete These Selected Elements?</p>
          </div>
          <button class="confirm-btn" data-dismiss="modal" onclick="onDeleteSelection()">
              <img src="../../assets/img/delete.svg"> 
              <span>YES! DELETE THESE ELEMENTS</span>
          </button>
        </div>
      </div>
    </div>
  </div>
  <!-- Delete Selection Modal End -->
  <!-- Help Video Modal -->
  <div class="modal fade" id="help-modal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-body">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
          <div class="col-xs-12 no-padding">
            <div class="embed-responsive embed-responsive-16by9">
              <iframe class="yvideo-form" src="https://player.vimeo.com/video/49614043?title=0&byline=0&portrait=0" frameborder="0" allowfullscreen=""></iframe>
            </div>
          </div>
          <div class="clearfix"></div>
        </div>
      </div>
    </div>
  </div>
  <!-- Help Video Modal End-->
  <!--SAVE TEMPLATE Modal-->
  <div class="modal fade" id="save-template-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
          <h4 class="modal-title"><i class="fa fa-plus"></i>Save As Template</h4>
        </div>
        <div class="modal-body">
          <div class="col-md-12 no-padding-left right-bordered">
            <div class="row">
              <div class="form-group">
                <label class="col-xs-3 no-padding control-label text-right label-style">Template Name</label>
                <div class="col-xs-9 padding-right-41">
                  <div class="inner-addon right-addon">
                    <div class="formField">
                      <input class="form-control counter-input" placeholder="Type In Your Template Name" maxlength="40" />
                      <span class="pageNameCount"><span class="updateCounter">0</span> / 40</span>
                    </div>
                    <div class="validation col-xs-9 col-xs-offset-3" style="display:none;">
                      <p class="not-validation"> Enter Template Name</p>
                    </div>
                  </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-xs-10 col-md-offset-2"><button class="btn btn-success btn-close"><i class="fa fa-check"></i>SAVE</button></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--End SAVE TEMPLATE Modal-->
  <!--CROP MODAL-->
  <div id="cropper-popup" class="modal fade" tabindex="-1" role="dialog">
   <div class="modal-dialog main-popup">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
        </button>
        <h4 class="modal-title"><i class="fa fa-crop"></i> Crop Image</h4>
      </div>
      <div class="modal-body popup-body text-center">
        <div class="crop-container">
          <img src="http://placehold.it/280x40" class="croppImgLogo" alt="Cropper" />
        </div>
        <div class="crop-actions ratio-action" data-toggle="buttons">
          <ul class="aspect6-7" style="display:none">
            <li class="ratioLi ratio6x7" style="border-right: 0px;">
              <span>6x7 :</span>
              <a class="aspect-btn ratio-square3 active" data-method="setAspectRatio" data-option="0.8571" value="0.8571" title="Set Aspect Ratio"></a>
            </li>
          </ul>
          <ul class="aspect1-1">
            <li class="ratioLi ratio1x1">
              <span>1x1 :</span>
              <a class="aspect-btn ratio-square active" data-method="setAspectRatio" data-option="1" value="1" title="Set Aspect Ratio"></a>
            </li>
          </ul>
          <div class="btn-group">
            <button type="button" class="btn btn-primary m-left" data-method="zoom" data-option="-0.1" title="Zoom Out"> <span class="fa fa-search-minus"></span>
            </button>
            <button type="button" class="btn btn-primary" data-method="zoom" data-option="0.1" title="Zoom In"> <span class="fa fa-search-plus"></span>
            </button>
          </div>
        </div>
      </div>
      <div class="modal-footer crop-actions">
        <button type="button" class="btn rk-gray-btn pull-left" data-dismiss="modal">Cancel</button>
        <button id="cropper-save" type="button" class="btn rk-green-btn" data-method="getCroppedCanvas">Save</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- CROP MODAL END -->
  <!-- SCRIPT -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
  <script type="text/javascript" src="../../assets/libs/js/jquery-ui.min.js"></script>
  <script src="https://www.google.com/recaptcha/api.js" async defer></script>
  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <script src="../../assets/libs/js/gojs/go.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.js"></script>
  <script src="../../assets/libs/js/clipboard.min.js"></script>
  <script type="text/javascript" src="../../assets/libs/js/noty/jquery.noty.js"></script>
  <script type="text/javascript" src="../../assets/libs/js/noty/layouts/top.js"></script>
  <script type="text/javascript" src="../../assets/libs/js/noty/layouts/topCenter.js"></script>
  <script type="text/javascript" src="../../assets/libs/js/noty/themes/default.js"></script>
  <!-- custom scrolling js -->
  <script type="text/javascript" src="../../assets/libs/js/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>
  <!-- ICHECK -->
  <script src="../../assets/libs/js/icheck.min.js"></script>
  <!-- ColorPicker -->
  <script src="../../assets/libs/js/colorpicker/colorpicker.js"></script>
  <!-- Cropper -->
  <script src="../../assets/libs/js/cropper.js"></script>
  <script type="text/javascript" src="../../assets/libs/js/moment.min.js"></script> 
  <script type="text/javascript" src="../../assets/libs/js/daterangepicker/daterangepicker.js"></script> 
  <!-- custom js files -->
  <script src="../../assets/js/admin-js/builder-js/dashboard-base.js"></script>
  <script src="../../assets/js/admin-js/builder-pro-js/card-templates/rounded-bottom-rectangle.js"></script>
  <script src="../../assets/js/admin-js/builder-pro-js/card-templates/page-card.js"></script>
  <script src="../../assets/js/admin-js/builder-pro-js/card-templates/traffic-card.js"></script>
  <script src="../../assets/js/admin-js/builder-pro-js/card-templates/action-card.js"></script>
  <script src="../../assets/js/admin-js/builder-js/card-templates/text-card.js"></script>
  <script src="../../assets/js/admin-js/builder-js/DrawCommandHandler.js"></script>
  <script src="../../assets/js/admin-js/builder-pro-js/builder.js"></script>
  <script src="../../assets/js/admin-js/builder-js/upload-demo.js"></script>
  <script src="../../assets/js/admin-js/builder-js/cropper-script.js"></script>
  <!-- END TEMPLATE -->

  <!-- END SCRIPT -->
</body>



