<!DOCTYPE html>
<html lang="en">

<head>
  <!-- META SECTION -->
  <title>Setup</title>

  <!-- INCLUDE HEAD -->
  <?php include('layout/head.php'); ?>

  <!-- CSS PLUGINS FOR THIS PAGE -->
  <link rel="stylesheet" type="text/css" href="../../assets/libs/css/flags.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" id="theme" href="../../assets/libs/css/intlTelInput.css" />
  <link href="../../assets/libs/css/cropper.css" rel="stylesheet">

  <!-- CSS FOR THIS PAGE ONLY -->
  <link href="../../assets/css/admin-css/business-record-css/business-record-base.css" rel="stylesheet" />
  <link href="../../assets/css/admin-css/welcome-wizard-css/welcome-wizard.css" rel="stylesheet" />
  <link href="../../assets/css/admin-css/business-record-css/settings.css" rel="stylesheet" />
</head>

<body>
  <!-- START PAGE CONTAINER -->
  <div class="page-container page-navigation-top">
    <!-- PAGE CONTENT -->
    <div class="page-content landing-page-wizard">

      <!--INCLUDE HEADER -->
     <!-- PAGE CONTENT WRAPPER -->
      <div class="page-content-wrap">
        <!-- HEADER -->
        <div class="topNavWrapper">
          <a class='logo-link-blue' href='summary.php'>
            <img src="../../assets/img/funnel-map-icon.png">
            <span>STORY<strong>SCRIPT</strong></span>
          </a>
          <span class="content-title"><div class="tabs-nav no-padding">
          <ul class="col-sm-12 no-padding">
              <li role="presentation" ><a href="create-script-wizard.php"> <img class='normal-icon logo-icon' src="../../assets/img/funnel-map-icon.png"><img class='active-icon logo-icon' src="../../assets/img/logo-icon-white.png">Template</a></li>
              <li role="presentation"><a href="setup1.php"><i class="fa fa-cog"></i>Setup</li>
              <li role="presentation" class="active"><a href="questions.php"><i class="fa fa-list"></i> Questions</a></li>

              <li role="presentation"><a><i class="fa fa-file-text-o"></i> Text Draft</a></li>
            </ul>
          </div></span>
           
         <div class="help-video help-video-container no-padding skipBtn">
          <div class="line">
           <a href="create-funnel-wizard-library.php"><i class="fa fa-chevron-left"></i>
            <span>Go Back</span></a>
          </div>
        </div>
        </div>
        <div class="wrapper">

      
          <div class="tab-content first-level">
            <div class="tab-pane fadeIn active">
              <div class="stepContentHolder no-padding">
                <div class="row">
             
                  <div class="tab-content col-md-11">
                    <div class="row tab-pane fadeIn active" id="profile">
                      <div class="col-md-8">
                        
                        <!-- END USER SETUP -->
                   
                          <div class="questions-info">
                          
                            <div class="row questions">
                                <a class="question-icon"><i class="fa fa-list"></i></a>  Business Insights <a><i class="fa fa-edit"></i></a>
                             </div>
                         
                            <div class="row questions-ans">
                              <p><a>1</a> Give a brief Explanation of whate your business does </p>
                              
                              <p><a>2</a> What is the most important thing your customers are looking for? </p>

                              <p><a>3</a> What is the biggest benefit of dealing with your business? </p>
                            </div>

                            <div class="row questions">
                                <a class="question-icon"><i class="fa fa-list"></i></a>  Business Insights <a><i class="fa fa-edit"></i></a>
                            </div>

                            <div class="row questions">
                                <a class="question-icon"><i class="fa fa-list"></i></a>  Business Insights <a><i class="fa fa-edit"></i></a>
                            </div>
                              
                          </div>
                          <!-- END COMPANY CONTACT INFO -->
                     
                      </div>
                      <div class="col-md-4">
                        <div class="video-img-edit vedioSteps">
                          <iframe height="193" src="https://www.youtube.com/embed/cYiIvg-P9gE" frameborder="0" allowfullscreen></iframe>
                        </div>
                        <div class="btn bootstro-finish-btn-wrapper orange-button nextBtn"> <a href="#" class="">NEXT STEP <i class="fa fa-angle-double-right"></i></a></div>
                        <br>
                        <br>
                        <div class="btn bootstro-finish-btn-wrapper privewqu-button nextBtn"> <a href="#" class=""><i class="fa fa-eye"></i>Priview Questionnaire</a></div>
                      </div>

                    </div>
                   
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- END PAGE CONTENT WRAPPER -->
    </div>
    <!-- END PAGE CONTENT -->  
  </div>
  <!-- END PAGE CONTAINER -->

  <?php include('modals/signout-message-box.php'); ?>

  <!-- INCLUDE FOOTER -->
  <?php include('layout/foot.php'); ?>

  <!-- SCRIPTS FOR THIS PAGE -->
  <!-- PLUGINS -->
  <script type="text/javascript" src="../../assets/libs/js/intlTelInput.js"></script>
  <script type="text/javascript" src="../../assets/libs/js/jquery.flagstrap.js"></script>
  <!-- END PAGE PLUGINS -->
  <!-- START TEMPLATE -->
  <script type="text/javascript" src="../../assets/js/admin-js/business-record-js/settings.js"></script>
  <!-- END TEMPLATE -->
  <!-- END SCRIPTS -->
</body>

</html>
  