<!-- START SCRIPTS -->
<!-- START PLUGINS -->
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script type="text/javascript" src="../../assets/libs/js/jquery/jquery-ui.min.js"></script>
<!-- bootstrap js file  -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<!-- bootstrap Select js file  -->
<script type="text/javascript" src="../../assets/libs/js/bootstrap/bootstrap-select.js"></script>
<!-- END PLUGINS -->
<!-- THIS PAGE PLUGINS -->
<script type="text/javascript" src="../../assets/libs/js/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>
<script src="https://cdn.jsdelivr.net/bootstrap.tagsinput/0.8.0/bootstrap-tagsinput.min.js"></script>
<script type="text/javascript" src='../../assets/libs/js/validationengine/languages/jquery.validationEngine-en.js'></script>
<script type="text/javascript" src="../../assets/libs/js/validationengine/jquery.validationEngine.js"></script>
<script type="text/javascript" src="../../assets/libs/js/jquery-validation/jquery.validate.js"></script>
<!-- END PAGE PLUGINS -->
<!-- START TEMPLATE -->
<script type="text/javascript" src="../../assets/js/admin-js/business-record-js/business-record-base.js"></script>
<script type="text/javascript" src="../../assets/js/plugins.js"></script>
<script type="text/javascript" src="../../assets/js/actions.js"></script>