<!-- META SECTION -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="icon" href="../../assets/img/funnel-map-icon.png" type="image/x-icon" />
<!-- END META SECTION -->

<!-- COMMON CSS EXTERNAL LIBRARIES -->
<link rel="stylesheet" type="text/css" id="theme" href="../../assets/libs/css/theme-default.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="../../assets/libs/css/mcustomscrollbar/jquery.mCustomScrollbar.css" rel="stylesheet" />

<!-- COMMON CSS INTERNAL LIBRARIES -->
<link href="../../assets/css/base-new.css" rel="stylesheet" type="text/css">

