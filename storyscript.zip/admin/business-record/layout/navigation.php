<ul class="nav nav-tabs nav-justified top-nav">
    <li class="<?php echo ($headerActiveItem == 'summary') ? 'active' : ''; ?>">
        <a href="summary.php">
            <i class="fa fa-area-chart"></i>Summary
        </a>
    </li>
    <li class="<?php echo ($headerActiveItem == 'library') ? 'active' : ''; ?>">
        <a href="funnel-library.php">
            <img class='normal-icon logo-icon' src="../../assets/img/funnel-map-icon.png">
            <img class='active-icon logo-icon' src="../../assets/img/logo-icon-white.png">
            Funnel Library
        </a>
    </li>
    <li class="<?php echo ($headerActiveItem == 'minicourse') ? 'active' : ''; ?>">
        <a href="minicourse.php"><i class="fa fa-desktop"></i>Mini Course</a>
    </li>
    <li class="<?php echo ($headerActiveItem == 'settings') ? 'active' : ''; ?>">
        <a href="settings.php"><i class="fa fa-gear"></i>Settings</a>
    </li>
    <li class="new-funnel">
        <a href="create-funnel-wizard-library.php"><i class="fa fa-plus"></i>New Funnel</a>
    </li>
</ul>