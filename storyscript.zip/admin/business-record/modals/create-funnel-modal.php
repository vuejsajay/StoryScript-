<div class="modal fade" id="create-funnel-modal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
        <h4 class="modal-title"><i class="fa fa-plus"></i>NEW FUNNEL MAP</h4>
      </div>
      <div class="modal-body">
        <div class="col-md-8">
          <form id='newFunnelMapForm'>
            <div class="row">
              <div class="form-group">
                <label class="col-xs-3 no-padding control-label text-right label-style">Funnel Name</label>
                <div class="col-xs-9 padding-right-41">
                  <div class="inner-addon right-addon">
                    <div class="formField">
                      <input name="funnelMapName" class="form-control pageName" placeholder="Funnel Name Goes Here" maxlength="40" required>
                      <span class="pageNameCount"><span>0</span> / 40</span>
                    </div>
                  </div>
                </div>
                <div class="clearfix"></div>
              </div>
              <div class="form-group">
                <label class="col-xs-3 no-padding control-label text-right label-style">Funnel Type</label>
                <div class="col-xs-9 padding-right-41">
                  <select class="select select-funnel-type required" name="funnelType">
                    <option value="" selected disabled>Select</option>
                    <option value="1" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/brandsite-funnel.png'/></i> Brandsite Funnel">Brandsite Funnel</option>
                    <option value="2" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/optin-funnel.png'/></i> Optin Lead Funnel">Optin Lead Funnel</option>
                    <option value="3" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/sales-funnel.png'/></i> Sales Funnel">Sales Funnel</option>
                    <option value="4" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/upsell-funnel.png'/></i> Upsell Funnel">Upsell Funnel</option>
                    <option value="5" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/profit-funnel.png'/></i> Profit Funnel">Profit Funnel</option>
                    <option value="6" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/webinar-funnel.png'/></i> Webinar Funnel">Webinar Funnel</option>
                    <option value="7" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/launch-funnel.png'/></i> Launch Funnel">Launch Funnel</option>
                    <option value="8" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/ecom-funnel.png'/></i> Ecom Funnel">Ecom Funnel</option>
                    <option value="9" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/social-media-funnel.png'/></i> Social Media Funnel">Social Media Funnel</option>
                    <option value="10" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/campaign-funnel.png'/></i> Ask Campaign Funnel">Ask Campaign Funnel</option>
                    <option value="11" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/membership-funnel.png'/></i> Membership Funnel">Membership Funnel</option>
                    <option value="12" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/affiliate-funnel.png'/></i> Affiliate Funnel">Affiliate Funnel</option>
                    <option value="13" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/video-sales-funnel.png'/></i> Video Sales Letter Funnel">Video Sales Letter Funnel</option>
                    <option value="14" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/survey-funnel.png'/></i> Survey Funnel">Survey Funnel</option>
                    <option value="15" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/challenge-funnel.png'/></i> Challenge Funnel">Challenge Funnel</option>
                    <option value="16" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/live-stream-funnel.png'/></i> Live Stream Funnel">Live Stream Funnel</option>
                    <option value="17" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/cancellation-funnel.png'/></i> Cancellation Funnel">Cancellation Funnel</option>
                    <option value="18" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/application-funnel.png'/></i> Application Funnel">Application Funnel</option>
                    <option value="19" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/daily-deal-funnel.png'/></i> Daily Deal Funnel">Daily Deal Funnel</option>
                  </select>
                </div>
                <div class="clearfix"></div>
              </div>
              <div class="form-group" style="display: none;">
                <label class="col-xs-3 no-padding control-label text-right label-style">Color</label>
                <div class="col-xs-9 padding-right-41 mt-5">
                  <input class="form-control" id="funnelColor">
                </div>
                <div class="clearfix"></div>
              </div>
            </div>
          </form>
        </div>
        <div class="col-md-4 custom-padding-left hidden-md">
          <div class="embed-responsive embed-responsive-16by9">
            <iframe width="560" height="315" src="https://www.youtube.com/embed/cYiIvg-P9gE" frameborder="0" allowfullscreen=""></iframe>
          </div>
          <a href="#" data-path="../" class="btn bootstro-finish-btn-wrapper blue-button nextBtn">NEXT Step <i class="fa fa-angle-double-right"></i></a>
        </div>
      </div>
    </div>
  </div>
</div>