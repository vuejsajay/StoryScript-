<div class="page-container page-navigation-top animated fadeIn" id="saveAsTemplatePage">
  <!-- PAGE CONTENT -->
  <div class="page-content landing-page-wizard">
    <!-- PAGE CONTENT WRAPPER -->
    <div class="page-content-wrap">
      <div class="topNavWrapper">
        <img src="../../assets/img/funnel-map-icon.png">
        <span>FUNNEL<strong>MAPS</strong></span>
        <span class="content-title"><i class="fa fa-save"></i>SAVE YOUR FUNNEL MAP AS A TEMPLATE</span>
        <a class="skipBtn backBtn" href="#"><i class="fa fa-angle-left"></i>GO BACK </a>
      </div>
      <div class="stepContentHolder step1">
        <div class="row">
          <div class="col-md-8">
            <form id="saveTemplateForm" class="form-horizontal saveTemplateForm">
              <div class="form-group required">
                <label class="col-md-3 col-xs-12 control-label">Template Name</label>
                <div class="col-md-9 col-xs-12">
                  <div class="formField">
                    <input name="templateName" type="text" class="form-control counting-field" placeholder="Funnel Template Name Goes Here" maxlength="40">
                    <span class="char-counter"><span class="update-counter">0</span> / 40</span>
                  </div>
                </div>
              </div>
              <div class="form-group required">
                <label class="col-md-3 col-xs-12 control-label">Description</label>
                <div class="col-md-9 col-xs-12">
                  <textarea class="form-control" rows='6' placeholder="Describe Your Funnel Map Template" name='description'></textarea>
                </div>
              </div>
              <div class="form-group">
                <label class="col-md-3 col-xs-12 control-label">Tags</label>
                <div class="col-md-9 col-xs-12">
                  <input type="text" value="" data-role="tagsinput" class="form-control tag-box">
                </div>
              </div>
              <div class="form-group" style="position: relative;">
                <label class="col-md-3 col-xs-12 control-label">Video URL</label>
                <div class="col-md-9 col-xs-12 videoUrlWrapper" style="position: relative;">
                  <input id="videoUrl" type="text" name="videoUrl" value="" class="form-control">
                  <div class="col-xs-12 no-padding">
                    <div class="note-meta">
                      <i class="fa fa-info-circle"></i> Youtube and Vimeo Videos only.
                    </div>
                  </div>
                  <span class="video-icon"><i class="fa fa-vimeo"></i></span>
                </div>
                <div class="valid-mark"><i class="fa fa-check"></i></div>
              </div>
              <div class="form-group">
                <label class="col-md-3 col-xs-12 control-label">Thumnail</label>
                <div class="col-md-9 col-xs-12">
                  <div class="upload-thumb">
                    <img class="img-thumbnail" src="../../assets/img/thumb-upload-bg.png">
                    <a class="skipBtn upload-btn" href="#"><i class="fa fa-cloud-upload"></i>Upload </a>
                    <div class="img-overlay">
                      <button class="edit-thumb-btn" type="button"><i class="fa fa-edit"></i></button>
                      <button class="delete-thumb-btn" type="button"><i class="fa fa-trash"></i></button>
                    </div>
                  </div>
                  <i class="upload-desc">JPG,PNG 16X9 Image</i>
                </div>
              </div>
              <div class="form-group" style="display: none">
                <label class="col-md-3 col-xs-12 control-label">Color</label>
                <div class="col-md-9 col-xs-12 mt-5">
                  <input class="form-control" id="funnelColor">
                </div>
              </div>
            </form>
            <form id="imgForm" style="display:none;">
              <input name="imageField" type="file" accept="image/jpeg,image/x-png" />
            </form>
          </div>
          <div class="col-md-4">
            <div class="video-img-edit vedioSteps">
              <iframe height="193" src="https://www.youtube.com/embed/cYiIvg-P9gE" frameborder="0" allowfullscreen></iframe>
            </div>
            <div class="btn bootstro-finish-btn-wrapper orange-button nextBtn"> <a href="#" class="save-template-btn"><i class="fa fa-check"></i>SAVE TEMPLATE </a> </div>
          </div>
        </div>
      </div>
    </div>
    <!-- END PAGE CONTENT WRAPPER -->
  </div>
  <!-- END PAGE CONTENT -->
</div>