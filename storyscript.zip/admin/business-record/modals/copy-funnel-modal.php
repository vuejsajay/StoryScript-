<div class="modal fade" id="create-funnel-modal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
        <h4 class="modal-title"><i class="fa fa-plus"></i>NEW FUNNEL MAP</h4>
      </div>
      <div class="modal-body">
        <div class="col-md-8">
          <form id='newFunnelMapForm'>
            <div class="row">
              <div class="form-group">
                <label class="col-xs-3 no-padding control-label text-right label-style">Funnel Name</label>
                <div class="col-xs-9 padding-right-41">
                  <div class="inner-addon right-addon">
                    <div class="formField">
                      <input name="funnelMapName" class="form-control counting-field" placeholder="Funnel Name Goes Here" maxlength="40" required>
                      <span class="char-counter"><span class="update-counter">0</span> / 40</span>
                    </div>
                  </div>
                </div>
                <div class="clearfix"></div>
              </div>
              <div class="form-group" style="display: none;">
                <label class="col-xs-3 no-padding control-label text-right label-style">Color</label>
                <div class="col-xs-9 padding-right-41 mt-5">
                  <input class="form-control" id="funnelColor">
                </div>
                <div class="clearfix"></div>
              </div>
            </div>
          </form>
        </div>
        <div class="col-md-4 custom-padding-left hidden-md">
          <div class="embed-responsive embed-responsive-16by9">
            <iframe width="560" height="315" src="https://www.youtube.com/embed/cYiIvg-P9gE" frameborder="0" allowfullscreen=""></iframe>
          </div>
          <a href="#" data-path="../" class="btn bootstro-finish-btn-wrapper blue-button nextBtn">NEXT Step <i class="fa fa-angle-double-right"></i></a>
        </div>
      </div>
    </div>
  </div>
</div>