<!-- Help Video Modal -->
<div class="modal fade" id="video-modal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-body">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
        <div class="col-xs-12 no-padding">
          <div class="embed-responsive embed-responsive-16by9">
            <iframe class="yvideo-form" src="https://player.vimeo.com/video/49614043?title=0&byline=0&portrait=0" frameborder="0" allowfullscreen=""></iframe>
          </div>
        </div>
        <div class="clearfix"></div>
      </div>
    </div>
  </div>
</div>
<!-- Help Video Modal End-->