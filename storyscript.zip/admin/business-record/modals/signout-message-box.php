<!-- LOGOUT MESSAGE BOX-->
<div class="message-box animated fadeIn" data-sound="alert" id="mb-signout">
  <div class="mb-container">
    <div class="mb-middle">
      <div class="mb-title"><span class="fa fa-sign-out"></span> Log <strong>Out</strong> ?</div>
      <div class="mb-content">
        <p>Are You Sure You Want To LOG OUT ?</p>
        <p>Press No If You Want To Continue Work. Press Yes To Logout.</p>
      </div>
      <div class="mb-footer">
        <div class="pull-right"> <a href="/" class="btn btn-success btn-lg">Yes</a>
          <button class="btn btn-default btn-lg mb-control-close">No</button>
        </div>
      </div>
    </div>
  </div>
</div>