<!DOCTYPE html>
<html lang="en">

<head>
  <title>Create Funnel Wizard Library</title>

  <!-- INCLUDE HEAD -->
  <?php include('layout/head.php'); ?>

  <!-- CSS PLUGINS FOR THIS PAGE -->
  <link href="https://cdn.jsdelivr.net/bootstrap.tagsinput/0.8.0/bootstrap-tagsinput.css" rel="stylesheet" />
  <!-- Cropper -->
  <link href="../../assets/libs/css/cropper.css" rel="stylesheet">
  <!-- CSS Custom -->
  <link href="../../assets/css/admin-css/builder-css/upload-demo.css" rel="stylesheet" />
  <link href="../../assets/css/admin-css/business-record-css/create-funnel-popup.css" rel="stylesheet" type="text/css">
  <link href="../../assets/css/admin-css/welcome-wizard-css/welcome-wizard.css" rel="stylesheet" />
  <link href="../../assets/css/admin-css/business-record-css/business-record-base.css" rel="stylesheet" />
  <link href="../../assets/css/admin-css/business-record-css/create-funnel-wizard-library.css" rel="stylesheet"/>
  <!-- EOF CSS Custom -->
</head>

<body>
  <!-- START PAGE CONTAINER -->
  <div class="page-container page-navigation-top animated fadeIn" id="mainPage">
    <!-- PAGE CONTENT -->
    <div class="page-content landing-page-wizard">
      <!-- PAGE CONTENT WRAPPER -->
      <div class="page-content-wrap">

        <!-- HEADER -->
        <div class="topNavWrapper">
          <a class='logo-link-blue' href='summary.php'>
            <img src="../../assets/img/funnel-map-icon.png">
            <span>FUNNEL<strong>MAPS</strong></span>
          </a>
          <span class="content-title">FUNNEL TEMPLATE LIBRARY</span>
          <?php include('modals/help-video-dropdown.php'); ?>
        </div>
        <!-- END HEADER -->

        <div class="stepContentHolder">

          <!-- NAVIGATION BAR -->
          <div class="tabs-nav no-padding">
            <ul class="col-sm-12 no-padding">
              <li role="presentation" class="active"><a href="#funnelLibrary" role="tab" data-toggle="tab"> <img class='normal-icon logo-icon' src="../../assets/img/funnel-map-icon.png"><img class='active-icon logo-icon' src="../../assets/img/logo-icon-white.png">Funnel Library<span>20</span></a></li>
              <li role="presentation"><a href="#myFunnels" role="tab" data-toggle="tab"><i class="fa fa-user"></i>  My Funnels<span>10</span></a></li>
              <li role="presentation"><a href="#marketplace" role="tab" data-toggle="tab"><i class="fa fa-shopping-cart"></i> Marketplace<span>0</span></a></li>
              <div class="pull-right">
                <li role="presentation" class="search"><div class="searchWrapper"><input type="search" class="" placeholder="Search..." aria-controls="LatestBanners"><i class="fa fa-search searchIcon"></i></div></li>
                <li><div class="separator"></div></li>
                <li role="presentation" class="filter">
                  <span><i class="fa fa-filter"></i><b> Type</b></span>
                  <select class="select select-funnel-type required" name="funnelType" id="select-funnel-type">
                    <option value="0" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/all.png'/></i><span>All Funnels</span>" data-filter='*'>All Funnels</option>
                    <option value="1" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/brandsite-funnel.png'/></i><span class='option-text'>Brandsite Funnel</span>" data-filter='.brand'>Brandsite Funnel</option>
                    <option value="2" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/optin-funnel.png'/></i><span class='option-text'>Optin Lead Funnel</span>" data-filter='.optin'>Optin Lead Funnel</option>
                    <option value="3" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/sales-funnel.png'/></i><span class='option-text'>Sales Funnel</span>" data-filter='.sales'>Sales Funnel</option>
                    <option value="4" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/upsell-funnel.png'/></i><span class='option-text'>Upsell Funnel</span>" data-filter='.upsell'>Upsell Funnel</option>
                    <option value="5" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/profit-funnel.png'/></i><span class='option-text'>Profit Funnel</span>" data-filter='.profit'>Profit Funnel</option>
                    <option value="6" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/webinar-funnel.png'/></i><span class='option-text'>Webinar Funnel</span>" data-filter='.webinar'>Webinar Funnel</option>
                    <option value="7" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/launch-funnel.png'/></i><span class='option-text'>Launch Funnel</span>" data-filter='.launch'>Launch Funnel</option>
                    <option value="8" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/ecom-funnel.png'/></i><span class='option-text'>Ecom Funnel</span>" data-filter='.ecom'>Ecom Funnel</option>
                    <option value="9" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/social-media-funnel.png'/></i><span class='option-text'>Social Media Funnel</span>" data-filter='.social'>Social Media Funnel</option>
                    <option value="10" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/campaign-funnel.png'/></i><span class='option-text'>Ask Campaign Funnel</span>" data-filter='.campaign'>Ask Campaign Funnel</option>
                    <option value="11" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/membership-funnel.png'/></i><span class='option-text'>Membership Funnel</span>" data-filter='.membership'>Membership Funnel</option>
                    <option value="12" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/affiliate-funnel.png'/></i><span class='option-text'>Affiliate Funnel</span>" data-filter='.affiliate'>Affiliate Funnel</option>
                    <option value="13" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/video-sales-funnel.png'/></i><span class='option-text'>Video Sales Letter Funnel</span>" data-filter='.video'>Video Sales Letter Funnel</option>
                    <option value="14" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/survey-funnel.png'/></i><span class='option-text'>Survey Funnel</span>" data-filter='.survey'>Survey Funnel</option>
                    <option value="15" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/challenge-funnel.png'/></i><span class='option-text'>Challenge Funnel</span>" data-filter='.challenge'>Challenge Funnel</option>
                    <option value="16" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/live-stream-funnel.png'/></i><span class='option-text'>Live Stream Funnel</span" data-filter='.stream'>Live Stream Funnel</option>
                    <option value="17" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/cancellation-funnel.png'/></i><span class='option-text'>Cancellation Funnel</span>" data-filter='.cancel'>Cancellation Funnel</option>
                    <option value="18" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/application-funnel.png'/></i><span class='option-text'>Application Funnel</span>" data-filter='.app'>Application Funnel</option>
                    <option value="19" data-content="<i class='fa'><img src='../../assets/img/funnel-icons/colored/daily-deal-funnel.png'/></i><span class='option-text'>Daily Deal Funnel</span>" data-filter='.daily'>Daily Deal Funnel</option>
                  </select>
                </li>
              </div>
            </ul>
          </div>
          <!-- END NAVIGATION BAR -->

          <div class="tab-content second-level">

            <!-- BEGIN FUNNEL LIBRARY -->
            <div class="tab-pane fadeIn active" id="funnelLibrary">
              <div class="row item-container">

                <!-- Start From Scratch item -->
                <div class="col-xs-3 no-padding">
                  <div class="banner-item from-scratch" data-toggle='modal' data-target='#create-funnel-modal'>
                    <div class="img-overlay animated fadeIn">
                      <a class="button preview-button" href="#"><i class="fa fa-check"></i>Start From Scratch</a>
                    </div>
                    <div class="square-content">
                      <div class="content-inside">
                        <img class="img-responsive" src="../../assets/img/from-scratch.png">
                      </div>
                      <div class="top-title">
                        <span>Start From Scratch</span>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- END Start From Scratch item -->

                <?php
                  $funnelsLibraryItems = [
                    [
                      'type'  => 'optin',
                      'image' => '../../assets/img/optin-funnel.png',
                      'title' => 'Optin Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/optin-funnel.png'
                    ],
                    [
                      'type'  => 'sales',
                      'image' => '../../assets/img/sales-funnel.png',
                      'title' => 'Sales Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/sales-funnel.png',
                      'isMyFunnel' => true,
                    ],
                    [
                      'type'  => 'upsell',
                      'image' => '../../assets/img/upsell-funnel.png',
                      'title' => 'Upsell Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/upsell-funnel.png'
                    ],
                    [
                      'type'  => 'normal-thumb brand',
                      'image' => '../../assets/img/optin-funnel-normal-thumb.png',
                      'title' => 'Brand site Funnel Namez Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/brandsite-funnel.png',
                      'isMyFunnel' => true,
                    ],
                    [
                      'type'  => 'normal-thumb profit',
                      'image' => '../../assets/img/optin-funnel-normal-thumb.png',
                      'title' => 'Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/profit-funnel.png',
                      'isMyFunnel' => true,
                    ],
                    [
                      'type'  => 'normal-thumb webinar',
                      'image' => '../../assets/img/optin-funnel-normal-thumb.png',
                      'title' => 'Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/webinar-funnel.png',
                      'isMyFunnel' => true,
                    ],
                    [
                      'type'  => 'normal-thumb launch',
                      'image' => '../../assets/img/optin-funnel-normal-thumb.png',
                      'title' => 'Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/launch-funnel.png',
                      'isMyFunnel' => true,
                    ],
                    [
                      'type'  => 'normal-thumb ecom',
                      'image' => '../../assets/img/optin-funnel-normal-thumb.png',
                      'title' => 'Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/ecom-funnel.png',
                      'isMyFunnel' => true,
                    ],
                    [
                      'type'  => 'normal-thumb social',
                      'image' => '../../assets/img/optin-funnel-normal-thumb.png',
                      'title' => 'Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/social-media-funnel.png',
                      'isMyFunnel' => true,
                    ],
                    [
                      'type'  => 'normal-thumb campaign',
                      'image' => '../../assets/img/optin-funnel-normal-thumb.png',
                      'title' => 'Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/campaign-funnel.png',
                      'isMyFunnel' => true,
                    ],
                    [
                      'type'  => 'normal-thumb membership',
                      'image' => '../../assets/img/optin-funnel-normal-thumb.png',
                      'title' => 'Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/membership-funnel.png',
                      'isMyFunnel' => true,
                    ],
                    [
                      'type'  => 'normal-thumb affiliate',
                      'image' => '../../assets/img/optin-funnel-normal-thumb.png',
                      'title' => 'Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/affiliate-funnel.png',
                      'isMyFunnel' => true,
                    ],
                    [
                      'type'  => 'normal-thumb video',
                      'image' => '../../assets/img/optin-funnel-normal-thumb.png',
                      'title' => 'Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/video-sales-funnel.png'
                    ],
                    [
                      'type'  => 'normal-thumb survey',
                      'image' => '../../assets/img/optin-funnel-normal-thumb.png',
                      'title' => 'Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/survey-funnel.png'
                    ],
                    [
                      'type'  => 'normal-thumb challenge',
                      'image' => '../../assets/img/optin-funnel-normal-thumb.png',
                      'title' => 'Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/challenge-funnel.png'
                    ],
                    [
                      'type'  => 'normal-thumb stream',
                      'image' => '../../assets/img/optin-funnel-normal-thumb.png',
                      'title' => 'Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/stream-funnel.png'
                    ],
                    [
                      'type'  => 'normal-thumb cancel',
                      'image' => '../../assets/img/optin-funnel-normal-thumb.png',
                      'title' => 'Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/cancellation-funnel.png'
                    ],
                    [
                      'type'  => 'normal-thumb app',
                      'image' => '../../assets/img/optin-funnel-normal-thumb.png',
                      'title' => 'Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/application-funnel.png'
                    ],
                    [
                      'type'  => 'normal-thumb daily',
                      'image' => '../../assets/img/optin-funnel-normal-thumb.png',
                      'title' => 'Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/daily-deal-funnel.png'
                    ],
                    [
                      'type'  => 'normal-thumb brand',
                      'image' => '../../assets/img/optin-funnel-normal-thumb.png',
                      'title' => 'Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/brandsite-funnel.png'
                    ]
                  ];
                ?>
                <?php foreach( $funnelsLibraryItems as $funnel ){ ?>
                  <div class="col-xs-3 no-padding">
                    <div class="banner-item <?php echo $funnel['type']; ?>">
                      <div class="img-overlay animated fadeIn">
                        <a class="button preview-button" href="view-funnel.php">
                          <img src="../../assets/img/eye-preview.png" alt="" />View This Funnel
                        </a>
                        <?php if(isset($funnel['isMyFunnel']) && $funnel['isMyFunnel'] == true) echo('<div class="my-temp-icon label-icon" data-toggle="popover" data-trigger="hover" data-placement="top" data-container="body" data-content="My Template"><i class="fa fa-user"></i></div>'); ?>
                      </div>
                      <div class="square-content">
                        <?php if(strpos($funnel['type'], 'normal-thumb') !== false) echo('<div class="left-bar"></div>'); ?>
                        <div class="content-inside">
                          <img class="img-responsive" src="<?php echo $funnel['image']; ?>" alt="" />
                        </div>
                        <div class="top-title">
                          <div class="funnel-icon">
                            <img src="<?php echo $funnel['icon']; ?>" alt="" />
                          </div>
                          <span><?php echo $funnel['title']; ?>"</span>
                        </div>
                      </div>
                    </div>
                  </div>
                <?php } ?>

              </div>
            </div>
            <!-- END FUNNEL LIBRARY -->

            <!-- BEGIN MY FUNNELS -->
            <div class="tab-pane fadeIn" id="myFunnels">
              <div class="row item-container my-funnels">

                <!-- Start From Scratch item -->
                <div class="col-xs-3 no-padding">
                  <div class="banner-item from-scratch" data-toggle='modal' data-target='#create-funnel-modal'>
                    <div class="img-overlay animated fadeIn">
                      <a class="button preview-button" href="#"><i class="fa fa-check"></i>Start From Scratch</a>
                    </div>
                    <div class="square-content">
                      <div class="content-inside">
                        <img class="img-responsive" src="../../assets/img/from-scratch.png">
                      </div>
                      <div class="top-title">
                        <span>Start From Scratch</span>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- END Start From Scratch item -->

                <?php
                  //List with items
                  $myFunnelsItems = [
                    [
                      'type'  => 'sales',
                      'image' => '../../assets/img/sales-funnel.png',
                      'title' => 'Sales Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/sales-funnel.png',
                      'isMyFunnel' => true,
                    ],
                    [
                      'type'  => 'normal-thumb brand',
                      'image' => '../../assets/img/optin-funnel-normal-thumb.png',
                      'title' => 'Brand Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/brandsite-funnel.png',
                      'isMyFunnel' => true,
                    ],
                    [
                      'type'  => 'normal-thumb optin',
                      'image' => '../../assets/img/optin-funnel-normal-thumb.png',
                      'title' => 'Optin Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/optin-funnel.png',
                      'isMyFunnel' => true,
                    ],
                    [
                      'type'  => 'normal-thumb sales',
                      'image' => '../../assets/img/optin-funnel-normal-thumb.png',
                      'title' => 'Sales Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/sales-funnel.png',
                      'isMyFunnel' => true,
                    ],
                    [
                      'type'  => 'normal-thumb upsell',
                      'image' => '../../assets/img/optin-funnel-normal-thumb.png',
                      'title' => 'Upsell Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/upsell-funnel.png',
                      'isMyFunnel' => true,
                    ],
                    [
                      'type'  => 'normal-thumb brand',
                      'image' => '../../assets/img/optin-funnel-normal-thumb.png',
                      'title' => 'Brand Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/brandsite-funnel.png',
                      'isMyFunnel' => true,
                    ],
                    [
                      'type'  => 'normal-thumb optin',
                      'image' => '../../assets/img/optin-funnel-normal-thumb.png',
                      'title' => 'Optin Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/optin-funnel.png',
                      'isMyFunnel' => true,
                    ],
                    [
                      'type'  => 'normal-thumb sales',
                      'image' => '../../assets/img/optin-funnel-normal-thumb.png',
                      'title' => 'Sales Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/sales-funnel.png',
                      'isMyFunnel' => true,
                    ],
                    [
                      'type'  => 'normal-thumb upsell',
                      'image' => '../../assets/img/optin-funnel-normal-thumb.png',
                      'title' => 'Upsell Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/upsell-funnel.png',
                      'isMyFunnel' => true,
                    ],
                    [
                      'type'  => 'normal-thumb affiliate',
                      'image' => '../../assets/img/optin-funnel-normal-thumb.png',
                      'title' => 'Funnel Name Goes Here 2 Lines',
                      'icon'  => '../../assets/img/funnel-icons/white/affiliate-funnel.png',
                      'isMyFunnel' => true,
                    ],
                  ];
                ?>
                <?php foreach( $myFunnelsItems as $funnel ){ ?>
                  <div class="col-xs-3 no-padding">
                    <div class="banner-item <?php echo $funnel['type']; ?>">
                      <div class="img-overlay animated fadeIn">
                        <a class="button preview-button" href="view-funnel.php">
                          <img src="../../assets/img/eye-preview.png" alt="" />View This Funnel
                        </a>
                        <?php if(isset($funnel['isMyFunnel']) && $funnel['isMyFunnel'] == true) echo('<div class="my-temp-icon label-icon" data-toggle="popover" data-trigger="hover" data-placement="top" data-container="body" data-content="My Template"><i class="fa fa-user"></i></div>'); ?>
                      </div>
                      <div class="square-content">
                        <?php if(strpos($funnel['type'], 'normal-thumb') !== false) echo('<div class="left-bar"></div>'); ?>
                        <div class="content-inside">
                          <img class="img-responsive" src="<?php echo $funnel['image']; ?>" alt="" />
                        </div>
                        <div class="top-title">
                          <div class="funnel-icon">
                            <img src="<?php echo $funnel['icon']; ?>" alt="" />
                          </div>
                          <span><?php echo $funnel['title']; ?>"</span>
                        </div>
                      </div>
                    </div>
                  </div>
                <?php } ?>
                
              </div>
            </div>
            <!-- END MY FUNNELS -->

            <!-- BEGIN MARKETPLACE -->
            <div class="tab-pane fadeIn" id="marketplace">
               <div class="col-xs-3 no-padding">
                  <div class="banner-item from-scratch" data-toggle='modal' data-target='#create-funnel-modal'>
                    <div class="img-overlay animated fadeIn">
                      <a class="button preview-button" href="#"><i class="fa fa-check"></i>Start From Scratch</a>
                    </div>
                    <div class="square-content">
                      <div class="content-inside">
                        <img class="img-responsive" src="../../assets/img/from-scratch.png">
                      </div>
                      <div class="top-title">
                        <span>Start From Scratch</span>
                      </div>
                    </div>
                  </div>
                </div>
            </div>
            <!-- END MARKETPLACE -->
          </div>
        </div>
      </div>
      <!-- END PAGE CONTENT WRAPPER -->
    </div>
    <!-- END PAGE CONTENT -->
  </div>

  <?php include('modals/save-as-template.php'); ?>
  <?php include('modals/create-funnel-modal.php'); ?>
  
  <!-- INCLUDE FOOTER -->
  <?php include('layout/foot.php'); ?>

  <!-- START SCRIPTS -->
  <!-- START PLUGINS -->
  <script src="https://cdn.jsdelivr.net/bootstrap.tagsinput/0.8.0/bootstrap-tagsinput.min.js"></script>
  <!-- Cropper -->
  <script src="../../assets/libs/js/cropper.js"></script>
  <!-- END PAGE PLUGINS -->
  <!-- START TEMPLATE -->
  <script src="../../assets/js/admin-js/business-record-js/upload.js"></script>
  <script src="../../assets/js/admin-js/business-record-js/cropper-script.js"></script>
  <script type="text/javascript" src="../../assets/js/admin-js/business-record-js/create-funnel-wizard-library.js"></script>
  <!-- END TEMPLATE -->
  <!-- END SCRIPTS -->
</body>

</html>
