<!DOCTYPE html>
<html lang="en">
<head>
  <title>View Funnel</title>

  <!-- INCLUDE HEAD -->
  <?php include('layout/head.php'); ?>

  <!-- Plugin CSS INCLUDE -->
  <link rel="stylesheet" type="text/css" href="../../assets/libs/css/flags.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" id="theme" href="../../assets/libs/css/intlTelInput.css" />
  <link rel="stylesheet" type="text/css" id="theme" href="../../assets/libs/css/spectrum.css" />
  <!-- END Plugin CSS INCLUDE -->
  <!-- CSS Custom -->
  <link href="../../assets/css/admin-css/business-record-css/create-funnel-popup.css" rel="stylesheet" type="text/css">
  <link href="../../assets/css/admin-css/welcome-wizard-css/welcome-wizard.css" rel="stylesheet" />
  <link href="../../assets/css/admin-css/business-record-css/business-record-base.css" rel="stylesheet" />
  <link href="../../assets/css/admin-css/business-record-css/view-funnel.css" rel="stylesheet" />
  <!-- End CSS Custom -->
</head>
<body>
  <!-- START PAGE CONTAINER -->
  <div class="page-container page-navigation-top">
    <!-- PAGE CONTENT -->
    <div class="page-content landing-page-wizard">
      <!-- PAGE CONTENT WRAPPER -->
      <div class="page-content-wrap">
        <div class="topNavWrapper">
          <a class='logo-link-blue' href='summary.php'>
            <img src="../../assets/img/funnel-map-icon.png">
            <span>FUNNEL<strong>MAPS</strong></span>
          </a>
          <div class="help-video help-video-container no-padding skipBtn">
            <div class="line">
              <i class="fa fa-play-circle-o"></i>
              <span>HELP VIDEO</span>
              <i class="fa fa-caret-down" aria-hidden="true"></i>
            </div>
            <div class="video-wrapper video-container" style="display:none">
              <div class="embed-responsive embed-responsive-16by9">
                <iframe width="495" height="278" class="yvideo stopped" src="https://www.youtube.com/embed/cYiIvg-P9gE" frameborder="0" allowfullscreen></iframe>
              </div>
              <div class="clearfix"></div>
            </div>
          </div>
        </div>
        <div class="stepContentHolder step2 view-funnel">
          <div class="row">
            <h1>FUNNEL MAP TEMPLATE HEADLINE GOES HERE</h1>
            <div class="video-img-edit">
              <iframe height="357" width="650" src="https://www.youtube.com/embed/cYiIvg-P9gE" frameborder="0" allowfullscreen></iframe>
            </div>
            <div class="btns-wrapper">
              <a href="#create-funnel-modal" data-toggle="modal"><button class="orange-button vf-btn" data-toggle="popover" data-trigger='hover' data-placement='top' data-container='body' data-content='Copy This Template To Edit And Use In Your Funnel Maps Account'> <img src="../../assets/img/logo-icon-white.png">Copy This Funnel </button></a>
              <button class="blue-button vf-btn" data-toggle="popover" data-trigger='hover' data-placement='top' data-container='body' data-content='Copy This Template To Funnel Pages To Build Your Funnel' style="display: none"><img src="../../assets/img/hyper-logo.png">Use In Funnel Pages</button>
              <a href="https://drive.google.com/open?id=1bKscmGdE2Cx1Gf4gIseEyF-9QjbdMoUd"><button class="teal-button vf-btn" data-toggle="popover" data-trigger='hover' data-placement='top' data-container='body' data-content='Download All The Resources To Your Computer'><i class="fa fa-cloud-download"></i>Download Resources </button></a>
            </div>
            <div class="funnel-desc">
              <p>The goal with the product sales funnel is to qualify buyers by offering them an irresistible low ticket item. After the customer has purchased the low ticket item, you will offer them upsells and downsells to increase the average cart value. The goal with this funnel.</p>
              <p>The goal with the product sales funnel is to qualify buyers by offering them an irresistible low ticket item. After the customer has purchased the low ticket item, you will offer them upsells and downsells to increase the average cart value. The goal with this funnel.</p>
            </div>
          </div>
        </div>
      </div>
      <!-- END PAGE CONTENT WRAPPER -->
    </div>
    <!-- END PAGE CONTENT -->
  </div>
  <!-- END PAGE CONTAINER -->

  <?php include('modals/copy-funnel-modal.php'); ?>

  <!-- INCLUDE FOOTER -->
  <?php include('layout/foot.php'); ?>

  <!-- START SCRIPTS -->
  <!-- START PLUGINS -->
  <script type="text/javascript" src="../../assets/libs/js/spectrum.js"></script>
  <!-- END PLUGINS -->
  <!-- START TEMPLATE -->
  <script src="../../assets/js/admin-js/business-record-js/view-funnel.js"></script>
  <!-- END TEMPLATE -->
  <!-- END SCRIPTS -->
</body>
</html>
