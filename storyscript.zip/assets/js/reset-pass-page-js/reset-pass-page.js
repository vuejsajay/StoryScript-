$(".sent-pass-btn").click(function(){
  $(".login-form-container.sent-form").hide();
  $(".login-form-container.sent-success").show();
});
