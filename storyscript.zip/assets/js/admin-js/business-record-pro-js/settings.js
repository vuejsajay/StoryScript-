$("#contactPhone").intlTelInput();
$("#companyContactPhone").intlTelInput();
$("#businessPhone").intlTelInput();
$('#countryDDL').flagStrap();
$('#companyCountryDDL').flagStrap();

// form validation
// first override jquery validate plugin defaults
$.validator.addMethod("customemail",
  function(value, element) {
    return /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/.test(value);
  },
  "Please enter a valid email address."
);
$.validator.addMethod("phoneNumber",
  function(value, element) {
    if(value == '') return true;
    return /^[+]*[(]{0,1}[0-9]{1,4}[)]{0,1}[-\s\./0-9]*$/.test(value);
  },
  "Please enter a valid phone number."
);
$.validator.addMethod("requiredTags", function(value) { //add custom method
    //Tags input plugin converts input into div having id #YOURINPUTID_tagsinput
    //now you can count no of tags
    return ($(".bootstrap-tagsinput").find(".tag").length > 0 || $(".bootstrap-tagsinput input").val().length > 0);
}, "This field is required.");
$.validator.addMethod("validTags", function(value) {
  var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return (!$('.bootstrap-tagsinput input').val().toLowerCase().length && re.test($('.bootstrap-tagsinput .tag').last().text().toLowerCase())) || re.test($('.bootstrap-tagsinput input').val().toLowerCase()); 
}, "Please insert a correct email format.");

$.validator.setDefaults({
  highlight: function(element) {
    if ($(element).is('select')) {
      $(element).parent().find('.btn-default').addClass('selectError');
    } else {
      $(element).closest('.form-group').addClass('has-error');
    }
  },
  unhighlight: function(element) {
    if ($(element).is('select')) {
      $(element).parent().find('.btn-default').removeClass('selectError');
    } else {
      $(element).closest('.form-group').removeClass('has-error');
    }
  },
  errorElement: 'span',
  errorClass: 'help-block',
  errorPlacement: function(error, element) {
    if (element.attr('type') === 'checkbox' || element.attr('type') === 'radio') {
      error.insertAfter(element.closest('.form-group').find('label'));
    } else if (element.parent('.input-group').length) {
      error.insertAfter(element.parent());
    } else if ($(element).is('select')) {
      element.next().after(error); // special placement for select elements
    } else if ($(element).is('textarea')) {
      element.parent().find('.cke').after(error);
    }
    else {
      error.insertAfter(element);
    }
  }
});
// form validation rules (by the name tag)
function validateForm(formObj) {
  var jvalidate = formObj.validate({
    ignore: [],
    rules: {
      // Individual info
      firstName: {
        required: true,
      },
      lastName: {
        required: false,
      },
      email: {
        required: true,
        email: true,
      },
      contactPhone: {
        required: true,
        phoneNumber: true
      },
      website: {
        required: true,
        url: true
      },

      // Company Info
      companyName: {
        required: true,
        maxlength: 100
      },
      address: {
        maxlength: 100
      },
      city: {
        maxlength: 100
      },
      state: {
        maxlength: 100
      },
      postcode: {
        number: true
      },
      businessPhone: {
        required: true,
        phoneNumber: true
      },
      companyContactPhone: {
        required: true,
        phoneNumber: true,
      },
      businessWebsite: {
        required: true,
        url: true,
      },

      // Share Funnel
      funnelName: {
        required: true,
      },
      emailSubject: {
        required: true,
      },
      shareWith: {
        "requiredTags": true,
        "validTags": true,
      },
      emailBody: {
        required: function() {
          CKEDITOR.instances.emailBody.updateElement();
        },
        minlength: 1
      }
    },
    messages: {
    }
  });
}

//Toggle Individual/Company tab
$('.samewidthx span').click(function() {
  if(!$(this).hasClass('active')) {
    $(this).addClass('active');
    if($(this).hasClass('local')) {
      $('.online').removeClass('active');
      $('#individualForm').show();
      $('#companyForm').hide();
    } else {
      $('.local').removeClass('active');
      $('#companyForm').show();
      $('#individualForm').hide();
    }
  } 
});

// any form that has a button with id nextBtn, will be validated and submitted. maybe too generic!
$(document).on('click', '.nextBtn', function(ev) {
  ev.preventDefault();
  var formObj;
  if($('.toggleStyle .local').hasClass('active')) {
    formObj = $("#individualForm");
  } else {
    formObj = $("#companyForm");
  }
  validateForm(formObj);
  if (formObj.valid() === true) {
  } else {
    // do not submit untill errors are corrected
  }
});

// Analytics Code Clipboard
// Copy js Button
var clipboard = new Clipboard('#copyCodeBtn');
  clipboard.on('success', function(e) {
    e.clearSelection();
    copySuccess ();
});
// Success Function to Show the Top Right Success Notification After Copying
function copySuccess () {
  var naughty = noty({
    text: 'Analytics Code Copied to Clipboard Successfully',
    layout: 'topRight',
    type: 'success',
    timeout: 1000
  });
}

$(document).ready(function() {
  // init sharedFunnels Table
  var sharedFunnelsTable = $('#sharedFunnels').DataTable({
    searching: true,
    "bSort": false,
    lengthChange: false,
    pageLength: 5,
    paging: true,
    info: true,
    autoWidth: false,
    dom: 'tip',
    'language': {
      "info": "Showing _START_-_END_ of <b>_TOTAL_</b>",
      "paginate": {
        "first": "<",
        "last": ">",
        "next": "<span>Next</span><i class='fa fa-chevron-right' aria-hidden='true'></i>",
        "previous": "<i class='fa fa-chevron-left' aria-hidden='true'> </i><span>Back</span> ",
      },
    },
    "columns": [
      {"width": "11%"},
      {"width": "57%"},
      {"width": "21%"},
      {"width": "11%"},
    ]
  });

  var emailsTable = $('#emails').DataTable({
    "scrollY": "220px",
    searching: false,
    "bSort": false,
    lengthChange: false,
    paging: false,
    info: false,
    autoWidth: false,

    "columns": [
      {"width": "5%"},
      {"width": "20%"},
      {"width": "70%"},
      {"width": "5%"},
    ]
  });

  // Make index column for emails table
  emailsTable.column(0, {search:'applied'}).nodes().each( function (cell, i) {
    cell.innerHTML = i+1;
  }).draw();

  // Redraw email table for fitting header width when modal is shown
  $('#funnelSharingInfoModal').on('shown.bs.modal', function(){
    emailsTable.draw();
  });

  // Search function
  $('.searchWrapper input').on('keyup', function() {
    sharedFunnelsTable.search(this.value).draw();
  });

  CKEDITOR.config.allowedContent = true;
  // Setup CKEditor
  CKEDITOR.replace('emailBody', {
    height:258,
  });
  $(document).on("click", ".popover-content a", function () {
      // here get the value that user clicked on it in popover
      myValue = '<span style="color: #3598db;">' + "[" + $(this).text() + "]" + '</span>';
      CKEDITOR.instances['emailBody'].insertHtml(myValue);
      $('.token a').popover('hide');
  });
})

//validate select fields on change
$(document).on('change', 'select', function() {
  if($(this).val()!=""){
    var Wrapper = $(this).parent();
    Wrapper.find(".help-block").hide();
    Wrapper.find(".selectError").removeClass("selectError");
  }
});

// Validate email address format before adding
$('input.tag-box').on('itemAdded', function(event) {
  // event.item: contains the item
  var Wrapper = $(this).closest('.form-group');
  var tagItem = event.item;
  // var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  // if(!re.test(String(event.item).toLowerCase())) {
  //   Wrapper.removeClass("has-error").addClass("has-error");
  //   if(!Wrapper.find(".help-block").length){
  //     $('<span id="shareWith-error" class="help-block">Please insert a correct email format.</span>').insertAfter($(this));
  //   } else {
  //     Wrapper.find(".help-block").show();
  //     Wrapper.find(".help-block").html("Please insert a correct email format.");
  //   }
  //   $(this).tagsinput('remove', tagItem);
  //   setTimeout(function() {$('.bootstrap-tagsinput input').val(tagItem); $('.bootstrap-tagsinput input').attr('size', tagItem.length)}, 100);

  // } else {
  //   Wrapper.find(".help-block").hide();
  //   Wrapper.removeClass("has-error");
  // }
  var validator = $('#saveTemplateForm').validate({
    ignore: [],
    rules: {
      // Share Funnel
      funnelName: {
        required: true,
      },
      emailSubject: {
        required: true,
      },
      shareWith: {
        "requiredTags": true,
        "validTags": true,
      },
      emailBody: {
        required: function() {
          CKEDITOR.instances.emailBody.updateElement();
        },
        minlength: 1
      }
    },
  });
  if(!validator.element('.tag-box')) {
    $(this).tagsinput('remove', tagItem);
    setTimeout(function() {$('.bootstrap-tagsinput input').val(tagItem); $('.bootstrap-tagsinput input').attr('size', tagItem.length)}, 50);
  }
});

// Validate tags input field on change
$('input.tag-box').on('itemAdded', function(event) {
  // event.item: contains the item
  // var Wrapper = $(this).closest('.form-group');
  // Wrapper.find(".help-block").hide();
  // Wrapper.removeClass("has-error");
});


// Show Share Funnels page
$('.share-btn').on('click', function() {
  $('#mainPage').toggle();
  $('#shareFunnelPage').toggle();
  $('body').toggleClass('sfm-opened');
})

$('.snf-btn').on('click', function() {
  $('#mainPage').toggle();
  $('#shareFunnelPage').toggle();
  $('body').toggleClass('sfm-opened');
})

// Hide Share Funnels page
$('.send-btn').on('click', function(e) {
  e.preventDefault();
  var formObj= $("#saveTemplateForm");
  setTimeout(validateForm(formObj), 200);
  if (formObj.valid() === true) {
    $('#mainPage').toggle();
    $('#shareFunnelPage').toggle();
    $('body').toggleClass('sfm-opened');
    formObj.submit();
  }
})

// Notification for resending invitation
$('#funnelSharingInfoModal .resend-btn').on('click', function(e) {
  var naughty = noty({
    text: 'Email Has Been Resent Successfully',
    layout: 'topRight',
    type: 'success',
    timeout: 1000
  });
})

// Hide Save As Template Page
$('#shareFunnelPage .backBtn').click(function() {
  $('#mainPage').toggle();
  $('#shareFunnelPage').toggle();
  $('body').toggleClass('sfm-opened');
})

$('.token a').popover({
  html: true,
  content: function () {
    return $('#token').html();
  }
});