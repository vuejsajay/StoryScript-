// ---------------------- media popup and cropper code -------------------------------\\
function brandingCropper(url,ratio,minW,minH) {
	$('#cropper-popup').modal();
	$('#cropper-popup').on('shown.bs.modal', function () {
		$('.croppImgLogo').cropper('destroy');
		$('.croppImgLogo').attr('src', "");
		$('.croppImgLogo').attr('src',url );
		$('.croppImgLogo').cropper({
			aspectRatio: ratio,
			strict: true,
			guides: true,
			highlight: true,
			dragCrop: true,
			cropBoxMovable: true,
			cropBoxResizable: true,
			autoCrop: true,
			rotatable: true,
			minCropBoxWidth: minW,
			minCropBoxHeight: minH
		});
	}).on('hidden.bs.modal', function () {
		$('.ratio-action').show();
	});

}

function getCropped(val,type){
 $("#prevImg").attr('src',val);
	$('#cropper-popup').modal('hide');
}

var croppedImg;

$('#cropper-popup').on('hidden.bs.modal', function () {
	$('.croppImgLogo').cropper('destroy');
	$('.croppImgLogo').attr('src','http://placehold.it/322x190');
});

var $actions =  $(".crop-actions");
var $image = $('.croppImgLogo');
// Methods

// Methods
$actions.on('click', '[data-method]', function () {
	var $this = $(this);
	var data = $this.data();
	var $target;
	var result;

	if ($this.prop('disabled') || $this.hasClass('disabled')) {
		return;
	}

	if ($image.data('cropper') && data.method) {
		data = $.extend({}, data); // Clone a new one

		if (typeof data.target !== 'undefined') {
			$target = $(data.target);

			if (typeof data.option === 'undefined') {
				try {
					data.option = JSON.parse($target.val());
				} catch (e) {
					console.log(e.message);
				}
			}
		}
		mm= data;
		result = $image.cropper(data.method, data.option, data.secondOption);

		if (data.flip === 'horizontal') {
			$(this).data('option', -data.option);
		}

		if (data.flip === 'vertical') {
			$(this).data('secondOption', -data.secondOption);
		}

		if (data.method === 'getCroppedCanvas' && result) {
			getCropped(result.toDataURL(),croppedImg);
		}

		if ($.isPlainObject(result) && $target) {
			try {
				$target.val(JSON.stringify(result));
			} catch (e) {
				console.log(e.message);
			}
		}
	}
});

// get clicks on the save button in the cropper modal
$('#cropper-save').click(function(){
	// check if the cropper is launched from within the thumbnail images
	if (thumbnailEdit) {
		// get latest cropped image
		var cropcanvas = $('.croppImgLogo').cropper('getCroppedCanvas');
		// get the encoded image from the canvas, decode it using php, upload it to the server under [/cropped] folder
		var photo = cropcanvas.toDataURL();
		$.ajax({
  		method: 'POST',
  		url: 'upload_cropped.php',
  		data: {
    		photo: photo
  		},
			success: function(data){
				// if upload is successful, update thumbnail, and update modal preview image
				// update thumbnail on page
				var str = '<img class="thumb-img" src=' + data + '>';
				$(clickedCustomThumbBtn).parent().find('.thumbs-list').append(str);
				funnelDiagram.model.setDataProperty(editingNode.data, 'screenshot', data);
				if((editingNode.category == "action-card" || editingNode.category == "traffic-card")) {
					funnelDiagram.startTransaction("change layout");
					if(cropcanvas.width != cropcanvas.height) {
						editingNode.findObject("border").desiredSize = new go.Size(180, 230);
						editingNode.findObject("screenshot").desiredSize = new go.Size(120,140);
						editingNode.findObject("plus-btn-panel").position = new go.Point(133, 70);
					} else {
						editingNode.findObject("border").desiredSize = new go.Size(120, 150);
						editingNode.findObject("screenshot").desiredSize = new go.Size(60, 60);
						editingNode.findObject("plus-btn-panel").position = new go.Point(72, 30);
					}
					if(cropcanvas.width != cropcanvas.height) {
						$(clickedCustomThumbBtn).parent().find('.thumbs-list').find('.thumb-img').last().addClass("6*7");
					}
					funnelDiagram.commitTransaction("change layout");
					settingMenu.css({left: funnelDiagram.transformDocToView(editingNode.location).x + editingNode.actualBounds.width / 2 * funnelDiagram.scale - $(settingMenu).width() / 2});
	  			settingMenu.css({top: funnelDiagram.transformDocToView(editingNode.location).y + editingNode.actualBounds.height * funnelDiagram.scale + 10});
				}
			}
		});
	}
});
