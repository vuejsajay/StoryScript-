var textCardTemplate = 
  $$(go.Node, "Viewbox",
    {
      name: "text-card",
      cursor: "pointer",
      selectionAdorned: true,
      resizable: true,
      selectionChanged: function(n) {
        if(n.isSelected && !$('.multiselect-btn').hasClass('active')) {
          onClickSettingPage(n);
        }
      }
    },
    new go.Binding("key", "key"),
    new go.Binding("location", "loc", go.Point.parse).makeTwoWay(go.Point.stringify),
    $$(go.Panel, "Auto",
      $$(go.Shape, "RoundedRectangle",
        {
          name: "border",
          fill: "transparent", stroke: null,
          toLinkable: true, portId: '',
          parameter1: 5,
          strokeWidth: 3,
        }
      ),
      $$(go.TextBlock,
        {
          name: "text-content",
          font: "bold 14px Open Sans, sans-serif",
          stroke: "black",
          text: 'Add A Text Note In Here',
          shadowVisible: false,
          maxSize: new go.Size(326, NaN),
          margin: 20,
          editable: true,
          textAlign: "center"
        },
        new go.Binding("text", "text").makeTwoWay(),
      ),
    )
  ); // end Node
