﻿<!DOCTYPE html>
<html lang="en" class="body-full-height">
<head>
  <!-- META SECTION -->
  <title>Funnel Map - Login</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="icon" href="assets/img/funnel-map-icon.png" type="image/x-icon" />
  <!-- END META SECTION -->

  <!-- CSS INCLUDE -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" id="theme" href="assets/libs/css/theme-default.css"/>
  <!-- EOF CSS INCLUDE -->
  <!-- CUSTOM CSS -->
  <link rel="stylesheet" type="text/css" id="theme" href="assets/css/login-css/login-page-style.css"/>
</head>
<body>
  <div class="login-container">
    <div class="login-box animated text-center fadeInDown">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-md-push-6 no-mobile-padding">
            <div class="main-login-container">
              <div class="logo-body">
                <img class="logo-img" src="assets/img/logo-lr.png" alt="">
              </div>
              <div class="login-body login-form-container">
                <div class="login-title"><strong>Welcome</strong>, Please login</div>
                  <!--We have change the method for demostration-->
                <form id="validate" action="admin/welcome-wizard/step2.php" class="form-horizontal"  method="get" >
                  <div class="form-group">
                    <div class="col-md-12">
                      <a class="btn btn-info btn-block fb-button"><i class="fa fa-facebook"></i> LOGIN WITH FACEBOOK</a>
                    </div>
                  </div>
                  <div class="loginOr">
                    <div class="col-xs-12">
                      <hr class="hrOr">
                      <span class="spanOr">OR</span>
                    </div>
                  </div>
                  <div class="form-group" style="display: none">
                    <div class="col-md-12">
                      <div class="alert alert-danger" role="alert"><i class="fa fa-times"></i> Incorrect Login</div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-md-12">
                      <input type="email" class="validate[required,email] form-control" placeholder="Username"/>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-md-12">
                      <input type="password" class="validate[required,minSize[1]] form-control" placeholder="Password"/>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-md-12">
                      <button class="btn btn-info btn-block blue-button"><i class="fa fa-lock fa-fw"></i> Log In</button>
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-sm-6">
                      <a href="reset-pass-page.php" class="forget-pass-btn text-left">Forgot Your Password?</a>
                    </div>
                    <div class="col-sm-6">
                      <a href="signup.php" class="forget-pass-btn text-right">Create A New Account!</a>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-md-pull-6 no-mobile-padding">
            <div class="ad-container">
              <div class="login-body ad">
                <a href="#"><img src="assets/img/Prospect-Rocket.png" alt=""></a>
              </div>
            </div>
          </div>
          <div class="col-md-12">
            <div class="login-footer">
              <hr>
              <div class="text-center footet-text">
                  <p>
                      &copy; <strong>2019 Funnel Maps <sup>tm</sup></strong> - All Rights Reserved, Product Of <strong>Strategic Marketer</strong><br>
                      Click Here For <strong><a href="http://lmgsupport.com/" target="_blank">SUPPORT</a></strong>
                  </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- START SCRIPTS -->
  <!-- START PLUGINS -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <script type='text/javascript' src='assets/libs/js/validationengine/languages/jquery.validationEngine-en.js'></script>
  <script type='text/javascript' src='assets/libs/js/validationengine/jquery.validationEngine.js'></script>
  <script type='text/javascript' src='assets/libs/js/jquery-validation/jquery.validate.js'></script>
  <!-- END PLUGINS -->

  <!-- START TEMPLATE -->
  <script type="text/javascript" src="assets/js/plugins.js"></script>
  <!-- END TEMPLATE -->
</body>
</html>
