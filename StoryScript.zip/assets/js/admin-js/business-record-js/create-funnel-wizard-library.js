// Display help video when click help video btn
$(".help-video-container").click(function() {
  $(".help-video-container .video-container").slideToggle();
  $(".help-video-container .line i:nth-child(n+2)").toggleClass("fa-caret-down").toggleClass("fa-caret-up");
});

// Init validator
$.validator.setDefaults({
  highlight: function(element) {
    if ($(element).is('select')) {
      $(element).parent().find('.btn-default').addClass('selectError');
    } else {
      $(element).closest('.form-group').addClass('has-error');
    }
  },
  unhighlight: function(element) {
    if ($(element).is('select')) {
      $(element).parent().find('.btn-default').removeClass('selectError');
    } else {
      $(element).closest('.form-group').removeClass('has-error');
    }
  },
  errorElement: 'span',
  errorClass: 'help-block',
  errorPlacement: function(error, element) {
    if (element.attr('type') === 'checkbox' || element.attr('type') === 'radio') {
      error.insertAfter(element.closest('.form-group').find('label'));
    } else if (element.parent('.input-group').length) {
      error.insertAfter(element.parent());
    } else if ($(element).is('select')) {
      element.next().after(error); // special placement for select elements
    } else {
      error.insertAfter(element);
    }
  }
});
function validateForm(formObj) {
  var jvalidate = formObj.validate({
    ignore: [],
    rules: {
      funnelMapName: {
        required: true,
      }
    },
    messages: {
      agreement1: "You Must Agree To The Terms Of Service"
    }
  });
}

// Init tags input
$('.form-group input.tag-box').tagsinput();

// Click next btn
$(document).on('click', '.nextBtn', function(e) {
  e.preventDefault();
  var formObj = $('#newFunnelMapForm');
  validateForm(formObj);
  if (formObj.valid() === true) {
    window.location.replace("../builder/map-builder-blank.php");
  } else {
    // do not submit untill errors are corrected
  }
});

//validate select fields on change
$(document).on('change', 'select', function() {
  if($(this).val()!=""){
    var Wrapper = $(this).parent();
    Wrapper.find(".help-block").hide();
    Wrapper.find(".selectError").removeClass("selectError");
  }
});

