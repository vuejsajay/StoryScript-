var trafficCardTemplate = 
  $$(go.Node, "Position",
    {
      name: "traffic-card",
      isShadowed: true,
      shadowOffset: new go.Point(0, 2),
      shadowBlur: 8,
      shadowColor: "rgba(0, 0, 0, 0.25)",
      cursor: "grab",
      selectionAdorned: true,
      selectionAdornmentTemplate:
        $$(go.Adornment, "Auto",
          { layerName: "Background" },
          $$(go.Shape, "RoundedRectangle",
          { fill: null, stroke: "rgb(204, 0, 0)", strokeWidth: 2, strokeDashArray: [12, 8], fill: "rgba(255,255,255,0.7)"}),
          $$(go.Placeholder)
        ),  // end Adornment
       selectionChanged: function(n) {
        if(n.isSelected && !$('.multiselect-btn').hasClass('active')) {
          n.findObject("connect-btn").visible = true;
          onClickSettingPage(n);
        } else if(!n.isSelected) {
          n.findObject("connect-btn").visible = false;
        }
      }
    },
    new go.Binding("key", "key"),
    new go.Binding("location", "loc", go.Point.parse).makeTwoWay(go.Point.stringify),
    $$(go.Shape, "Rectangle",
      {
        name: 'border',
        fill:"transparent", stroke: null,
        portId: '', toLinkable: true,
        desiredSize: new go.Size(120, 150),
      }
    ),
    $$(go.Panel, "Vertical",
      {name: "wrapper",position: new go.Point(2, 0)},
      $$(go.TextBlock,
        {
          name: "card-header", shadowVisible: false,
          textAlign: "center",
          maxLines: 2,
          desiredSize: new go.Size(114, 40),
          overflow: go.TextBlock.OverflowEllipsis,
          verticalAlignment: go.Spot.Bottom,
          font: "bold 13px Open Sans, sans-serif",
          editable: true,
          margin: new go.Margin(0,0,10,0),
          cursor: "text",
          textEdited: function(thisTextBlock, oldStr, newStr) {
            $('.traffic-setting-tab #itemName').val(newStr);
          },
          toolTip:                       // define a tooltip for each node
            $$(go.Adornment, "Spot",      // that has several labels around it
              { background: "transparent", shadowVisible: true },  // avoid hiding tooltip when mouse moves
              new go.Binding('visible', 'description', function(v) {
                if(v == undefined || v == '') return false;
                return true;
              }),
              $$(go.Placeholder, { padding: 10}),
              $$(go.Panel, "Vertical", 
                {alignment: go.Spot.Top,},
                $$(go.Panel, "Auto",
                  $$(go.Shape, "Rectangle",
                    {
                      stroke: "rgba(0,0,0,0.1)",
                      strokeWidth: 1,
                      fill: "white",
                    },
                  ),
                  $$(go.TextBlock,
                    {
                      margin: 10,
                      font: "bold 13px Open Sans, sans-serif",
                      shadowVisible: false,
                    },
                    new go.Binding("text", "description")
                  ),
                ),
                $$(go.Shape, "TriangleDown",
                  {
                      desiredSize: new go.Size(7, 7),
                      margin: new go.Margin(-3,0,0,0),
                      stroke: null,
                      fill: "white",
                  },
                ),
              ) 
            )  // end Adornment
        },
        new go.Binding("text", "cardTitle", function(t) {
          return t.substring(0, 25); 
        }).makeTwoWay(),
      ),
      
      $$(go.Panel, "Position",
        $$(go.Panel, "Auto",
          {name: "body", shadowVisible: true},
          $$(go.Shape, "RoundedRectangle", 
            { 
              name: "card-bg",
              stroke: "rgb( 1, 145, 159 )",
              strokeWidth: 2,
              strokeDashArray: [12, 8],       
              parameter1: 5, // border-radius: 5px;
              fill: "white",
              shadowVisible: true,
            },
          ),
          $$(go.Picture,
            {
              name: "screenshot",
              desiredSize: new go.Size(60, 60),
              imageStretch: go.GraphObject.Uniform,
              margin: new go.Margin(10, 10),
            },
            new go.Binding("source", "screenshot"),
          ),
        ), //end BODY
        $$(go.Panel, "Auto",
          {
            name: "plus-btn-panel",
            position: new go.Point(72,35), 
            desiredSize: new go.Size(30,30),
            cursor: "pointer",
            click: function(e, obj) {
              onClickDraw(obj);
            }
          },
          $$(go.Shape, {fill:"transparent", stroke: null}),
          $$(go.Panel, "Auto",
            { name: "connect-btn"},
            $$(go.Shape, {stroke: null, fill: "transparent"}),
            $$(go.Shape, "Circle",
              {desiredSize: new go.Size(30,30), stroke: null, fill: "white" }
            ),
            $$(go.Shape, "Circle",
              {name: "btn-fg", desiredSize: new go.Size(24,24), stroke: null, fill: "rgb(2, 145, 159)" }
            ),
            $$(go.Shape, "PlusLine",
              {
                name: "plus-line",
                desiredSize: new go.Size(12,12),
                stroke: "white",
                strokeWidth: 2,
                visible: true,
              })
          ),
        ),
        $$(go.Panel, "Auto",
          {
            position: new go.Point(-15,35), 
            desiredSize: new go.Size(30,30),
          },
        ),
      ),
      $$(go.Panel, "Auto",
        { 
          name: "info-panel",
          cursor: "pointer",
          toolTip:                       // define a tooltip for each node
            $$(go.Adornment, "Spot",      // that has several labels around it
              { background: "transparent",},  // avoid hiding tooltip when mouse moves
              // new go.Binding('visible', 'description', function(v) {
              //   if(v == undefined || v == '') return false;
              //   return true;
              // }),
              $$(go.Placeholder, { padding: 22}),
              $$(go.Panel, "Vertical",
                {alignment: go.Spot.Bottom, shadowVisible: true},
                $$(go.Shape, "TriangleUp",
                  {
                    desiredSize: new go.Size(7, 7),
                    stroke: null,
                    fill: "white",
                    isPanelMain: false,
                    margin: new go.Margin(0, 0, -2, 0),
                  },
                ),
                $$(go.Panel, "Auto",
                  {isPanelMain: true},
                  $$(go.Shape, "Rectangle",
                    {
                      stroke: null,
                      fill: "white",
                    },
                  ),
                  $$(go.TextBlock,
                    {
                      margin: 10,
                      font: "bold 13px Open Sans, sans-serif",
                      shadowVisible: false,
                      text: "Views",
                    },
                    new go.Binding("text", "infoText")
                  ),
                ),
              )
            )  // end Adornment
        },
        new go.Binding("visible", "isLive").ofModel(),
        $$(go.Shape, "Circle",
          {
            desiredSize: new go.Size(50,50),
            shadowVisible: false,
            strokeWidth: 2,
            stroke: "white",
            fill: "#018f9d",
            margin: new go.Margin(-25, 0, 0, 0)
          }),
        $$(go.TextBlock,
          {
            font: "bold 13px Open Sans, sans-serif",
            text: "100",
            stroke: "white",
            margin: new go.Margin(20, 0, 0, 0)
          },
          new go.Binding("text", "infoText"),
        )
      )
    ),
  ); // end Node