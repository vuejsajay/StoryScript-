var pageCardTemplate = 
  $$(go.Node, "Position",
    {
      name: "page-card",
      isShadowed: true,
      shadowOffset: new go.Point(0, 2),
      shadowBlur: 8,
      shadowColor: "rgba(0, 0, 0, 0.25)",
      selectionAdorned: true,
      // width: 181, // ~ 159(width of card) + 7.5(radius of red toPort) + 14(radius of expanded blue fromPort)
      cursor: "grab",
      selectionAdornmentTemplate:
        $$(go.Adornment, "Auto",
          { layerName: "Background" },
          $$(go.Shape, "RoundedRectangle",
          { fill: null, stroke: "rgb(204, 0, 0)", strokeWidth: 2, strokeDashArray: [12, 8], fill: "rgba(255,255,255,0.7)"}),
          $$(go.Placeholder)
        ),  // end Adornment
      selectionChanged: function(n) {
        if(n.isSelected && !$('.multiselect-btn').hasClass('active')) {
          n.findObject("connect-btn").visible = true;
          onClickSettingPage(n);
        } else if(!n.isSelected) {
          n.findObject("connect-btn").visible = false;
        }
      }
    },
    new go.Binding("key", "key"),
    new go.Binding("location", "loc", go.Point.parse).makeTwoWay(go.Point.stringify),
    $$(go.Shape, "Rectangle",
      {
        name: 'border',
        fill:"transparent", stroke: null, 
        toLinkable: true, portId: '',
        desiredSize: new go.Size(180, 230),
      },
    ),
    $$(go.Panel, "Vertical",
      {name: "wrapper", position: new go.Point(2, 0)},
      $$(go.TextBlock,
        {
          name: "card-header", shadowVisible: false,
          desiredSize: new go.Size(141, 35),
          overflow: go.TextBlock.OverflowEllipsis,
          verticalAlignment: go.Spot.Bottom,
          textAlign: "center",
          maxLines: 2,
          font: "bold 13px Open Sans, sans-serif",
          editable: true,
          margin: new go.Margin(0,0,10,0),
          cursor: "text",
          textEdited: function(thisTextBlock, oldStr, newStr) {
            $('.page-setting-tab #pageName').val(newStr);
          },
          toolTip:                       // define a tooltip for each node
            $$(go.Adornment, "Spot",      // that has several labels around it
              { background: "transparent", shadowVisible: true },  // avoid hiding tooltip when mouse moves
              new go.Binding('visible', 'description', function(v) {
                if(v == undefined || v == '') return false;
                return true;
              }),
              $$(go.Placeholder, { padding: 10}),
              $$(go.Panel, "Vertical", 
                {alignment: go.Spot.Top,},
                $$(go.Panel, "Auto",
                  $$(go.Shape, "Rectangle",
                    {
                      stroke: "rgba(0,0,0,0.1)",
                      strokeWidth: 1,
                      fill: "white",
                    },
                  ),
                  $$(go.TextBlock,
                    {
                      margin: 10,
                      font: "bold 13px Open Sans, sans-serif",
                      shadowVisible: false,
                    },
                    new go.Binding("text", "description")
                  ),
                ),
                $$(go.Shape, "TriangleDown",
                  {
                      desiredSize: new go.Size(7, 7),
                      margin: new go.Margin(-3,0,0,0),
                      stroke: null,
                      fill: "white",
                  },
                ),
              ) 
            )  // end Adornment
        },
        new go.Binding("text", "cardTitle", function(t) {
          return t.substring(0, 25); 
        }).makeTwoWay(),
      ),
      $$(go.Panel, "Position",
        $$(go.Panel, "Auto",
          {name: "body",},
          $$(go.Shape, "RoundedRectangle", 
            { 
              name: "card-bg",
              stroke: "rgb(53, 152, 219)",
              strokeWidth: 2,
              strokeDashArray: [12, 8],
              parameter1: 5, // border-radius: 5px;
              fill: "white",
              shadowVisible: true,
            },
          ),
          $$(go.Panel, "Auto",
            {
              name: "screenshot-panel",
              margin: 10,
            },
            $$(go.Panel, "Auto",
              { name: "screenshot-pic-panel"},
              $$(go.Shape, "RoundedRectangle",
                {
                  name: "screenshot-border",
                  strokeWidth: 1,
                  stroke: "rgb(243,243,243)",
                  fill: "rgb(255,255,255)",
                  parameter1: 2,
                  desiredSize: new go.Size(120, 140),
                }),
              $$(go.Picture,
                {
                  name: "screenshot",
                  desiredSize: new go.Size(120, 140),
                },
                new go.Binding("source", "screenshot"),
              ),
            ),
          ),
        ), //end BODY
        $$(go.Panel, "Auto",
          {
            position: new go.Point(133,70), 
            desiredSize: new go.Size(30,30),
            cursor: "pointer",
            click: function(e, obj) {
              onClickDraw(obj);
            }
          },
          $$(go.Shape, {fill:"transparent", stroke: null}),
          $$(go.Panel, "Auto",
            {name: "connect-btn", visible: false},
            $$(go.Shape, {stroke: null, fill: "transparent"}),
            $$(go.Shape, "Circle",
              {desiredSize: new go.Size(30,30), stroke: null, fill: "white",}
            ),
            $$(go.Shape, "Circle",
              {name: "btn-fg", desiredSize: new go.Size(24,24), stroke: null, fill: "rgb(53, 152, 219)" }
            ),
            $$(go.Shape, "PlusLine",
              {
                name: "plus-line",
                desiredSize: new go.Size(12,12),
                stroke: "white",
                strokeWidth: 2,
                visible: true,
              })
          )
        ),
        $$(go.Panel, "Auto",
          {
            position: new go.Point(-15,70), 
            desiredSize: new go.Size(30,30),
          },
        ),
      )
    )
  ); // end Node

