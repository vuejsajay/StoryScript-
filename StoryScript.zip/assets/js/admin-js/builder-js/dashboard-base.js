
const $$ = go.GraphObject.make;  // for conciseness in defining templates
var funnelDiagram;

var Themes = {
  BLUE : "rgb(53, 152, 219)",
  BLUE_STR : "blue",

  GREY : "rgb( 153, 153, 153 )",
  GREY_STR : "grey",

  RED : "rgb( 179, 0, 0 )",
  RED_STR : "red",

  TEAL : "rgb( 1, 145, 159 )",
  TEAL_STR : "teal",

  PURPLE : "rgb( 108, 81, 126 )",
  PURPLE_STR : "purple",

  ORANGE : "rgb( 254, 154, 30 )",
  ORANGE_STR : "orange",

  GREEN: "rgb( 37, 170, 115)",
  GREEN_STR : "green",  
};

var colorNames = {
  "rgb(53, 152, 219)": "blue",
  "rgb( 153, 153, 153 )": "grey",
  "rgb( 179, 0, 0 )": "red",
  "rgb( 1, 145, 159 )": "teal",
  "rgb( 108, 81, 126 )": "purple",
  "rgb( 254, 154, 30 )": "orange",
  "rgb( 37, 170, 115)": "green",
};


//easing function for zoom animation
function ease(t, b, c, d){
  t /= (d / 2);
  if (t < 1) return c / 2 * t * t + b;
  return -c / 2 * ((--t) * (t - 2) - 1) + b;
}

//zoom function
function zoom(factor) {
  var duration = funnelDiagram.animationManager.duration;
  var start = +new Date();
  var finish = start + duration;
  var newScale = funnelDiagram.scale * factor;
  var oldScale = funnelDiagram.scale;

  var $this = this;
  function zoomTick() {
    var time = +new Date();
    var currentTime = time > finish ? duration : (time - start);
    funnelDiagram.scale = $this.ease(currentTime, oldScale, newScale - oldScale, duration);
    if (time > finish) { return;} 
    window.requestAnimationFrame(zoomTick);
  }
  window.requestAnimationFrame(zoomTick);
}

// Zoom in
function onClickZoomIn() {
  zoom(1.2);
}

// Zoom out 
function onClickZoomOut() {
  zoom(0.8);
}