<!DOCTYPE html>
<html lang="en">

<head>
	<title>Summary</title>

	<!-- INCLUDE HEAD -->
  <?php include('layout/head.php'); ?>

	<!-- CSS PLUGINS FOR THIS PAGE -->
  <link href="https://cdn.jsdelivr.net/bootstrap.tagsinput/0.8.0/bootstrap-tagsinput.css" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" id="theme" href="../../assets/libs/css/spectrum.css" />
  <link href="../../assets/libs/css/cropper.css" rel="stylesheet">

	<!-- CSS FOR THIS PAGE ONLY -->
	<link href="../../assets/css/admin-css/builder-css/upload-demo.css" rel="stylesheet" />
	<link href="../../assets/css/admin-css/welcome-wizard-css/welcome-wizard.css" rel="stylesheet" />
	<link href="../../assets/css/admin-css/business-record-css/business-record-base.css" rel="stylesheet" />
	<link href="../../assets/css/admin-css/business-record-css/summary.css" rel="stylesheet" />
</head>

<body>
	<!-- START PAGE CONTAINER -->
	<div class="page-container page-navigation-top" id="mainPage">
		<!-- PAGE CONTENT -->
		<div class="page-content">
			
			<!--INCLUDE HEADER -->
	    <?php include('layout/header.php'); ?>
			
			<!-- PAGE CONTENT WRAPPER -->
			<div class="page-content-wrap">
				
				<div class="wrapper">
					
					<!--INCLUDE NAVIGATION -->
	        <?php $headerActiveItem = 'summary'; //set navigation active item ?>
	        <?php include('layout/navigation.php'); ?>
					
					<div class="tab-content first-level">
						<div id="summary" class="tab-pane zoomIn active">
							
							<div class="row">
								
								<!-- BEGIN High Converting Sales Funnels -->
								<div class="col-md-8 no-padding-left">
									<div class="item-container high-sales-funnels">
										<div class="container-heading">
											<img class="logo-icon" src="../../assets/img/funnel-map-icon.png" alt="" />
											Learn About These High Converting Sales Funnels
										</div>
										
										<?php
											//List with items
											$highConvertingSalesFunnels = [
												[
													'type'	=> 'optin',
													'image'	=> '../../assets/img/optin-funnel.png',
													'title'	=> 'Optin Funnel Name Goes Here 2 Lines',
													'icon'	=> '../../assets/img/funnel-icons/white/optin-funnel.png'
												],
	                      [
	                        'type'	=> 'sales',
	                        'image'	=> '../../assets/img/sales-funnel.png',
	                        'title'	=> 'Sales Funnel Name Goes Here 2 Lines',
	                        'icon'	=> '../../assets/img/funnel-icons/white/sales-funnel.png'
	                      ],
	                      [
	                        'type'	=> 'upsell',
	                        'image'	=> '../../assets/img/upsell-funnel.png',
	                        'title'	=> 'Upsell Funnel Name Goes Here 2 Lines',
	                        'icon'	=> '../../assets/img/funnel-icons/white/upsell-funnel.png'
	                      ],
	                      [
	                        'type'	=> 'optin',
	                        'image'	=> '../../assets/img/optin-funnel.png',
	                        'title'	=> 'Optin Funnel Name Goes Here 2 Lines',
	                        'icon'	=> '../../assets/img/funnel-icons/white/optin-funnel.png'
	                      ],
	                      [
	                        'type'	=> 'sales',
	                        'image'	=> '../../assets/img/sales-funnel.png',
	                        'title'	=> 'Sales Funnel Name Goes Here 2 Lines',
	                        'icon'	=> '../../assets/img/funnel-icons/white/sales-funnel.png'
	                      ],
	                      [
	                        'type'	=> 'upsell',
	                        'image'	=> '../../assets/img/upsell-funnel.png',
	                        'title'	=> 'Upsell Funnel Name Goes Here 2 Lines',
	                        'icon'	=> '../../assets/img/funnel-icons/white/upsell-funnel.png'
	                      ]
											];
										?>
										
										<div class="row no-padding">
											
											<?php foreach( $highConvertingSalesFunnels as $funnel ){ ?>
												<div class="col-xs-4 p-10">
													<div class="banner-item <?php echo $funnel['type']; ?>">
														<div class="img-overlay animated fadeIn">
															<a class="button preview-button" href="view-funnel.php">
																<img src="../../assets/img/eye-preview.png" alt="" />View This Funnel
															</a>
														</div>
														<div class="square-content">
															<div class="content-inside">
																<img class="img-responsive" src="<?php echo $funnel['image']; ?>" alt="" />
															</div>
															<div class="top-title">
																<div class="funnel-icon">
																	<img src="<?php echo $funnel['icon']; ?>" alt="" />
																</div>
																<span><?php echo $funnel['title']; ?>"</span>
															</div>
														</div>
													</div>
												</div>
											<?php } ?>
											
										</div>
									</div>
								</div>
								<!-- END High Converting Sales Funnels -->
								
								<!-- BEGIN BOX INFO AND SLIDE -->
								<div class="col-md-4 no-padding-right">
									<ul class="account-info">
										<li class="name">
											<i class="fa fa-suitcase"></i><span class="name-span">David Smith Long Name Goes Here</span>
										</li>
										<li><i class="fa fa-user"></i><b>Account:</b> Marketer</li>
										<li><i class="fa fa-desktop"></i>Get A Funnel Coach</li>
									</ul>
									
									<ul id="slides">
										<li class="slide showing">
											<a href='#' target="_blank"><img src="../../assets/img/funnel-pages.png"></a>
										</li>
										<li class="slide">
											<a href='#' target="_blank"><img src="../../assets/img/BoostWebinars.png"></a>
										</li>
										<li class="slide">
											<a href='#' target="_blank"><img src="../../assets/img/Lead-Kahuna.png"></a>
										</li>
										<li class="slide">
											<a href='#' target="_blank"><img src="../../assets/img/Prospect-Rocket.png"></a>
										</li>
										<li class="slide">
											<a href='#' target="_blank"><img src="../../assets/img/RepKahuna.png"></a>
										</li>
									</ul>
								</div>
								<!-- END BOX INFO AND SLIDE -->
							</div>
							
							<!-- BEGIN LATEST FUNNEL -->
							<div class="row latest-funnels">
								<div class="lf-heading">
									<span>
										<img class='normal-icon logo-icon' src="../../assets/img/funnel-map-icon.png" alt="" />Latest Funnels
									</span>
									<a class="pull-right" href="funnel-library.php#myFunnels">
										<img src="../../assets/img/eye-preview.png" alt="" /> All Funnels
									</a>
								</div>
								
								<div class="row lf-content">
									<div class="row with-funnels">
										
	                  <?php
											//List with items
											$latestFunnels  = [
												[
													'type'	=> 'brand',
													'image'	=> '../../assets/img/optin-funnel-normal-thumb.png',
													'title'	=> 'Brand site Funnel Name Goes Here 2 Lines',
													'icon'	=> '../../assets/img/funnel-icons/white/brandsite-funnel.png'
												],
	                      [
	                        'type'	=> 'optin',
	                        'image'	=> '../../assets/img/optin-funnel-normal-thumb.png',
	                        'title'	=> 'Optin Funnel Name Goes Here 2 Lines',
	                        'icon'	=> '../../assets/img/funnel-icons/white/optin-funnel.png'
	                      ],
	                      [
	                        'type'	=> 'sales',
	                        'image'	=> '../../assets/img/optin-funnel-normal-thumb.png',
	                        'title'	=> 'Sales Funnel Name Goes Here 2 Lines',
	                        'icon'	=> '../../assets/img/funnel-icons/white/sales-funnel.png'
	                      ],
	                      [
	                        'type'	=> 'upsell',
	                        'image'	=> '../../assets/img/optin-funnel-normal-thumb.png',
	                        'title'	=> 'Upsell Funnel Name Goes Here 2 Lines',
	                        'icon'	=> '../../assets/img/funnel-icons/white/upsell-funnel.png'
	                      ],
	                      [
	                        'type'	=> 'brand',
	                        'image'	=> '../../assets/img/optin-funnel-normal-thumb.png',
	                        'title'	=> 'Brand site Funnel Name Goes Here 2 Lines',
	                        'icon'	=> '../../assets/img/funnel-icons/white/brandsite-funnel.png'
	                      ],
	                      [
	                        'type'	=> 'optin',
	                        'image'	=> '../../assets/img/optin-funnel-normal-thumb.png',
	                        'title'	=> 'Optin Funnel Name Goes Here 2 Lines',
	                        'icon'	=> '../../assets/img/funnel-icons/white/optin-funnel.png'
	                      ],
	                      [
	                        'type'	=> 'sales',
	                        'image'	=> '../../assets/img/optin-funnel-normal-thumb.png',
	                        'title'	=> 'Sales Funnel Name Goes Here 2 Lines',
	                        'icon'	=> '../../assets/img/funnel-icons/white/sales-funnel.png'
	                      ],
	                      [
	                        'type'	=> 'upsell',
	                        'image'	=> '../../assets/img/optin-funnel-normal-thumb.png',
	                        'title'	=> 'Upsell Funnel Name Goes Here 2 Lines',
	                        'icon'	=> '../../assets/img/funnel-icons/white/upsell-funnel.png'
	                      ]
											];
	                  ?>
										
										<?php foreach($latestFunnels as $funnel){ ?>
											<div class="col-xs-3 p-10">
												<div class="banner-item normal-thumb <?php echo $funnel['type']; ?>">
													<div class="img-overlay animated fadeIn">
														<a class="button edit-funnel" href="../builder-pro/map-builder.php"><i class="fa custom-edit"></i>Edit Funnel</a>
														<div class="dropdown">
															<a class="button settings" data-toggle="dropdown"><span><i class="fa fa-gear"></i></span>Settings
																<div class="pull-right"><i class="fa fa-caret-down"></i></div>
															</a>
															<ul class="dropdown-menu animated fadeIn">
																<li class="sat-btn"><i class="fa fa-save"></i>Save As Template
																</li>
																<li><i class="fa fa-cloud-download"></i>Funnel Resources</li>
																<li><i class="fa fa-file-pdf-o"></i>Download As PDF</li>
																<li data-toggle='modal' data-target='#delete-modal'>
																	<i class="fa fa-times"></i>Delete Funnel
																</li>
															</ul>
														</div>
														<div class="funnel-elements-num" data-toggle="popover" data-trigger="hover" data-html="true" data-placement="top" data-container="body" data-content="Funnel Elements">
															<img src="../../assets/img/puzzle.png" alt="" /> 8
														</div>
													</div>
													
													
													<div class="square-content">
														<div class="left-bar"></div>
														<div class="content-inside">
															<img class="img-responsive" src="<?php echo $funnel['image']; ?>" alt="" />
														</div>
														<div class="top-title">
															<div class="funnel-icon">
																<img src="<?php echo $funnel['icon']; ?>" alt="" />
															</div>
															<span><?php echo $funnel['title']; ?></span>
														</div>
													</div>
												</div>
											</div>
										<?php } ?>
										
									</div>
								</div>
							</div>
							<!-- END LATEST FUNNEL -->
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- END PAGE CONTENT WRAPPER -->
	</div>
	<!-- END PAGE CONTAINER -->

	<?php include('modals/save-as-template.php'); ?>
	<?php include('modals/signout-message-box.php'); ?>
	<?php include('modals/delete-modal.php'); ?>
	<?php include('modals/cropper-popup.php'); ?>

	<!-- INCLUDE FOOTER -->
	<?php include('layout/foot.php'); ?>
	<!-- SCRIPTS FOR THIS PAGE -->

	<!-- PLUGINS -->
	<script src="../../assets/libs/js/cropper.js"></script>
	<script type="text/javascript" src="../../assets/libs/js/spectrum.js"></script>
	<!-- END PLUGINS -->

	<!-- INCLUDE PAGE SCRIPTS -->
	<script src="../../assets/js/admin-js/business-record-js/upload.js"></script>
	<script src="../../assets/js/admin-js/business-record-js/cropper-script.js"></script>
	<script type="text/javascript" src="../../assets/js/admin-js/business-record-js/summary.js"></script>

</body>
</html>
