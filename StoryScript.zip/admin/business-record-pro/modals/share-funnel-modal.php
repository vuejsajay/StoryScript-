<div class="page-container page-navigation-top animated fadeIn" id="shareFunnelPage">
  <!-- PAGE CONTENT -->
  <div class="page-content landing-page-wizard">
    <!-- PAGE CONTENT WRAPPER -->
    <div class="page-content-wrap">
      <div class="topNavWrapper">
        <img src="../../assets/img/funnel-map-icon.png">
        <span>FUNNEL<strong>MAPS</strong></span>
        <span class="content-title"><i class="fa fa-share-alt"></i>SHARE FUNNELS WITH OTHER USERS</span>
        <a class="skipBtn backBtn" href="#"><i class="fa fa-angle-left"></i>GO BACK </a>
      </div>
      <div class="stepContentHolder step1">
        <div class="row">
          <div class="col-md-8">
            <form id="saveTemplateForm" class="form-horizontal">
              <div class="form-group required">
                <label class="col-md-3 col-xs-12 control-label">Select Funnel</label>
                <div class="col-md-9 col-xs-12">
                  <select class="select select-funnel-name required" name="funnelName" data-live-search="true">
                    <option value="" selected disabled>Select</option>
                    <option value="1">Optin Funnel</option>
                    <option value="2">Sales Funnel</option>
                    <option value="3">Upsell Funnel</option>
                    <option value="4">Brandsite Funnel</option>
                    <option value="5">Profit Funnel</option>
                  </select>
                </div>
              </div>
              <div class="form-group required">
                <label class="col-md-3 col-xs-12 control-label">Share With</label>
                <div class="col-md-9 col-xs-12">
                  <input type="text" value="" data-role="tagsinput" class="form-control tag-box" name="shareWith">
                  <span>* Seperate Emails By Comma(,)</span>
                </div>
              </div>
              <div class="form-group required">
                <label class="col-md-3 col-xs-12 control-label">Email Subject</label>
                <div class="col-md-9 col-xs-12" >
                  <input type="text" value="" class="form-control required" name="emailSubject">
                </div>
              </div>
              <div class="form-group required">
                <label class="col-md-3 col-xs-12 control-label">Email Body</label>
                <div class="col-md-9 col-xs-12">
                  <div class="token"> <a title="" class="profileOption" data-tole="popover" data-placement="bottom" data-container="body">Tokens <i class="fa fa-caret-down"></i></a> </div>
                  <div id="token">
                    <a>Funnel Share Link</a>
                    <a>First Name</a>
                    <a>Last Name</a>
                    <a>Business Name</a>
                    <a>Business Email</a>
                    <a>Business Address</a>
                    <a>Business Phone</a>
                  </div>
                  <textarea name="emailBody" id="emailBody" class="form-control required" rows="10">
                    <div>Your Email Body Goes Here</div>
                    <span style="color: #3598db;">[Share Funnel Link]</span>
                  </textarea>
                </div>
              </div>
              <div class="form-group" style="display: none">
                <label class="col-md-3 col-xs-12 control-label">Color</label>
                <div class="col-md-9 col-xs-12 mt-5">
                  <input class="form-control" id="funnelColor">
                </div>
              </div>
            </form>
            <form id="imgForm" style="display:none;">
              <input name="imageField" type="file" accept="image/jpeg,image/x-png" />
            </form>
          </div>
          <div class="col-md-4">
            <div class="video-img-edit vedioSteps">
              <iframe height="193" src="https://www.youtube.com/embed/cYiIvg-P9gE" frameborder="0" allowfullscreen></iframe>
            </div>
            <div class="btn bootstro-finish-btn-wrapper orange-button nextBtn"> <a href="#" class="send-btn"><i class="fa fa-check"></i>SAVE & SEND </a> </div>
          </div>
        </div>
      </div>
    </div>
    <!-- END PAGE CONTENT WRAPPER -->
  </div>
  <!-- END PAGE CONTENT -->
</div>