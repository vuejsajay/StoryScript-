<!DOCTYPE html>
<html lang="en">

<head>
  <!-- META SECTION -->
  <title>Settings</title>

  <!-- INCLUDE HEAD -->
  <?php include('layout/head.php'); ?>

  <!-- CSS PLUGINS FOR THIS PAGE -->
  <link rel="stylesheet" type="text/css" href="../../assets/libs/css/flags.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" id="theme" href="../../assets/libs/css/intlTelInput.css" />
  <link href="../../assets/libs/css/cropper.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/bootstrap.tagsinput/0.8.0/bootstrap-tagsinput.css" rel="stylesheet" />

  <!-- CSS FOR THIS PAGE ONLY -->
  <link href="../../assets/css/admin-css/business-record-css/business-record-base.css" rel="stylesheet" />
  <link href="../../assets/css/admin-css/welcome-wizard-css/welcome-wizard.css" rel="stylesheet" />
  <link href="../../assets/css/admin-css/business-record-css/settings.css" rel="stylesheet" />
</head>

<body>
  <!-- START PAGE CONTAINER -->
  <div class="page-container page-navigation-top" id="mainPage">
    <!-- PAGE CONTENT -->
    <div class="page-content landing-page-wizard">

      <!--INCLUDE HEADER -->
      <?php include('layout/header.php'); ?>

      <!-- PAGE CONTENT WRAPPER -->
      <div class="page-content-wrap">
        <div class="wrapper">

          <!--INCLUDE NAVIGATION -->
          <?php $headerActiveItem = 'settings'; //set navigation active item ?>
          <?php include('layout/navigation.php'); ?>

          <div class="tab-content first-level">
            <div class="tab-pane fadeIn active">
              <div class="stepContentHolder no-padding">
                <div class="row">
                  <div class="col-md-1 menu-sidebar no-padding">
                    <nav class="side-menu-links" role="navigation">
                      <ul class="nav navbar-nav text-center">
                        <li class="active"> <a data-toggle="tab" href="#profile"> <i class="fa fa-user"></i><br>
                          profile </a> </li>
                        <li> <a data-toggle="tab" href="#account"> <i class="fa fa-upload"></i><br>
                          Account </a></li>
                        <li> <a data-toggle="tab" href="#shareFunnels"> <i class="fa fa-share-alt"></i><br>
                          SHARE FUNNELS </a></li>
                        <li> <a data-toggle="tab" href="#analyticsCode"> <i class="fa fa-code"></i><br>
                          ANALYTICS CODE </a></li>
                      </ul>
                    </nav>
                  </div>
                  <div class="tab-content col-md-11">
                    <div class="row tab-pane fadeIn active" id="profile">
                      <div class="col-md-8">
                        <!-- USER SETUP -->
                        <div class="user-setup">
                          <div class="row heading">
                            <div class="line-wrapper">
                              <p>
                                <span><i class="fa fa-gear"></i>USER SETUP</span>
                              </p>
                            </div>
                          </div>
                          <div class="row">
                            <label class="col-md-3 col-xs-12 control-label">User</label>
                            <div class="col-md-9 toggleStyle businessTypeCol">
                              <div class="col-md-3 no-padding samewidthx"><span class="local active"><i class="fa fa-user"></i> Individual</span></div>
                              <div class="col-md-3 no-padding samewidthx"><span class="online"><i class="fa fa-building-o"></i> Company</span></div>
                            </div>
                          </div>
                        </div>
                        <!-- END USER SETUP -->
                        <form id="individualForm" role="form" class="form-horizontal">
                          <!-- COMPANY CONTACT INFO -->
                          <div class="contact-info">
                            <div class="row heading">
                              <div class="line-wrapper">
                                <p>
                                  <span><i class="fa fa-user"></i>CONTACT INFO</span>
                                </p>
                              </div>
                            </div>
                            <div class="row">
                              <div class="form-group col-md-6 required no-padding">
                                <label class="col-xs-6 control-label">First Name</label>
                                <div class="col-xs-6 no-padding-right">
                                  <input name="firstName" type="text" class="form-control" placeholder="" required>
                                </div>
                              </div>
                              <div class="form-group col-md-6 no-padding">
                                <label class="col-xs-5 control-label">Last Name</label>
                                <div class="col-xs-7">
                                  <input name="lastName" type="text" class="form-control" placeholder="">
                                </div>
                              </div>
                            </div>
                            <div class="form-group required">
                              <label class="col-md-3 col-xs-12 control-label">Contact Email</label>
                              <div class="col-md-9 col-xs-12">
                                <input name="email" type="text" class="form-control" placeholder="" required>
                              </div>
                            </div>
                            <div class="form-group required">
                              <label class="col-md-3 col-xs-12 control-label">Contact Phone</label>
                              <div class="col-md-9 col-xs-12">
                                <input name="contactPhone" id="contactPhone" type="text" class="form-control" placeholder="" required>
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="col-md-3 col-xs-12 control-label">Country</label>
                              <div class="col-md-9 col-xs-12">
                                <div id="countryDDL" data-input-name="country" data-selected-country="US" data-button-size="btn-lg" data-button-type="form-control-custom" data-scrollable="true" data-scrollable-height="250px"> </div>
                              </div>
                            </div>
                            <div class="form-group required">
                              <label class="col-md-3 col-xs-12 control-label">Website URL</label>
                              <div class="col-md-9 col-xs-12">
                                <input name="website" type="text" class="form-control" required>
                              </div>
                            </div>
                          </div>
                          <!-- END COMPANY CONTACT INFO -->
                        </form>
                        <form id="companyForm" role="form" class="form-horizontal">
                          <!-- COMPANY CONTACT INFO -->
                          <div class="contact-info">
                            <div class="row heading">
                              <div class="line-wrapper">
                                <p>
                                  <span><i class="fa fa-building-o"></i>COMPANY INFO</span>
                                </p>
                              </div>
                            </div>
                            <div class="form-group required">
                              <label class="col-md-3 col-xs-12 control-label">Company Name</label>
                              <div class="col-md-9 col-xs-12">
                                <input name="companyName" type="text" class="form-control" placeholder="" required>
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="col-md-3 col-xs-12 control-label">Address</label>
                              <div class="col-md-9 col-xs-12">
                                <input name="address" type="text" class="form-control" placeholder="">
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="col-md-3 col-xs-12 control-label">City</label>
                              <div class="col-md-9">
                                <div class="row">
                                  <div class="col-md-3 no-padding-left">
                                    <input name="city" type="text" class="form-control">
                                  </div>
                                  <div class="col-md-5 no-padding">
                                    <label class="col-xs-3 control-label no-padding">State</label>
                                    <div class="col-xs-9">
                                      <input name="state" type="text" class="form-control">
                                    </div>
                                  </div>
                                  <div class="col-md-4 no-padding">
                                    <label class="col-xs-4 control-label no-padding">Postal</label>
                                    <div class="col-xs-8 no-padding-right">
                                      <input name="postcode" type="text" class="form-control">
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="form-group required">
                              <label class="col-md-3 col-xs-12 control-label">Country</label>
                              <div class="col-md-9 col-xs-12">
                                <div id="companyCountryDDL" data-input-name="country" data-selected-country="US" data-button-size="btn-lg" data-button-type="form-control-custom" data-scrollable="true" data-scrollable-height="250px"> </div>
                              </div>
                            </div>
                            <div class="form-group required">
                              <label class="col-md-3 col-xs-12 control-label">Business Phone</label>
                              <div class="col-md-9 col-xs-12">
                                <input name="businessPhone" id="businessPhone" type="text" class="form-control">
                              </div>
                            </div>
                            <div class="form-group required">
                              <label class="col-md-3 col-xs-12 control-label">Website URL</label>
                              <div class="col-md-9 col-xs-12">
                                <input name="businessWebsite" type="text" class="form-control" required>
                              </div>
                            </div>
                          </div>
                          <div class="contact-info company-contact">
                            <div class="row heading">
                              <div class="line-wrapper">
                                <p>
                                  <span><i class="fa fa-user"></i>COMPANY CONTACT INFO</span>
                                </p>
                              </div>
                            </div>
                            <div class="row">
                              <div class="form-group col-md-6 required no-padding">
                                <label class="col-xs-6 control-label">First Name</label>
                                <div class="col-xs-6 no-padding-right">
                                  <input name="firstName" type="text" class="form-control" placeholder="" required>
                                </div>
                              </div>
                              <div class="form-group col-md-6 no-padding">
                                <label class="col-xs-5 control-label">Last Name</label>
                                <div class="col-xs-7">
                                  <input name="lastName" type="text" class="form-control" placeholder="">
                                </div>
                              </div>
                            </div>
                            <div class="form-group required">
                              <label class="col-md-3 col-xs-12 control-label">Contact Email</label>
                              <div class="col-md-9 col-xs-12">
                                <input name="companyEmail" type="text" class="form-control" placeholder="" required>
                              </div>
                            </div>
                            <div class="form-group required">
                              <label class="col-md-3 col-xs-12 control-label">Contact Phone</label>
                              <div class="col-md-9 col-xs-12">
                                <input name="companyContactPhone" id="companyContactPhone" type="text" class="form-control" placeholder="" required>
                              </div>
                            </div>
                          </div>
                          <!-- END COMPANY CONTACT INFO -->
                        </form>
                      </div>
                      <div class="col-md-4">
                        <div class="video-img-edit vedioSteps">
                          <iframe height="193" src="https://www.youtube.com/embed/cYiIvg-P9gE" frameborder="0" allowfullscreen></iframe>
                        </div>
                        <div class="btn bootstro-finish-btn-wrapper orange-button nextBtn"> <a href="#" class=""><i class="fa fa-check"></i>SAVE</a></div>
                      </div>
                    </div>
                    <div class="row tab-pane fadeIn" id="account">
                      <div class='cp-wrapper'> <!-- cp = current plan -->
                        <div class="cp-header plan-wrapper-header">
                          <span><i class="fa fa-angle-double-right"></i> CURRENT PLAN</span>
                          <button class='ph-btn' data-toggle="modal" disabled><i class="fa fa-usd"></i> Payment History</button>
                        </div>
                        <div class="row cp-content">
                          <div class="col-sm-4"> 
                            <div class="cp-col plan-col">
                              <div class="plan-header"> Marketer (Single User )
                              </div>
                              <div class="plan-price">
                                <div class="price-number">
                                  FREE
                                </div>
                              </div>
                              <div class="plan-features">
                                <ul class="features-list no-padding">
                                  <li><i class="fa fa-check"></i> 10 Funnel Maps</li>
                                </ul>
                              </div>
                              <a class="plan-btn">
                                <i class="fa fa-check"></i> Current Plan
                              </a>
                            </div>
                          </div>
                          <div class="col-sm-8">
                            <div class="client-comments">
                              <div class="cc-header"> <!-- cc = client comments -->
                                <i class="fa fa-comment"></i> What Our Clients Are Saying
                              </div>
                              <div class="cc-content">
                                <div class="row cc-item">
                                  <img class="cc-avatar" src="../../assets/img/david.png">
                                  <div class="cc-detail">
                                    <div class="client-name">
                                      DAVID SMITH
                                    </div>
                                    <img class="comment-rating" src="../../assets/img/5stars.png">
                                    <div class="comment-detail">
                                      Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                    </div>
                                  </div>
                                </div>
                                <div class="row cc-item">
                                  <img class="cc-avatar" src="../../assets/img/rachel.png">
                                  <div class="cc-detail">
                                    <div class="client-name">
                                      RACHEL WHITE
                                    </div>
                                    <img class="comment-rating" src="../../assets/img/5stars.png">
                                    <div class="comment-detail">
                                      Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class='up-wrapper'> <!-- up = upgrade plan -->
                        <div class="up-header plan-wrapper-header">
                          <span>
                          <i class="fa fa-upload"></i> UPGRADE YOUR PLAN</span>
                        </div>
                        <div class="row up-content">
                          <div class="col-sm-4">
                            <div class="plan-col pro-plan">
                              <div class="plan-header"> PRO (Single User )
                              </div>
                              <div class="plan-price">
                                <div class='price-number'>$29</div>
                                <div class="plan-period">Per month</div>
                              </div>
                              <div class="plan-features">
                                <ul class="features-list no-padding">
                                  <li><i class="fa fa-check"></i> 25 Funnel Maps</li>
                                  <li><i class="fa fa-check"></i> Analytics Tracking</li>
                                </ul>
                              </div>
                              <a class="plan-btn">
                                <i class="fa fa-upload"></i> UPGRADE TO PRO
                              </a>
                            </div>
                          </div>
                          <div class="col-sm-4">
                            <div class="plan-col agency-plan">
                              <div class="plan-header"> AGENCY
                              </div>
                              <div class="plan-price">
                                <div class='price-number'>$59</div>
                                <div class="plan-period">Per month</div>
                              </div>
                              <div class="plan-features">
                                <ul class="features-list no-padding">
                                  <li><i class="fa fa-check"></i> Unlimited Businesses</li>
                                  <li><i class="fa fa-check"></i> Unlimited Funnel Maps</li>
                                  <li><i class="fa fa-check"></i> Analytics Tracking</li>
                                  <li><i class="fa fa-check"></i> Landing Page System</li>
                                </ul>
                              </div>
                              <a class="plan-btn">
                                <i class="fa fa-upload"></i> UPGRADE TO AGENCY
                              </a>
                            </div>
                          </div>
                          <div class="col-sm-4">
                            <div class="plan-col vault-plan">
                              <div class="plan-header"> FUNNEL MAPS VAULT
                              </div>
                              <div class="plan-price">
                                <div class='price-number'>$47</div>
                                <div class="plan-period">One Time Offer</div>
                              </div>
                              <div class="plan-features">
                                <ul class="features-list no-padding">
                                  <li><i class="fa fa-check"></i> Growing Database of Proven Funnels</li>
                                  <li><i class="fa fa-check"></i> All Swipe Files</li>
                                  <li><i class="fa fa-check"></i> Video Breakdowns</li>
                                  <li><i class="fa fa-check"></i> 2 to 4 New Funnels Each Month</li>
                                  <li><i class="fa fa-check"></i> <b>*BONUS*</b> Funnel Pages Templates</li>
                                </ul>
                              </div>
                              <a class="plan-btn">
                                <i class="fa fa-angle-double-right"></i> TAKE THIS OTO OFFER <i class="fa fa-angle-double-left"></i>
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row tab-pane fadeIn" id="shareFunnels">
                      <div class="sf-heading">
                        <div class="heading-left">
                          <i class="fa fa-share-alt"></i><span>SHARED FUNNELS</span>
                          <span class="sf-count">6</span>
                        </div>
                        <div class="searchWrapper">
                          <input type="search" class="" placeholder="Search..." aria-controls="LatestBanners"><i class="fa fa-search searchIcon"></i>
                        </div>
                        <button class="snf-btn"><i class="fa fa-share-alt"></i>Share New Funnel</button>
                      </div>
                      <div class="table-wrapper">
                        <table class="table table-striped" id="sharedFunnels">
                          <thead>
                            <tr>
                              <th>Thumb</th>
                              <th>Funnel Name</th>
                              <th>Users</th>
                              <th>Actions</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php
                              $sharedFunnels = [
                                [
                                  'thumb' => '../../assets/img/optin-funnel.png',
                                  'funnelName' => 'Funnel Name Goes Here Up to 40 Chars',
                                  'funnelTypeIcon' => '../../assets/img/funnel-icons/colored/optin-funnel.png',
                                  'funnelType' => 'Optin Funnel',
                                  'usersNum' => 5,
                                ],
                                [
                                  'thumb' => '../../assets/img/optin-funnel.png',
                                  'funnelName' => 'Funnel Name Goes Here Up to 40 Chars',
                                  'funnelTypeIcon' => '../../assets/img/funnel-icons/colored/optin-funnel.png',
                                  'funnelType' => 'Optin Funnel',
                                  'usersNum' => 3,
                                ],
                                [
                                  'thumb' => '../../assets/img/optin-funnel.png',
                                  'funnelName' => 'Funnel Name Goes Here Up to 40 Chars',
                                  'funnelTypeIcon' => '../../assets/img/funnel-icons/colored/optin-funnel.png',
                                  'funnelType' => 'Optin Funnel',
                                  'usersNum' => 4,
                                ],
                                [
                                  'thumb' => '../../assets/img/optin-funnel.png',
                                  'funnelName' => 'Funnel Name Goes Here Up to 40 Chars',
                                  'funnelTypeIcon' => '../../assets/img/funnel-icons/colored/optin-funnel.png',
                                  'funnelType' => 'Optin Funnel',
                                  'usersNum' => 5,
                                ],
                                [
                                  'thumb' => '../../assets/img/optin-funnel.png',
                                  'funnelName' => 'Funnel Name Goes Here Up to 40 Chars',
                                  'funnelTypeIcon' => '../../assets/img/funnel-icons/colored/optin-funnel.png',
                                  'funnelType' => 'Optin Funnel',
                                  'usersNum' => 6,
                                ],
                                [
                                  'thumb' => '../../assets/img/optin-funnel.png',
                                  'funnelName' => 'Funnel Name Goes Here Up to 40 Chars',
                                  'funnelTypeIcon' => '../../assets/img/funnel-icons/colored/optin-funnel.png',
                                  'funnelType' => 'Optin Funnel',
                                  'usersNum' => 6,
                                ],
                              ];

                              foreach( $sharedFunnels as $funnel ){
                            ?>

                            <tr>
                              <td class="thumb"><img src="<?php echo $funnel['thumb'];?>"></td>
                              <td class="funnel-name">
                                <p><?php echo $funnel['funnelName'];?></p>
                                <p class="funnel-type"><img src="<?php echo $funnel['funnelTypeIcon'];?>"> <?php echo $funnel['funnelType'];?></p>
                              </td>
                              <td class="users-num">
                                <a href="#" data-toggle="modal" data-target="#funnelSharingInfoModal"><i class="fa fa-users"></i> <?php echo $funnel['usersNum'];?></a>
                              </td>
                              <td class="action-btns">
                                <a href="#" class="action-btn share-btn" data-toggle="popover" data-placement="auto top" data-content="<strong>Share With A User</strong>" data-html="true" data-trigger="hover"><i class="fa fa-paper-plane"></i></a>
                                <a href="#" data-toggle="popover" class="action-btn" data-container="body" data-placement="auto top" data-content="<strong>View Funnel</strong>" data-html="true" data-trigger="hover"><i class="fa fa-eye"></i></a>
                              </td>
                            </tr>
                            <?php }?>
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <div class="row tab-pane fadeIn" id="analyticsCode">
                      <div class='col-md-8' style="padding-left: 30px">
                        <div class="row heading">
                          <div class="line-wrapper">
                            <p>
                              <span><i class="fa fa-code"></i>ANALYTICS CODE</span>
                            </p>
                          </div>
                        </div>
                        <div class="ac-wrapper">
                          <div class="ac-heading">
                            Copy And Paste This Analytics Code Before
                            The &lt/body&gt Of Your Website
                          </div>
                          <textarea class='ac-content'><script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
 
  ga('create', 'UA-xxxxxx-1', 'auto');
  ga('send', 'pageview');
</script></textarea>
                      
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="video-img-edit vedioSteps">
                          <iframe height="193" src="https://www.youtube.com/embed/cYiIvg-P9gE" frameborder="0" allowfullscreen></iframe>
                        </div>
                        <div class="btn bootstro-finish-btn-wrapper orange-button nextBtn" id="copyCodeBtn" data-clipboard-target='.ac-content'> <a href="#" class=""><i class="fa fa-copy"></i>COPY ANALYTICS CODE</a></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- END PAGE CONTENT WRAPPER -->
    </div>
    <!-- END PAGE CONTENT -->  
  </div>
  <!-- END PAGE CONTAINER -->

  <?php include('modals/signout-message-box.php'); ?>
  <?php include('modals/funnel-sharing-info-modal.php'); ?>
  <?php include('modals/share-funnel-modal.php'); ?>
  <!-- INCLUDE FOOTER -->
  <?php include('layout/foot.php'); ?>

  <!-- SCRIPTS FOR THIS PAGE -->
  <!-- PLUGINS -->
  <script src="../../../assets/libs/js/clipboard.min.js"></script>
  <script type="text/javascript" src="../../../assets/libs/js/noty/jquery.noty.js"></script>
  <script type="text/javascript" src="../../../assets/libs/js/noty/layouts/top.js"></script>
  <script type="text/javascript" src="../../../assets/libs/js/noty/layouts/topRight.js"></script>
  <script type="text/javascript" src="../../../assets/libs/js/noty/themes/default.js"></script>
  <script type="text/javascript" src="../../assets/libs/js/intlTelInput.js"></script>
  <script type="text/javascript" src="../../assets/libs/js/jquery.flagstrap.js"></script>
  <script type="text/javascript" src="../../assets/libs/js/datatables/jquery.dataTables.min.js"></script>
  <script src="../../assets/libs/js/ckeditor/ckeditor.js"></script>
  <script src="../../assets/libs/js/ckeditor/config.js"></script>
  <!-- END PAGE PLUGINS -->
  <!-- START TEMPLATE -->
  <script type="text/javascript" src="../../assets/js/admin-js/business-record-pro-js/settings.js"></script>
  <!-- END TEMPLATE -->
  <!-- END SCRIPTS -->
</body>

</html>
  