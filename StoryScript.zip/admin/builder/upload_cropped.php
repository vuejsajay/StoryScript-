<?php
  $data = $_POST['photo'];
	list($type, $data) = explode(';', $data);
	list(, $data)      = explode(',', $data);
	$data = base64_decode($data);
  $targetPath = "uploads/cropped/".time().'.jpg';
  $upload = file_put_contents($targetPath, $data);
  if ($upload) {
    echo $targetPath;
  }
  else {
    echo "error";
  }
?>
