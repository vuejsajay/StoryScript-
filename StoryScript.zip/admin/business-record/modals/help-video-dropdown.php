<div class="help-video help-video-container no-padding skipBtn">
  <div class="line">
    <i class="fa fa-play-circle-o"></i>
    <span>HELP VIDEO</span>
    <i class="fa fa-caret-down" aria-hidden="true"></i>
  </div>
  <div class="video-wrapper video-container" style="display:none">
    <div class="embed-responsive embed-responsive-16by9">
      <iframe width="495" height="278" class="yvideo stopped" src="https://www.youtube.com/embed/cYiIvg-P9gE" frameborder="0" allowfullscreen></iframe>
    </div>
    <div class="clearfix"></div>
  </div>
</div>