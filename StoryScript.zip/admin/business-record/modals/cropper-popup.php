<!--CROP MODAL-->
<div id="cropper-popup" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog main-popup">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
        </button>
        <h4 class="modal-title"><i class="fa fa-crop"></i> Crop Image</h4>
      </div>
      <div class="modal-body popup-body text-center">
        <div class="crop-container">
          <img src="http://placehold.it/280x40" class="croppImgLogo" alt="Cropper" />
        </div>
        <div class="crop-actions ratio-action" data-toggle="buttons">
          <ul class="aspect16-9">
            <li class="ratioLi ratio6x7" style="border-right: 0px;">
              <span>16x9 :</span>
              <a class="aspect-btn ratio-square3 active" data-method="setAspectRatio" data-option="1.7778" value="1.7778" title="Set Aspect Ratio"></a>
            </li>
          </ul>
          <div class="btn-group">
            <button type="button" class="btn btn-primary m-left" data-method="zoom" data-option="-0.1" title="Zoom Out"> <span class="fa fa-search-minus"></span>
            </button>
            <button type="button" class="btn btn-primary" data-method="zoom" data-option="0.1" title="Zoom In"> <span class="fa fa-search-plus"></span>
            </button>
          </div>
        </div>
      </div>
      <div class="modal-footer crop-actions">
        <button type="button" class="btn rk-gray-btn pull-left" data-dismiss="modal">Cancel</button>
        <button id="cropper-save" type="button" class="btn rk-green-btn" data-method="getCroppedCanvas">Save</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
</div>
<!-- CROP MODAL END -->