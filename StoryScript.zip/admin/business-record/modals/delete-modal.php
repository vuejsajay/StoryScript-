<!-- DELETE MODAL -->
<div class="modal fade in" id="delete-modal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
        <h4 class="modal-title"><i class="fa fa-times"></i> warning</h4>
      </div>
      <div class="modal-body text-center">
        <p>Are You Sure You Want To Delete This Template?</p>
        <p>ALL DATA WILL BE LOST!</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger deleteBannerConfirm" data-dismiss="modal"><i class="fa fa-times"></i> <b>YES!</b> DELETE ANYWAY!</button>
      </div>
    </div>
  </div>
</div>
<!-- END DELETE MODAL -->