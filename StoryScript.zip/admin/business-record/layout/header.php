<a class="logo-link" href="#"></a>
<!-- START X-NAVIGATION VERTICAL -->
<ul class="x-navigation x-navigation-horizontal x-navigation-panel">
	<!-- START X-NAVIGATION VERTICAL -->
	<div class="custom-ul">
		<li><a href="#"><span class="fa fa-life-ring"></span>help</a></li>
		<li class="notification">
			<a href="#"><span class="fa fa-bell"></span></a>
			<div class="informer informer-danger">5</div>
			<div class="panel panel-primary animated zoomIn xn-drop-left xn-panel-dragging" style="z-index: 300">
				<div class="panel-body list-group list-group-contacts scroll" style="height: 200px;">
					<a href="#" class="list-group-item">
						<div class="list-group-status"><i class="fa fa-bell"></i></div>
						<span class="contacts-title">John Doe</span>
						<p>Praesent placerat tellus id augue condimentum</p>
					</a>
					<a href="#" class="list-group-item">
						<div class="list-group-status"><i class="fa fa-bell"></i></div>
						<span class="contacts-title">Dmitry Ivaniuk</span>
						<p>Donec risus sapien, sagittis et magna quis</p>
					</a>
					<a href="#" class="list-group-item">
						<div class="list-group-status"><i class="fa fa-bell"></i></div>
						<span class="contacts-title">Nadia Ali</span>
						<p>Mauris vel eros ut nunc rhoncus cursus sed</p>
					</a>
					<a href="#" class="list-group-item">
						<div class="list-group-status"><i class="fa fa-bell"></i></div>
						<span class="contacts-title">Darth Vader</span>
						<p>I want my money back!</p>
					</a>
				</div>
			</div>
		</li>
		<li><a href="#" class="mb-control" data-box="#mb-signout"><span class="fa fa-power-off"></span></a></li>
	</div>
	<!-- END TOGGLE NAVIGATION -->
</ul>
<!-- END X-NAVIGATION VERTICAL -->