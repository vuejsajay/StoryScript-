<!DOCTYPE html>
<html lang="en">
<head>
<!-- META SECTION -->
<title>Funnel Map</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="icon" href="../../assets/img/funnel-map-icon.png" type="image/x-icon" />
<!-- END META SECTION -->
<!-- CSS INCLUDE -->
<link rel="stylesheet" type="text/css" id="theme" href="../../assets/libs/css/theme-default.css" />
<link rel="stylesheet" type="text/css" href="../../assets/libs/css/flags.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" id="theme" href="../../assets/libs/css/intlTelInput.css" />
<!-- EOF CSS INCLUDE -->
<!-- CSS Custom -->
<link href="../../assets/css/base-new.css" rel="stylesheet" type="text/css">
<link href="../../assets/css/admin-css/welcome-wizard-css/welcome-wizard.css" rel="stylesheet" />
<!-- End CSS Custom -->
</head>
<body class="step1">
<!-- START PAGE CONTAINER -->
<div class="page-container page-navigation-top">
  <!-- PAGE CONTENT -->
  <div class="page-content landing-page-wizard">
    <!-- PAGE CONTENT WRAPPER -->
    <div class="page-content-wrap">
      <div class="topNavWrapper">
        <img src="../../assets/img/funnel-map-icon.png">
        <span>FUNNEL<strong>MAPS</strong></span>
      </div>
      <div class="stepContentHolder step1">
        <div class="row">
          <div class="col-md-8">
            <!-- USER SETUP -->
            <div class="user-setup">
              <div class="row heading">
                <div class="line-wrapper">
                  <p>
                    <span><i class="fa fa-gear"></i>USER SETUP</span>
                  </p>
                </div>
              </div>
              <div class="row">
                <label class="col-md-3 col-xs-12 control-label">User</label>
                <div class="col-md-9 toggleStyle businessTypeCol">
                  <div class="col-md-3 no-padding samewidthx"><span class="local active"><i class="fa fa-user"></i> Individual</span></div>
                  <div class="col-md-3 no-padding samewidthx"><span class="online"><i class="fa fa-building-o"></i> Company</span></div>
                </div>
              </div>
            </div>
            <!-- END USER SETUP -->
            <form id="individualForm" role="form" class="form-horizontal">
              <!-- COMPANY CONTACT INFO -->
              <div class="contact-info">
                <div class="row heading">
                  <div class="line-wrapper">
                    <p>
                      <span><i class="fa fa-user"></i>COMPANY CONTACT INFO</span>
                    </p>
                  </div>
                </div>
                <div class="form-group required">
                  <label class="col-md-3 col-xs-12 control-label">Contact Phone</label>
                  <div class="col-md-9 col-xs-12">
                    <input name="contactPhone" id="contactPhone" type="text" class="form-control" placeholder="" required>
                  </div>
                </div>
                <div class="form-group required">
                  <label class="col-md-3 col-xs-12 control-label">Website URL</label>
                  <div class="col-md-9 col-xs-12">
                    <input name="website" type="text" class="form-control" required>
                  </div>
                </div>
                <hr>
                <div class="form-group required">
                  <label class="col-md-3 col-xs-12 control-label">Password</label>
                  <div class="col-md-9 col-xs-12">
                    <input name="password"  id='individualPassword' type="password" class="form-control" placeholder="" required>
                  </div>
                </div>
                <div class="form-group required">
                  <label class="col-md-3 col-xs-12 control-label">Confirm Password</label>
                  <div class="col-md-9 col-xs-12">
                    <input name="confirmPasswordIndividual" type="password" class="form-control" placeholder="" required>
                  </div>
                </div>
              </div>
              <!-- END COMPANY CONTACT INFO -->
            </form>
            <form id="companyForm" role="form" class="form-horizontal">
              <!-- COMPANY CONTACT INFO -->
              <div class="contact-info">
                <div class="row heading">
                  <div class="line-wrapper">
                    <p>
                      <span><i class="fa fa-building-o"></i>COMPANY INFO</span>
                    </p>
                  </div>
                </div>
                <div class="form-group required">
                  <label class="col-md-3 col-xs-12 control-label">Company Name</label>
                  <div class="col-md-9 col-xs-12">
                    <input name="companyName" type="text" class="form-control" placeholder="" required>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 col-xs-12 control-label">Business Phone</label>
                  <div class="col-md-9 col-xs-12">
                    <input name="businessPhone" id="businessPhone" type="text" class="form-control">
                  </div>
                </div>
                <div class="form-group required">
                  <label class="col-md-3 col-xs-12 control-label">Contact Phone</label>
                  <div class="col-md-9 col-xs-12">
                    <input name="contactPhone" id="companyContactPhone" type="text" class="form-control" placeholder="" required>
                  </div>
                </div>
                <div class="form-group required">
                  <label class="col-md-3 col-xs-12 control-label">Website URL</label>
                  <div class="col-md-9 col-xs-12">
                    <input name="businessWebsite" type="text" class="form-control" required>
                  </div>
                </div>
                <hr>
                <div class="form-group required">
                  <label class="col-md-3 col-xs-12 control-label">Password</label>
                  <div class="col-md-9 col-xs-12">
                    <input name="companyPassword"  id='companyPassword' type="password" class="form-control" placeholder="" required>
                  </div>
                </div>
                <div class="form-group required">
                  <label class="col-md-3 col-xs-12 control-label">Confirm Password</label>
                  <div class="col-md-9 col-xs-12">
                    <input name="confirmPasswordCompany" type="password" class="form-control" placeholder="" required>
                  </div>
                </div>
              </div>
              <!-- END COMPANY CONTACT INFO -->
            </form>
          </div>
          <div class="col-md-4">
            <div class="video-img-edit vedioSteps">
              <iframe height="193" src="https://www.youtube.com/embed/cYiIvg-P9gE" frameborder="0" allowfullscreen></iframe>
            </div>
            <div class="btn bootstro-finish-btn-wrapper orange-button nextBtn"> <a href="step2.php" class="">NEXT STEP <i class="fa fa-angle-double-right"></i></a> </div>
          </div>
        </div>
      </div>
    </div>
    <!-- END PAGE CONTENT WRAPPER -->
  </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->
<!-- START SCRIPTS -->
<!-- START PLUGINS -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.0/external/jquery/jquery.min.js"></script>
<!-- bootstrap js file  -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<!-- bootstrap Select js file  -->
<script type="text/javascript" src="../../assets/libs/js/bootstrap/bootstrap-select.js"></script>
<script type="text/javascript" src="../../assets/libs/js/intlTelInput.js"></script>
<!-- END PLUGINS -->
<!-- THIS PAGE PLUGINS -->
<script type="text/javascript" src='../../assets/libs/js/validationengine/languages/jquery.validationEngine-en.js'></script>
<script type="text/javascript" src="../../assets/libs/js/validationengine/jquery.validationEngine.js"></script>
<script type="text/javascript" src="../../assets/libs/js/jquery-validation/jquery.validate.js"></script>
<script type="text/javascript" src="../../assets/libs/js/jquery.flagstrap.js"></script>
<!-- END PAGE PLUGINS -->
<!-- START TEMPLATE -->
<script src="../../assets/js/admin-js/welcome-wizard-js/welcome-wizard.js"></script>
<!-- END TEMPLATE -->
<!-- END SCRIPTS -->
</body>
</html>
