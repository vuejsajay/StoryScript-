﻿<!DOCTYPE html>
<html lang="en" class="body-full-height">
<head>
  <!-- META SECTION -->
  <title>Story Script - Reset Password</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="icon" href="assets/img/funnel-map-icon.png" type="image/x-icon" />
  <!-- END META SECTION -->

  <!-- CSS INCLUDE -->
  <link rel="stylesheet" type="text/css" id="theme" href="assets/libs/css/theme-default.css"/>
  <!-- EOF CSS INCLUDE -->
  <!-- CUSTOM CSS -->
  <link rel="stylesheet" type="text/css" id="theme" href="assets/css/reset-pass-page-css/reset-pass-page.css"/>
</head>
<body>
  <div class="login-container">
    <div class="login-box animated text-center fadeInDown">
      <div class="container">
        <div class="row">
          <div class="col-md-12 no-mobile-padding">
            <div class="main-login-container">
              <div class="logo-body">
                <img class="logo-img" src="assets/img/logo-lr.png" alt="">
              </div>
              <div class="login-body login-form-container sent-form">
                <div class="login-title"><strong>Forgot</strong> Password ?</div>
                <p class="sub-title">We will update your password. Please enter the <br>email you registered with.</p>
                  <div class="form-group">
                    <div class="col-md-12">
                      <div class="alert alert-danger" role="alert"><i class="fa fa-times"></i> Sorry, that email does not exist as a member</div>
                    </div>
                    <div class="clearfix"></div>
                  </div>
                  <div class="form-group">
                    <div class="col-md-12">
                      <input type="email" class="validate[required,email] form-control" placeholder="Your Registered Email"/>
                    </div>
                    <div class="clearfix"></div>
                  </div>
                  <div class="form-group">
                    <div class="col-md-12">
                      <button class="btn btn-info btn-block sent-pass-btn blue-button"><i class="fa fa-paper-plane fa-fw"></i> send</button>
                    </div>
                    <div class="clearfix"></div>
                  </div>
                  <div class="form-group">
                    <div class="col-md-12">
                      <a href="signup.php" class="forget-pass-btn">SIGN UP!</a>
                    </div>
                    <div class="clearfix"></div>
                  </div>
              </div>
              <div class="login-body login-form-container sent-success" style="display:none;">
                <div class="login-title"><strong>AWESOME!</strong></div>
                <img src="assets/img/sent-pass-icon.png" alt="">
                <p class="sent-sub-title">We just emailed you instructions on retrieving <br>your password.  Please check your email in the <br>next few minutes.</p>
                  <div class="form-group">
                    <div class="col-md-12">
                      <a href="login-page.php" class="btn btn-info btn-block blue-button"><i class="fa fa-lock fa-fw"></i> Bact To Login</a>
                    </div>
                    <div class="clearfix"></div>
                  </div>
                  <div class="form-group">
                    <div class="col-md-12">
                    </div>
                    <div class="clearfix"></div>
                  </div>
              </div>
            </div>
          </div>
          <div class="col-md-12">
            <div class="login-footer">
              <hr>
              <div class="text-center footet-text">

                  <p>
                      &copy; <strong>2019 Funnel Maps <sup>tm</sup></strong> - All Rights Reserved, Product Of <strong>Strategic Marketer</strong><br>
                      Click Here For <strong><a href="http://lmgsupport.com/" target="_blank">SUPPORT</a></strong>
                  </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- START SCRIPTS -->
  <!-- START PLUGINS -->
  <script type="text/javascript" src="assets/libs/js/jquery/jquery.min.js"></script>
  <script type="text/javascript" src="assets/libs/js/bootstrap/bootstrap.min.js"></script>
  <script type='text/javascript' src='assets/libs/js/validationengine/languages/jquery.validationEngine-en.js'></script>
  <script type='text/javascript' src='assets/libs/js/validationengine/jquery.validationEngine.js'></script>
  <script type='text/javascript' src='assets/libs/js/jquery-validation/jquery.validate.js'></script>
  <!-- END PLUGINS -->

  <script type='text/javascript' src='assets/js/reset-pass-page-js/reset-pass-page.js'></script>
  <!-- START TEMPLATE -->
  <script type="text/javascript" src="assets/js/plugins.js"></script>
  <!-- END TEMPLATE -->

</body>
</html>
