<!DOCTYPE html>
<html lang="en">
<head>
<!-- META SECTION -->
<title>Funnel Map</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="icon" href="../../assets/img/funnel-map-icon.png" type="image/x-icon" />
<!-- END META SECTION -->
<!-- CSS INCLUDE -->
<link rel="stylesheet" type="text/css" id="theme" href="../../assets/libs/css/theme-default.css" />
<!-- EOF CSS INCLUDE -->
<!-- CSS Custom -->
<link href="../../assets/css/base-new.css" rel="stylesheet" type="text/css">
<link href="../../assets/css/admin-css/welcome-wizard-css/welcome-wizard.css" rel="stylesheet" />
<!-- End CSS Custom -->
</head>
<body>
<!-- START PAGE CONTAINER -->
<div class="page-container page-navigation-top">
  <!-- PAGE CONTENT -->
  <div class="page-content landing-page-wizard">
    <!-- PAGE CONTENT WRAPPER -->
    <div class="page-content-wrap">
      <div class="topNavWrapper">
        <img src="../../assets/img/funnel-map-icon.png">
        <span>FUNNEL<strong>MAPS</strong></span>
      </div>
      <div class="stepContentHolder confirm">
        <img class="confirm-icon" src="../../assets/img/confirm-icon.png">
        <p class="heading"><strong>THANK YOU FOR SIGNING UP!</strong><br>Your Account Has Been Created</p>
        <p>Please Confirm Your Email By Clicking<br>The Link In The Email We Just Sent You.</p>
        <button class="repeatEmailBtn"><i class="fa fa-envelope"></i>I Didn’t Receive The Email, Send Me Again</button>
      </div>
    </div>
    <!-- END PAGE CONTENT WRAPPER -->
  </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->
<!-- START SCRIPTS -->
<!-- START PLUGINS -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.0/external/jquery/jquery.min.js"></script>
<!-- bootstrap js file  -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<!-- END PLUGINS -->
<!-- START TEMPLATE -->
<!-- <script src="../../assets/js/admin-js/welcome-wizard-js/welcome-wizard.js"></script> -->
<!-- END TEMPLATE -->
<!-- END SCRIPTS -->
</body>
</html>
