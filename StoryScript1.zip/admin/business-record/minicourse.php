<!DOCTYPE html>
<html lang="en">

<head>
	<title>Minicourse</title>
	
	<!-- INCLUDE HEAD -->
  <?php include('layout/head.php'); ?>
	
	<!-- CSS FOR THIS PAGE ONLY -->
  <link href="../../assets/css/admin-css/business-record-css/business-record-base.css" rel="stylesheet" />
	<link href="../../assets/css/admin-css/business-record-css/minicourse.css" rel="stylesheet" />
</head>

<body>
<!-- START PAGE CONTAINER -->
<div class="page-container page-navigation-top">
	<!-- PAGE CONTENT -->
	<div class="page-content">
		
		<!--INCLUDE HEADER -->
    <?php include('layout/header.php'); ?>
		
		<!-- PAGE CONTENT WRAPPER -->
		<div class="page-content-wrap">
			
			<div class="wrapper">
				
				<!--INCLUDE NAVIGATION -->
        <?php $headerActiveItem = 'minicourse'; //set navigation active item ?>
        <?php include('layout/navigation.php'); ?>
				
				<div class="tab-content first-level">
					<div id="minicourse" class="tab-pane zoomIn active">

						<!-- BEGIN Mini Course Videos -->
						<div class="row no-padding">

							<?php for($i = 1; $i <= 8; $i ++) { ?>
								<div class="col-xs-3 p-10">
			            <div class="banner-item">
			              <div class="square-content">
			                <a href='#video-modal' data-toggle="modal">
			                  <div class="content-inside">
			                    <img class="img-responsive" src="../../assets/img/mini-course-thumb.png" alt="">
			                    <div class="img-overlay">
			                      <img src="../../assets/img/play-video.png">
			                    </div>
			                  </div>
			                  <div class="top-title">
			                    <img src="../../assets/img/mini-course-video-icon.png">
			                    <span>Video Title Goes Here It Can Be 2 Lines</span>
			                  </div>
			                </a>
			              </div>
			            </div>
			          </div>
              <?php } ?>

						</div>
						<!-- END Mini Course Videos -->

					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- END PAGE CONTENT WRAPPER -->
</div>
<!-- END PAGE CONTAINER -->

<?php include('modals/signout-message-box.php'); ?>
<?php include('modals/help-video-modal.php'); ?>


<!-- INCLUDE FOOTER -->
<?php include('layout/foot.php'); ?>
</body>
</html>
