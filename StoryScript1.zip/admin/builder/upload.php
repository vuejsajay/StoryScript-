<?php
if(is_array($_FILES)) {
  if(is_uploaded_file($_FILES['imageField']['tmp_name'])) {
    $sourcePath = $_FILES['imageField']['tmp_name'];
    $targetPath = "uploads/".$_FILES['imageField']['name'];
    if(move_uploaded_file($sourcePath,$targetPath)) {
      echo $targetPath;
    }
    else {
      echo "error";
    }
  }
  else {
    echo "error";
  }
}
else {
  echo "error";
}
?>
