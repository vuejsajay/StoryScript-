var clickedCustomThumbBtn;

$(document).ready(function () {
	$(".forProductPhoto.img1-pro .delete-icon").click(function () {
		$(this).hide();
		$(".importFromDesktopBtn2.upload-btn").show();
		$('.forProductPhoto.img1-pro').hide();
		$(".thumb-img-Product-Photo").attr("src", "");
	});
  $(".forProductPhoto.img2-pro .delete-icon").click(function () {
		$(this).hide();
		$(".importFromDesktopBtn.upload-btn").show();
		$('.forProductPhoto.img2-pro').hide();
		$(".thumb-img-Product-Photo2").attr("src", "");
	});
	$('#imgForm2 input').on('change', function () {
		$(this).closest('form').submit();
	});
  $('#imgForm input').on('change', function () {
		$(this).closest('form').submit();
	});

	$("#cropper-save").click(function (e){
    if(ShowPreview==1){
			$(".forProductPhoto.img1-pro .delete-icon").show();
			$(".importFromDesktopBtn2.upload-btn").hide();
			$(".forProductPhoto.img1-pro").show();

    }
    if(ShowPreview==2){
			$(".forProductPhoto.img2-pro .delete-icon").show();
			$(".importFromDesktopBtn.upload-btn").hide();
			$(".forProductPhoto.img2-pro").show();
    }
	});

	$("#imgForm2").on('submit', (function (e) {
		e.preventDefault();
		$.ajax({
			url: "upload.php",
			type: "POST",
			data: new FormData(this),
			contentType: false,
			cache: false,
			processData: false,
			success: function (data) {
				// call cropper
				brandingCropper(data, ratio, 100, 100);
				// $('#imgForm2 input').attr("value","");
				thumbnailEdit = true;
        ShowPreview=1;
			},
			error: function () {}
		});
	}));
  $("#imgForm").on('submit', (function (e) {
		e.preventDefault();
		$.ajax({
			url: "upload.php",
			type: "POST",
			data: new FormData(this),
			contentType: false,
			cache: false,
			processData: false,
			success: function (data) {
				// call cropper
				brandingCropper(data, ratio, 6, 7);
				// $('#imgForm2 input').attr("value","");
				thumbnailEdit = true;
        ShowPreview=2;
			},
			error: function () {}
		});
	}));
	$(document).on('click', '.action-setting-tab .custom-thumb-btn, .traffic-setting-tab .custom-thumb-btn', function () {
		ratio = (1 / 1);
		$('#imgForm2 input').trigger('click');
		clickedCustomThumbBtn = $(this);
    $(".aspect1-1").show();
    $(".aspect6-7").show();
	});
	$(document).on('click', '.page-setting-tab .custom-thumb-btn', function () {
		clickedCustomThumbBtn = $(this);
	  ratio = (6 / 7);
	  $('#imgForm input').trigger('click');
	  $(".aspect1-1").hide();
	  $(".aspect6-7").show();
	});
});
