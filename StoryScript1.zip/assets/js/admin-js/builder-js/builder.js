var settingMenu;
var deleteLinkBtn;
var isDeleteConfirmed = false;
var selectedLink;
var selectedCard;
var selectedAutomationCard;
var prevParent;
var clickedPlusBtn;
var editingNode;
var editingRowId;
var oldValue;
var oldUrl;
var newValue;
var newUrl;

var templateArray = {
  "Sample Template": [
    [
      // {key: "SampleTemplate", isGroup: true},
      { key: "WatchVideo0", category: "action-card", cardTitle: "Watch Video", description: "clicked play", screenshot: "../../assets/img/action-icons/003-Watch-video.svg", themeColor: Themes.ORANGE,
        settingData: {
          actionName: "Watch Video",
          actionDescription: "clicked play",
          embedCode: "<script type='text/javascript'>window.onload = function() {window.funnelytics.events.trigger('video', {video: 'Upsell Video', offer: 'Downsell Video',}, function() {// continue with process..});};</script>",
          elements: [["video", "Upsell Video"], ["offer", "John"]],
          notes: [["11/15/17", "Note Goes Here and it can be long more than 1 line."], ["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."]],
        },
        group: "SampleTemplate",
        loc: "0 0"
      },
      { key: "LeadMagnet0", category: "page-card", pageType:"Optin Page",
        cardTitle: "Lead Magnet", screenshot: "../../assets/img/funnel-card-screenshot.png", themeColor: Themes.BLUE,
        settingData: {
          pageName: "Lead Magnet",
          pageURL: "www.MySite.com/page",
          embedCode: '<script type="text/javascript">window.onload = function() {window.funnelytics.events.trigger("video", {video: "Upsell Video",}, function() {// continue with process..});};</script>',
          params: [["a", "Yes", "Contain"], ["firstname", "John", "Contain"], ["lastname", "Smith", "Doesn't Contain"]],
          goals: [["Salesp Page", "29", "Lead"], ["Order", "30", "Sale"], ["Rep Page", "40", "Application"]],
          notes: [["11/15/17", "Note Goes Here and it can be long more than 1 line."], ["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."]],
        },
        group: "SampleTemplate",
        loc: "200 0",
      },
      { key: "Report0", category: "traffic-card", cardTitle: "Download Report", description: "", screenshot: "../../assets/img/traffic-icons/014-Report.svg",themeColor: Themes.TEAL,
        settingData: {
          itemName: "Download Report",
          itemDescription: "",
          itemURL: "",
          utmMarketingSrc: "newsletter",
          utmMediumType: "email",
          utmCampaign: "spring_sale",
          utmTerm: "paid",
          utmContent: "newsletter",
          utmURL: "?utm_source=newsletter&utm_medium=email&utm_campaign=spring_sale&utm_term=paid&utm_content=newsletter",
          notes: [["11/15/17", "Note Goes Here and it can be long more than 1 line."], ["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."]],
        },
        group: "SampleTemplate",
        loc: "500 0",
      },
    ],
    [
      { from: "WatchVideo0", to: "LeadMagnet0", arrowColor: Themes.ORANGE},
      { from: "LeadMagnet0", to: "Report0", arrowColor: Themes.BLUE},
    ]
  ]
};

// Delete Card
function onClickDeletePage() {
  settingMenu.hide();
  $('#deleteCardModal .page-name').text(editingNode.data['cardTitle']);
  switch (editingNode.category) {
    case 'page-card':
      $('#deleteCardModal .card-type').text('PAGE'); break;
    case 'traffic-card':
      $('#deleteCardModal .card-type').text('TRAFFIC ELEMENT'); break;
    case 'action-card':
      $('#deleteCardModal .card-type').text('ACTION ELEMENT'); break;
    case 'text-card':
      $('#deleteCardModal .card-type').text('TEXT ELEMENT'); break;
  }
  $('#deleteCardModal').modal();
}
function onDeleteCard() {
  funnelDiagram.startTransaction("removeNode");
  editingNode.findNodesInto().each(function(n) {
    if(n.findNodesOutOf().count == 1) {
      n.findObject('card-bg').stroke = n.data['themeColor'];
    }
  })
  funnelDiagram.remove(editingNode);
  funnelDiagram.commitTransaction("removeNode");
}

// Toggle Multi Selection
function onToggleMultiSelection() {
  $('.multiselect-btn').toggleClass("active");
  if($('.multiselect-btn').hasClass("active")) {
    funnelDiagram.toolManager.panningTool.isEnabled = false;
    funnelDiagram.toolManager.dragSelectingTool.isEnabled = true;
  } else {
    funnelDiagram.toolManager.panningTool.isEnabled = true;
    funnelDiagram.toolManager.dragSelectingTool.isEnabled = false;
  }
}

// Open warning modal when delete link
function onClickDeleteLink() {
  $('#deleteLinkModal .page-name1').text(selectedLink.fromNode.data['cardTitle']);
  $('#deleteLinkModal .page-name2').text(selectedLink.toNode.data['cardTitle']);
  $('#deleteLinkModal').modal();
}

// Delete Link
function onDeleteLink() { 
  var toNode = selectedLink.toNode;
  var fromNode = selectedLink.fromNode;
  var fromPort = selectedLink.fromPort;
  funnelDiagram.startTransaction("deleteLink");
  if(fromNode.findNodesOutOf().count == 1) {
    fromNode.findObject('card-bg').stroke = fromNode.data['themeColor'];
    fromNode.findObject('connect-btn').visible = true;
  }
  funnelDiagram.remove(selectedLink);
  funnelDiagram.commitTransaction("deleteLink");
  deleteLinkBtn.css("visibility", "hidden");
}

// Delete Selection
function onDeleteSelection() {
  funnelDiagram.allowDelete = true;
  isDeleteConfirmed = true;
  funnelDiagram.commandHandler.deleteSelection();
  isDeleteConfirmed = false;
}

// Cancel deleting selection
function onCancelDeleteSelection() {
  funnelDiagram.allowDelete = true;
}

//View page
function onClickPreviewPage() {
  window.open('#', '_blank');
}

// Show setting menu
function onClickSettingPage(obj) {
  settingMenu.hide();
  editingNode = obj;
  if(editingNode.category == "page-card") {
    settingMenu = $('.page-setting-menu');
  } else if(editingNode.category == 'text-card') {
    settingMenu = $('.text-setting-menu');
  } else if(editingNode.category == 'action-card'){
    settingMenu = $('.action-setting-menu');
  } else {
    settingMenu = $('.traffic-setting-menu');
  }
  settingMenu.show();
  settingMenu.css({left: funnelDiagram.transformDocToView(obj.location).x + obj.actualBounds.width / 2 * funnelDiagram.scale - $(settingMenu).width() / 2});
  settingMenu.css({top: funnelDiagram.transformDocToView(obj.location).y + obj.actualBounds.height * funnelDiagram.scale + 10});
}

//Edit funnel page
function onClickEditPage() {
  // settingMenu.hide();
  $("#sidebar-wrapper").css("left", "273px");
  closeOpenFloatingControls();
  $(".floating-btn").removeClass("active");
  $('.side-tab-content').removeClass("active");
  switch(editingNode.category) {
    case 'page-card':
      preparePageSettingTab(editingNode.data['settingData']);
      $('.setting-tab.active').hide();
      $('.setting-tab.active').removeClass('active');
      $('.page-setting-tab').show();
      $('.page-setting-tab').addClass('active');
      break;
    case 'traffic-card':
      prepareTrafficSettingTab(editingNode.data['settingData']);
      $('.setting-tab.active').hide();
      $('.setting-tab.active').removeClass('active');
      $('.traffic-setting-tab').show();
      $('.traffic-setting-tab').addClass('active');
      break;
    case 'action-card':
      prepareActionSettingTab(editingNode.data['settingData']);
      $('.setting-tab.active').hide();
      $('.setting-tab.active').removeClass('active');
      $('.action-setting-tab').show();
      $('.action-setting-tab').addClass('active');
      break;
    case 'text-card':
      funnelDiagram.toolManager.textEditingTool.textBlock = editingNode.findObject('text-content');
      funnelDiagram.currentTool = funnelDiagram.toolManager.textEditingTool;
      funnelDiagram.toolManager.textEditingTool.doStart();
  }
}

//Duplicate card
function onClickDuplicatePage() {
  settingMenu.hide();
  var loc = editingNode.actualBounds.center;
  funnelDiagram.commandHandler.copySelection();
  funnelDiagram.commandHandler.pasteSelection(new go.Point(loc.x+20, loc.y+20));
}

// Start drawing link when click "Draw connection"
function onClickDraw(btn) {
  clickedPlusBtn = btn;
  btn.part.findObject('border').fromLinkable = true;
  var ltool = funnelDiagram.toolManager.linkingTool;
  ltool.startObject = btn.part.findObject('border');
  ltool.temporaryLink.data = {"arrowColor": btn.findObject('btn-fg').fill};
  funnelDiagram.currentTool = ltool;
  ltool.doActivate();
}

// Change font size of text box
function onChangeFontSize() {
  var fs = $('.font-size-select').val();
  console.log(fs);
  funnelDiagram.startTransaction("change font size");
  editingNode.findObject("text-content").font = "bold " + fs + "px Open Sans, sans-serif";
  funnelDiagram.commitTransaction("change font size");
}

//Init linking tool
function commonLinkingToolInit(tool) {
  tool.portGravity = 0.0;
}

// Draw diagram
$(document).ready(function() {

  // Init Popovers
  $('[data-toggle="popover"]').popover();
  
  //Define delete point btn
  var deletePointButton =
    $$(go.Adornment, "Spot",
      {
        category: "LinkReshaping",
        layerName: "Tool",  // in front of Adornments
        background: "transparent",
        shadowBlur: 8,
        shadowColor: "rgba(0, 0, 0, 0.25)",
        selectionAdorned: true,
        mouseLeave: function(e) {  // hide this button
          e.diagram.remove(deletePointButton);
          deletePointButton.adornedObject = null;
        }
      },
      $$(go.Placeholder),
      $$("Button",
        { // button is above-right of the reshape handle circle
          alignment: go.Spot.TopRight,
          alignmentFocus: go.Spot.BottomLeft,
          desiredSize: new go.Size(24,24),
          "ButtonBorder.figure": "Circle",
          "ButtonBorder.fill": "white",
          "ButtonBorder.stroke": null,
          "ButtonBorder.shadowVisible": true,
          "_buttonStrokeOver": null,
          "_buttonFillOver": "white",
          cursor: "pointer",
          click: function(e, button) {
            var handle = button.part.adornedObject;
            var link = handle.part.adornedPart;
            var seg = handle.segmentIndex;
            var pts = link.points.copy();
            pts.removeAt(seg);
            funnelDiagram.startTransaction("deleted point from link route");
             
            link.points = pts;
            if(pts.count == 2) {
              link.invalidateRoute();
            }
            funnelDiagram.commitTransaction("deleted point from link route");
          }
        },
        $$(go.Shape, "XLine",
          { stroke: "red", strokeWidth: 2, width: 10, height: 10 }),  
      )
    );

  // Define diagram
  funnelDiagram = $$(go.Diagram, "edit-div",
    {
      // have mouse wheel events zoom in and out
      "toolManager.mouseWheelBehavior": go.ToolManager.WheelZoom,
      "toolManager.hoverDelay": 100,
      "toolManager.holdDelay": 300,
      "undoManager.isEnabled": true,  // enable undo & redo     
      initialContentAlignment: go.Spot.TopLeft,
      hasHorizontalScrollbar: false,
      hasVerticalScrollbar: false,
      minScale: 0.25, // so that the contents cannot appear too small
      maxScale: 3, // so that the contents cannot appear too big
      initialScale: 0.9,
      padding: new go.Margin(100, 0, 0, 280),
      layout: $$(go.TreeLayout, {layerSpacing: 90, nodeSpacing: 40, isOngoing: false, alignment: go.TreeLayout.AlignmentStart, setsPortSpot: false, setsChildPortSpot: false}),
      commandHandler: $$(DrawCommandHandler),
      'commandHandler.pasteOffset': new go.Point(20,20),
      "linkReshapingTool.handleArchetype":
        $$(go.Shape, "Circle",
          { // change the default reshape handle to be a large circle
            width: 16, height: 16,
            fill: "lightblue", stroke: "dodgerblue",
            mouseEnter: function(e, shape) {  // show the delete button
              deletePointButton.adornedObject = shape;
              e.diagram.add(deletePointButton);
            },
            mouseLeave: function(e, shape, next) {  // show the delete button
              var tool = e.diagram.toolManager.linkReshapingTool;
              if(tool.adornedLink)tool.adornedLink.removeAdornment(tool.name);
            },
          }),
    }),
  
  // Enable infinite scroll
  funnelDiagram.startTransaction("enable infinite scroll");
  funnelDiagram.scrollMode = go.Diagram.InfiniteScroll;
  funnelDiagram.commitTransaction("enalbe infinite scroll");

  settingMenu = $('.setting-menu');

  // Hide menu and color picker when background is clicked
  funnelDiagram.addDiagramListener("BackgroundSingleClicked", function(e) {
    $('.colorpicker').hide();
    settingMenu.hide();
  });

  // Hide menu when single node is selected
  funnelDiagram.addDiagramListener("ObjectSingleClicked", function(e) {
    $('.colorpicker').hide();
    $('.setting-tab.active').hide();
    $('.setting-tab.active').removeClass('active');
  });
  
  // link drawn event
  funnelDiagram.addDiagramListener("LinkDrawn", function(e) {
    var link = e.subject;
    link.fromNode.findObject('border').fromLinkable = false,
    link.data = {"arrowColor": clickedPlusBtn.findObject('btn-fg').fill};
    link.fromNode.findObject("card-bg").stroke = null;
  });

  // Selection deleting event
  funnelDiagram.addDiagramListener("SelectionDeleting", function(e) {
    if(!isDeleteConfirmed){
      funnelDiagram.allowDelete = false;
      $("#deleteSelectionkModal").modal();
    }
  });

  // Selection Move event
  funnelDiagram.addDiagramListener("SelectionMoved", function(e) {
    if(!$(".multiselect-btn").hasClass("active")) {
      obj = (e.subject).first();
      settingMenu.show();
      settingMenu.css({left: funnelDiagram.transformDocToView(obj.location).x + obj.actualBounds.width / 2 * funnelDiagram.scale - $(settingMenu).width() / 2});
      settingMenu.css({top: funnelDiagram.transformDocToView(obj.location).y + obj.actualBounds.height * funnelDiagram.scale + 10});
    }
  });

  // Hide Setting Menu in the beginng of dragging
  funnelDiagram.toolManager.draggingTool.doActivate = function() {
    settingMenu.hide();
    go.DraggingTool.prototype.doActivate.call(this);
  }

  // Add card templates to template map
  funnelDiagram.nodeTemplateMap.add("page-card", pageCardTemplate);
  funnelDiagram.nodeTemplateMap.add("traffic-card", trafficCardTemplate);
  funnelDiagram.nodeTemplateMap.add("action-card", actionCardTemplate);
  funnelDiagram.nodeTemplateMap.add("text-card", textCardTemplate);

  deleteLinkBtn = $('.delete-link-btn');

  // Define link template
  funnelDiagram.linkTemplate = $$(go.Link,
    {
      // routing: go.Link.AvoidsNodes,
      // corner: 10,
      // curve: go.Link.JumpOver,
      toShortLength: 4, fromShortLength: -5,
      fromSpot: go.Spot.None,
      toSpot: go.Spot.None,
      layerName: "Background",
      cursor: "pointer",
      reshapable: true,
      adjusting: go.Link.Stretch,
      selectionAdornmentTemplate:
        $$(go.Adornment,
          $$(go.Shape,
            { isPanelMain: true, stroke: "rgba(30,144,255,0.2)", strokeWidth: 20 }),
          $$(go.Shape,
            { isPanelMain: true, stroke: "#787878", strokeWidth: 2 }),
          $$(go.Shape,
            { toArrow: "Standard", fill: "#787878", stroke: null, scale: 1.5,segmentOffset: new go.Point(10,0) })
        ),  // end Adornment
      mouseEnter: function(e, obj, prev) {
        deleteLinkBtn.css("visibility", "visible");
        deleteLinkBtn.css({left: funnelDiagram.transformDocToView(obj.part.position).x  + obj.actualBounds.width / 2 * funnelDiagram.scale});
        deleteLinkBtn.css({top: funnelDiagram.transformDocToView(obj.part.position).y + obj.actualBounds.height / 2 * funnelDiagram.scale + 20});
        obj.path.stroke = "rgba(30,144,255,0.2)";
        selectedLink = obj.part;
        var tool = e.diagram.toolManager.linkReshapingTool;
        var ad = obj.findAdornment(tool.name);
        if (!ad) ad = tool.makeAdornment(obj.path);
        obj.addAdornment(tool.name, ad);
      },
      mouseLeave: function(e, link, next) {
        deleteLinkBtn.css("visibility", "hidden");
        link.path.stroke = "transparent";
        var tool = e.diagram.toolManager.linkReshapingTool;
        if (next && next.part.category === tool.name) return;
        link.removeAdornment(tool.name);
        e.diagram.remove(deletePointButton);
      },
      click: function(e, link) {
        var p = e.diagram.lastInput.documentPoint;
        var seg = link.findClosestSegment(p);
        var pts = link.points.copy();
        pts.insertAt(seg+1, p.copy());
        funnelDiagram.startTransaction("inserted point in link route");
        link.points = pts;
        funnelDiagram.commitTransaction("inserted point in link route");
      }
    },
    new go.Binding("points").makeTwoWay(),
    $$(go.Shape, 
      {stroke: "transparent", strokeWidth: 20, isPanelMain: true}
    ),
    $$(go.Shape, 
      {strokeWidth: 2, isPanelMain: true},
      new go.Binding("stroke", "arrowColor")
    ),
    
    $$(go.Shape, 
      {toArrow: "standard", stroke: null, scale: 1.5, segmentOffset: new go.Point(10,0)},
      new go.Binding("fill", "arrowColor")
    ),
  );

  //Define Group template
  funnelDiagram.groupTemplate =
    $$(go.Group, "Auto",
      {desiredSize: new go.Size(10000000, NaN), ungroupable: true},
      new go.Binding("location", "loc", go.Point.parse),
    );
  
  //LinkingBaseTool config
  funnelDiagram.toolManager.linkingTool.setNoTargetPortProperties = function(tempnode, tempport, toend) {
    go.LinkingTool.prototype.setNoTargetPortProperties.call(this, tempnode, tempport, toend);
    var node = this.diagram.findPartAt(this.diagram.lastInput.documentPoint);
    if(node instanceof go.Node && node == funnelDiagram.toolManager.linkingTool.originalFromNode) {
      tempnode.location = clickedPlusBtn.getDocumentPoint(go.Spot.Center).add(new go.Point(30, 30))
    }
  }

  // DragSelectingTool init
  funnelDiagram.toolManager.dragSelectingTool.delay = 100;
  funnelDiagram.toolManager.dragSelectingTool.isEnabled = false;
  funnelDiagram.toolManager.dragSelectingTool.box =
    $$(go.Part,
      { layerName: "Tool", selectable: false },
      $$(go.Shape, "RoundedRectangle",
        { name: "SHAPE", fill: null, stroke: Themes.ORANGE, strokeWidth: 3 }));

  // LinkingTool init
  var ltool = funnelDiagram.toolManager.linkingTool;
  commonLinkingToolInit(ltool);
  
  // Define temporary link template
  ltool.temporaryLink = $$(go.Link,
    {
      layerName: "Tool",
    },
    $$(go.Shape, 
      {strokeWidth: 2, strokeDashArray: [10,4]},
      new go.Binding("stroke", "arrowColor")
    ),
    $$(go.Shape, 
      {toArrow: "standard", stroke: null, scale: 1.5, segmentOffset: new go.Point(10,0)},
      new go.Binding("fill", "arrowColor")
    )
  );
  // do not allow links to be drawn starting at the "to" port
  ltool.direction = go.LinkingTool.ForwardsOnly;

  // Define custom highlight
  var tempFromNode =
    $$(go.Node,
      { layerName: "Background" },
      $$(go.Shape, "RoundedRectangle",
        { stroke: null, fill: "transparent", portId: "",fromSpot: go.Spot.AllSides,
          width: 1, height: 1 })
    );
  var tempToNode = 
    $$(go.Node,
      { layerName: "Tool" },
      $$(go.Shape, "RoundedRectangle",
        { stroke: Themes.ORANGE, strokeWidth: 2, fill: null, portId: "", toSpot: go.Spot.AllSides,
          width: 1, height: 1 })
    );

  funnelDiagram.toolManager.linkingTool.temporaryFromNode = tempFromNode;
  funnelDiagram.toolManager.linkingTool.temporaryFromPort = tempFromNode.port;
  funnelDiagram.toolManager.linkingTool.temporaryToNode = tempToNode;
  funnelDiagram.toolManager.linkingTool.temporaryToPort = tempToNode.port;

  // Create the model data that will be represented by Nodes and Links
  funnelDiagram.model = $$(go.GraphLinksModel,
    { 
      nodeDataArray: [
        { key: "WatchVideo", category: "action-card", description: "clicked play", cardTitle: "Watch Video", screenshot: "../../assets/img/action-icons/003-Watch-video.svg", themeColor: Themes.ORANGE,
          loc: "0 0",
          settingData: {
            actionName: "Watch Video",
            actionDescription: "clicked play",
            embedCode: "<script type='text/javascript'>window.onload = function() {window.funnelytics.events.trigger('video', {video: 'Upsell Video', offer: 'Downsell Video',}, function() {// continue with process..});};</script>",
            elements: [["video", "Upsell Video"], ["offer", "John"]],
            notes: [["11/15/17", "Note Goes Here and it can be long more than 1 line."], ["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."]],
          }
        },
        { key: "LeadMagnet", category: "page-card", pageType:"Optin Page", description: "Lead Magnet",
          cardTitle: "Lead Magnet", screenshot: "../../assets/img/funnel-card-screenshot.png", themeColor: Themes.BLUE,
          loc: "221 0",
          settingData: {
            pageName: "Lead Magnet",
            pageDescription: "Lead Magent",
            pageURL: "www.MySite.com/page",
            embedCode: '<script type="text/javascript">window.onload = function() {window.funnelytics.events.trigger("video", {video: "Upsell Video",}, function() {// continue with process..});};</script>',
            params: [["a", "Yes", "Contain"], ["firstname", "John", "Contain"], ["lastname", "Smith", "Doesn't Contain"]],
            goals: [["Salesp Page", "29", "Lead"], ["Order", "30", "Sale"], ["Rep Page", "40", "Application"]],
            notes: [["11/15/17", "Note Goes Here and it can be long more than 1 line."], ["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."]],
          }
        },
        { key: "SalesPage", category: "page-card", pageType:"Sales Page", description: "Sales Page",
          cardTitle: "Sales Page", screenshot: "../../assets/img/funnel-card-screenshot.png",themeColor: Themes.BLUE,
          loc: "502 0",
          settingData: {
            pageName: "Sales Page",
            pageDescription: "Sales Page",
            pageURL: "www.MySite.com/page",
            embedCode: '<script type="text/javascript">window.onload = function() {window.funnelytics.events.trigger("video", {video: "Upsell Video",}, function() {// continue with process..});};</script>',
            params: [["a", "Yes", "Contain"], ["firstname", "John", "Contain"], ["lastname", "Smith", "Doesn't Contain"]],
            goals: [["Salesp Page", "29", "Lead"], ["Order", "30", "Sale"], ["Rep Page", "40", "Application"]],
            notes: [["11/15/17", "Note Goes Here and it can be long more than 1 line."], ["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."]],
          }
        },
        { key: "TrustTriggerOrderPage", category: "page-card", pageType:"Order Page", description: "Trust Trigger Order Page",
          cardTitle: "Trust Trigger Order Page", screenshot: "../../assets/img/funnel-card-screenshot.png",themeColor: Themes.BLUE,
          loc: "783 0",
          settingData: {
            pageName: "Trust Trigger Order Page",
            pageDescription: "Trust Trigger Order Page",
            pageURL: "www.MySite.com/page",
            embedCode: '<script type="text/javascript">window.onload = function() {window.funnelytics.events.trigger("video", {video: "Upsell Video",}, function() {// continue with process..});};</script>',
            params: [["a", "Yes", "Contain"], ["firstname", "John", "Contain"], ["lastname", "Smith", "Doesn't Contain"]],
            goals: [["Salesp Page", "29", "Lead"], ["Order", "30", "Sale"], ["Rep Page", "40", "Application"]],
            notes: [["11/15/17", "Note Goes Here and it can be long more than 1 line."], ["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."]],
          }
        },
        { key: "OrderConf", category: "page-card", pageType:"Order Conf Page", description: "Order Conf Page",
          cardTitle: "Order Conf", screenshot: "../../assets/img/funnel-card-screenshot.png",themeColor: Themes.BLUE,
          loc: "1064 0",
          settingData: {
            pageName: "Order Conf Page",
            pageDescription: "Order Conf Page",
            pageURL: "www.MySite.com/page",
            embedCode: '<script type="text/javascript">window.onload = function() {window.funnelytics.events.trigger("video", {video: "Upsell Video",}, function() {// continue with process..});};</script>',
            params: [["a", "Yes", "Contain"], ["firstname", "John", "Contain"], ["lastname", "Smith", "Doesn't Contain"]],
            goals: [["Salesp Page", "29", "Lead"], ["Order", "30", "Sale"], ["Rep Page", "40", "Application"]],
            notes: [["11/15/17", "Note Goes Here and it can be long more than 1 line."], ["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."]],
          }
        },
        { key: "Email", category: "traffic-card", cardTitle: "Email", description: "", screenshot: "../../assets/img/traffic-icons/006-Email.svg",themeColor: Themes.TEAL,
          loc: "1345 0",
          settingData: {
            itemName: "Email",
            itemDescription: "",
            itemURL: "",
            utmMarketingSrc: "newsletter",
            utmMediumType: "email",
            utmCampaign: "spring_sale",
            utmTerm: "paid",
            utmContent: "newsletter",
            utmURL: "?utm_source=newsletter&utm_medium=email&utm_campaign=spring_sale&utm_term=paid&utm_content=newsletter",
            notes: [["11/15/17", "Note Goes Here and it can be long more than 1 line."], ["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."]],
          }
        },
        { key: "Report", category: "traffic-card", cardTitle: "Download Report", description: "", screenshot: "../../assets/img/traffic-icons/014-Report.svg",themeColor: Themes.TEAL,
          loc: "1566 0",
          settingData: {
            itemName: "Download Report",
            itemDescription: "",
            itemURL: "",
            utmMarketingSrc: "newsletter",
            utmMediumType: "email",
            utmCampaign: "spring_sale",
            utmTerm: "paid",
            utmContent: "newsletter",
            utmURL: "?utm_source=newsletter&utm_medium=email&utm_campaign=spring_sale&utm_term=paid&utm_content=newsletter",
            notes: [["11/15/17", "Note Goes Here and it can be long more than 1 line."], ["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."]],
          }      
        },
        { key: "Email2", category: "traffic-card", cardTitle: "Email", description: "", screenshot: "../../assets/img/traffic-icons/006-Email.svg",themeColor: Themes.TEAL,
          loc: "0, 286",
          settingData: {
            itemName: "Email",
            itemDescription: "",
            itemURL: "",
            utmMarketingSrc: "newsletter",
            utmMediumType: "email",
            utmCampaign: "spring_sale",
            utmTerm: "paid",
            utmContent: "newsletter",
            utmURL: "?utm_source=newsletter&utm_medium=email&utm_campaign=spring_sale&utm_term=paid&utm_content=newsletter",
            notes: [["11/15/17", "Note Goes Here and it can be long more than 1 line."], ["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."]],
          },
        },
        {key: "Text", category: "text-card", cardTitle: "Text", loc: "1566 211",}
      ],
      linkDataArray: [
        { from: "WatchVideo",  to: "LeadMagnet", arrowColor: Themes.ORANGE},
        { from: "LeadMagnet", to: "SalesPage", arrowColor: Themes.BLUE},
        { from: "SalesPage", to: "TrustTriggerOrderPage", arrowColor: Themes.BLUE},
        { from: "TrustTriggerOrderPage", to: "OrderConf", arrowColor: Themes.BLUE},
        { from: "OrderConf", to: "Email", arrowColor: Themes.BLUE},
        { from: "Email", to: "Report", arrowColor: Themes.TEAL},
        { from: "Email", to: "Text", arrowColor: Themes.TEAL},
      ]
    });
  funnelDiagram.startTransaction("initial config");
  funnelDiagram.links.each((x) => {  
    x.fromNode.findObject("card-bg").stroke = null;
    x.fromNode.findObject("connect-btn").visible = false;
  })
  funnelDiagram.commitTransaction("initial config");

  // Populate options for source select
  var sourceSelectData = "";
  funnelDiagram.nodes.each((n) => {
    sourceSelectData += "<option>" + n.data['cardTitle'] + "</option>";
  });
  $('#source-select').html(sourceSelectData);
  $('#edit-source-select').html(sourceSelectData);

  //Open New Parameter dropdown
  $('.create-btn').click(function() {
    $(this).parent().find('.add-dropdown-content input').val('');
    $(this).parent().find('.add-dropdown-content select option:first-child').prop('selected', true);
    $(this).parent().find('.add-dropdown-content').toggle();
  }); 
});

//Search filter in side bar
$(".searchWrapper input").on("keyup", function() {
  var container = $(".side-tab-content.active .tab-content");
  if ($(".side-tab-content.active .searchWrapper input").val() != "") {
    needle = $(".side-tab-content.active .searchWrapper input").val();
    var res = container.find(".nav-item").filter(function() {
      return ($(this).find(".nav-item-txt").text().toLowerCase().indexOf(needle.toLowerCase()) != -1) || ($(this).find(".nav-item-txt").text().toLowerCase() == needle.toLowerCase());
    });
    container.find(".nav-item").css('display', 'none');
    res.css('display', 'block');
  } else {
    container.find(".nav-item").css('display', 'block');
  }      
});

//preload template image
img_url = '../../assets/img/sampleTemplate.png';
var img = new Image();
img.src = img_url;

//Prepare Page Setting Data
function preparePageSettingTab(settingData) {
  $('.page-setting-tab #pageName').val(editingNode.data['cardTitle']);
  $('.page-setting-tab #pageDescription').val(settingData['pageDescription']);
  $('.page-setting-tab #pageURL').val(settingData["pageURL"]);
  $('.page-setting-tab .embed-code-textarea').val(settingData["embedCode"]);
  
  var tableData = "";
  $.each(settingData["params"], function(id, row) {
    tableData += "<tr>";
    $.each(row, function(id, col) {
      tableData += "<td>" + col + "</td>"
    })
    tableData += '<td><div class="dropdown"><i class="fa fa-cog" id="action-edit-btn" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></i><ul class="dropdown-menu" aria-labelledby="action-edit-btn"><li><a href="#"  class="edit-nav-item"><i class="fa fa-edit"></i> Edit</a></li><li><a href="#" class="delete-nav-item"><i class="fa fa-trash"></i> Delete</a></li></ul></div></td>';
    tableData += '</tr>';
  })
  $('.page-setting-tab #params-tab tbody').html(tableData);

  tableData = "";
  $.each(settingData["goals"], function(id, row) {
    tableData += "<tr>";
    $.each(row, function(id, col) {
      if(id != 3){
        if(id == 1)tableData += "<td>" + '$' + col + "</td>";
        else tableData += "<td>" + col + "</td>";
      }
    })
    tableData += '<td><div class="dropdown"><i class="fa fa-cog" id="action-edit-btn" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></i><ul class="dropdown-menu" aria-labelledby="action-edit-btn"><li><a href="#"  class="edit-nav-item"><i class="fa fa-edit"></i> Edit</a></li><li><a href="#" class="delete-nav-item"><i class="fa fa-trash"></i> Delete</a></li></ul></div></td>';
    tableData += '</tr>';
  })
  $('.page-setting-tab #goals-tab tbody').html(tableData);

  var notesData = "";
  $.each(settingData["notes"], function(id, item) {
    notesData += '<div class="note-item">' + '<span class="note-date"><i class="fa fa-calendar"></i>' + item[0] + '</span>';
    notesData += '<span class="note-content"><i class="fa fa-file"></i>' + item[1] + '</span>';
    notesData += '</div>';
  })
  $('.page-setting-tab .notes-list').html(notesData);  
}

//Save Page Setting Data
$('.page-setting-tab').on('hide', function() {
  funnelDiagram.model.setDataProperty(editingNode.data['settingData'], 'pageName', $(this).find('#pageName').val());
  funnelDiagram.model.setDataProperty(editingNode.data['settingData'], 'pageDescription', $(this).find('#pageDescription').val());
  funnelDiagram.model.setDataProperty(editingNode.data['settingData'], 'pageURL', $(this).find('#pageURL').val());
  var sourceSelectData = "";
  funnelDiagram.nodes.each((n) => {
    sourceSelectData += "<option>" + n.data['cardTitle'] + "</option>";
  });
  $('#source-select').html(sourceSelectData);
  $('#edit-source-select').html(sourceSelectData);
});

//Add parameter in Page Setting
$('.page-setting-tab .add-param-dropdown .add-btn').on('click', function() {
  newRow = '<tr><td>' + $('.page-setting-tab .add-param-dropdown #key-input').val() + '</td>';
  newRow += '<td>' + $('.page-setting-tab .add-param-dropdown #value-input').val() + '</td>';
  newRow += '<td>' + $('.page-setting-tab .add-param-dropdown #contain-select').find(':selected').text() + '</td>';
  newRow += '<td><div class="dropdown"><i class="fa fa-cog" id="action-edit-btn" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></i><ul class="dropdown-menu" aria-labelledby="action-edit-btn"><li><a href="#"  class="edit-nav-item"><i class="fa fa-edit"></i> Edit</a></li><li><a href="#" class="delete-nav-item"><i class="fa fa-trash"></i> Delete</a></li></ul></div></td>';
  newRow += '</tr>';
  updatedParams = editingNode.data['settingData']['params'];
  updatedParams.push(
    [
      $('.page-setting-tab .add-param-dropdown #key-input').val(),
      $('.page-setting-tab .add-param-dropdown #value-input').val(),
      $('.page-setting-tab .add-param-dropdown #contain-select').find(':selected').text()
    ]
  );
  $('.page-setting-tab #params-tab table tbody').append(newRow);
  funnelDiagram.model.setDataProperty(editingNode.data['settingData'], 'params', updatedParams);
  $('.page-setting-tab .add-param-dropdown .add-dropdown-content').toggle();
});

//Edit parameter in Page Setting
$('.page-setting-tab .edit-param-dropdown .add-btn').on('click', function() {
  editingRow = $('.page-setting-tab #params-tab tbody tr')[editingRowId];
  $($(editingRow).find('td')[0]).text($('.page-setting-tab .edit-param-dropdown #key-input').val());
  $($(editingRow).find('td')[1]).text($('.page-setting-tab .edit-param-dropdown #value-input').val());
  $($(editingRow).find('td')[2]).text($('.page-setting-tab .edit-param-dropdown #contain-select').val());
  updatedParams = editingNode.data['settingData']['params'];
  updatedParams[editingRowId][0] = $('.page-setting-tab .edit-param-dropdown #key-input').val();
  updatedParams[editingRowId][1] = $('.page-setting-tab .edit-param-dropdown #value-input').val();
  updatedParams[editingRowId][2] = $('.page-setting-tab .edit-param-dropdown #contain-select').val();
  funnelDiagram.model.setDataProperty(editingNode.data['settingData'], 'params', updatedParams);
  $('.page-setting-tab .edit-param-dropdown .add-dropdown-content').hide();
});

//Add goal in Page Setting
$('.page-setting-tab .add-goal-dropdown .add-btn').on('click', function() {
  newRow = '<tr><td>' + $('.page-setting-tab .add-goal-dropdown #name-input').val() + '</td>';
  newRow += '<td>' + '$' + $('.page-setting-tab .add-goal-dropdown #value-input').val() + '</td>';
  newRow += '<td>' + $('.page-setting-tab .add-goal-dropdown #type-select').find(':selected').text() + '</td>';
  newRow += '<td><div class="dropdown"><i class="fa fa-cog" id="action-edit-btn" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></i><ul class="dropdown-menu" aria-labelledby="action-edit-btn"><li><a href="#"  class="edit-nav-item"><i class="fa fa-edit"></i> Edit</a></li><li><a href="#" class="delete-nav-item"><i class="fa fa-trash"></i> Delete</a></li></ul></div></td>';
  newRow += '</tr>'
  updatedGoals = editingNode.data['settingData']['goals'];
  updatedGoals.push(
    [
      $('.page-setting-tab .add-goal-dropdown #name-input').val(),
      $('.page-setting-tab .add-goal-dropdown #value-input').val(),
      $('.page-setting-tab .add-goal-dropdown #type-select').find(':selected').text(),
      $('.page-setting-tab .add-goal-dropdown #source-select').find(':selected').text()
    ]
  );
  $('.page-setting-tab #goals-tab table tbody').append(newRow);
  funnelDiagram.model.setDataProperty(editingNode.data['settingData'], 'goals', updatedGoals);
  $('.page-setting-tab .add-goal-dropdown .add-dropdown-content').toggle();
});

//Edit goal in Page Setting
$('.page-setting-tab .edit-goal-dropdown .add-btn').on('click', function() {
  editingRow = $('.page-setting-tab #goals-tab tbody tr')[editingRowId];
  $($(editingRow).find('td')[0]).text($('.page-setting-tab .edit-goal-dropdown #name-input').val());
  $($(editingRow).find('td')[1]).text('$' + $('.page-setting-tab .edit-goal-dropdown #value-input').val());
  $($(editingRow).find('td')[2]).text($('.page-setting-tab .edit-goal-dropdown #type-select').val());
  updatedGoals = editingNode.data['settingData']['goals'];
  updatedGoals[editingRowId][0] = $('.page-setting-tab .edit-goal-dropdown #key-input').val();
  updatedGoals[editingRowId][1] = $('.page-setting-tab .edit-goal-dropdown #value-input').val();
  updatedGoals[editingRowId][2] = $('.page-setting-tab .edit-goal-dropdown #type-select').val();
  updatedGoals[editingRowId][3] = $('.page-setting-tab .edit-goal-dropdown #source-select').val();
  funnelDiagram.model.setDataProperty(editingNode.data['settingData'], 'goals', updatedGoals);
  $('.page-setting-tab .edit-goal-dropdown .add-dropdown-content').hide();
});

//Edit row in table
$('.setting-tab').on('click', '.dropdown .edit-nav-item', function(e) { 
  editingRowId = $(this).closest('tr').index();
  offset = 60;
  if($(this).closest('.setting-tab').hasClass('page-setting-tab')) {   
    if($(this).closest('.tab-pane').attr('id') == 'params-tab') {
      dropdownContent = $(this).closest('.tab-pane').find('.edit-param-dropdown .add-dropdown-content');
      rn = editingNode.data['settingData']['params'].length;
      for(i = editingRowId + 1; i < rn ; i ++) offset += $($(this).closest('tbody').find('tr')[i]).height();
      $(dropdownContent).css('top', -offset);
      $(dropdownContent).find('#key-input').val(editingNode.data['settingData']['params'][editingRowId][0]);
      $(dropdownContent).find('#value-input').val(editingNode.data['settingData']['params'][editingRowId][1]);
      $(dropdownContent).find('#contain-select').val(editingNode.data['settingData']['params'][editingRowId][2]);
      $(dropdownContent).show();
    } else {
      dropdownContent = $(this).closest('.tab-pane').find('.edit-goal-dropdown .add-dropdown-content');
      rn = editingNode.data['settingData']['goals'].length;
      for(i = editingRowId + 1; i < rn ; i ++) offset += $($(this).closest('tbody').find('tr')[i]).height();
      $(dropdownContent).css('top', -offset);
      $(dropdownContent).find('#name-input').val(editingNode.data['settingData']['goals'][editingRowId][0]);
      $(dropdownContent).find('#value-input').val(editingNode.data['settingData']['goals'][editingRowId][1]);
      $(dropdownContent).find('#type-select').val(editingNode.data['settingData']['goals'][editingRowId][2]);
      $(dropdownContent).find('#source-select').val(editingNode.data['settingData']['goals'][editingRowId][3]);
      $(dropdownContent).show();
    }
  } else {
    dropdownContent = $(this).closest('.tab-content').find('.edit-element-dropdown .add-dropdown-content');
    rn = editingNode.data['settingData']['elements'].length;
    for(i = editingRowId + 1; i < rn ; i ++) offset += $($(this).closest('tbody').find('tr')[i]).height();
    $(dropdownContent).css('top', -offset);
    $(dropdownContent).find('#key-input').val(editingNode.data['settingData']['elements'][editingRowId][0]);
    $(dropdownContent).find('#value-input').val(editingNode.data['settingData']['elements'][editingRowId][1]);
    $(dropdownContent).show();
  }
})

// Delete row in table
$('.setting-tab').on('click', '.dropdown .delete-nav-item', function(e) { 
  if($(this).closest('.setting-tab').hasClass('page-setting-tab')) {   
    if($(this).closest('.tab-pane').attr('id') == 'params-tab') {
      id = $(this).closest('tr').index();
      updatedParams = editingNode.data['settingData']['params'];
      updatedParams.splice(id, 1);
      funnelDiagram.model.setDataProperty(editingNode.data['settingData'], 'params', updatedParams);
    } else {
      id = $(this).closest('tr').index();
      updatedGoals = editingNode.data['settingData']['goals'];
      updatedGoals.splice(id, 1);
      funnelDiagram.model.setDataProperty(editingNode.data['settingData'], 'goals', updatedGoals);
    }
  } else {
    id = $(this).closest('tr').index();
    updatedElements = editingNode.data['settingData']['elements'];
    updatedElements.splice(id, 1);
    funnelDiagram.model.setDataProperty(editingNode.data['settingData'], 'elements', updatedElements);
  }
  $(this).closest('tr').remove();
})

// Add note in setting
$('.notes-panel .add-dropdown .add-btn').on('click', function() {
  currentDate = $.datepicker.formatDate('mm/dd/y', new Date());
  noteContent = $(this).parent().find('.note-textarea').val();
  var notesData = "";
  notesData += '<div class="note-item">' + '<span class="note-date"><i class="fa fa-calendar"></i>' + currentDate + '</span>';
  notesData += '<span class="note-content"><i class="fa fa-file"></i>' + noteContent + '</span>';
  notesData += '</div>';
  $(this).closest('.setting-slide-content').find('.notes-list').prepend(notesData); 
  updatedNotes = editingNode.data['settingData']['notes'];
  updatedNotes.unshift([currentDate, noteContent]);
  funnelDiagram.model.setDataProperty(editingNode.data['settingData'], 'notes', updatedNotes);
  $(this).closest('.setting-slide-content').find('.notes-list').scrollTop(0);
  $(this).parent().toggle();
});

//Prepare Traffic Setting data
function prepareTrafficSettingTab(settingData) {
  $('.traffic-setting-tab #itemName').val(editingNode.data['cardTitle']);
  $('.traffic-setting-tab #itemDescription').val(settingData["itemDescription"]);
  $('.traffic-setting-tab #itemURL').val(settingData["itemURL"]);
  $('.traffic-setting-tab #utm_source').val(settingData["utmMarketingSrc"]);
  $('.traffic-setting-tab #utm_medium').val(settingData["utmMediumType"]);
  $('.traffic-setting-tab #utm_campaign').val(settingData["utmCampaign"]);
  $('.traffic-setting-tab #utm_term').val(settingData["utmTerm"]);
  $('.traffic-setting-tab #utm_content').val(settingData["utmContent"]);
  $('.traffic-setting-tab #utmURL').val(settingData["utmURL"]);

  var notesData = "";
  $.each(settingData["notes"], function(id, item) {
    notesData += '<div class="note-item">' + '<span class="note-date"><i class="fa fa-calendar"></i>' + item[0] + '</span>';
    notesData += '<span class="note-content"><i class="fa fa-file"></i>' + item[1] + '</span>';
    notesData += '</div>';
  })
  $('.traffic-setting-tab .notes-list').html(notesData);  
}

//Save Traffic Setting Data
$('.traffic-setting-tab').on('hide', function() {
  funnelDiagram.model.setDataProperty(editingNode.data['settingData'], 'itemName', $(this).find('#itemName').val());
  funnelDiagram.model.setDataProperty(editingNode.data['settingData'], 'itemDescription', $(this).find('#itemDescription').val());
  funnelDiagram.model.setDataProperty(editingNode.data['settingData'], 'itemURL', $(this).find('#itemURL').val());
  funnelDiagram.model.setDataProperty(editingNode.data['settingData'], 'utmMarketingSrc', $(this).find('#utm_source').val());
  funnelDiagram.model.setDataProperty(editingNode.data['settingData'], 'utmMediumType', $(this).find('#utm_medium').val());
  funnelDiagram.model.setDataProperty(editingNode.data['settingData'], 'utmCampaign', $(this).find('#utm_campaign').val());
  funnelDiagram.model.setDataProperty(editingNode.data['settingData'], 'utmTerm', $(this).find('#utm_term').val());
  funnelDiagram.model.setDataProperty(editingNode.data['settingData'], 'utmContent', $(this).find('#utm_content').val());
  funnelDiagram.model.setDataProperty(editingNode.data['settingData'], 'utmURL', $(this).find('#utmURL').val());
  var sourceSelectData = "";
  funnelDiagram.nodes.each((n) => {
    sourceSelectData += "<option>" + n.data['cardTitle'] + "</option>";
  });
  $('#source-select').html(sourceSelectData);
});

//Prepare Action Setting Data
function prepareActionSettingTab(settingData) {
  $('.action-setting-tab #actionName').val(editingNode.data['cardTitle']);
  $('.action-setting-tab #actionDescription').val(settingData['actionDescription']);
  $('.action-setting-tab .embed-code-textarea').val(settingData["embedCode"]);
  
  var tableData = "";
  $.each(settingData["elements"], function(id, row) {
    tableData += "<tr>";
    $.each(row, function(id, col) {
      tableData += "<td>" + col + "</td>"
    })
    tableData += '<td><div class="dropdown"><i class="fa fa-cog" id="action-edit-btn" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></i><ul class="dropdown-menu" aria-labelledby="action-edit-btn"><li><a href="#"  class="edit-nav-item"><i class="fa fa-edit"></i> Edit</a></li><li><a href="#" class="delete-nav-item"><i class="fa fa-trash"></i> Delete</a></li></ul></div></td>';
    tableData += '</tr>';
  })
  $('.action-setting-tab tbody').html(tableData);

  var notesData = "";
  $.each(settingData["notes"], function(id, item) {
    notesData += '<div class="note-item">' + '<span class="note-date"><i class="fa fa-calendar"></i>' + item[0] + '</span>';
    notesData += '<span class="note-content"><i class="fa fa-file"></i>' + item[1] + '</span>';
    notesData += '</div>';
  })
  $('.action-setting-tab .notes-list').html(notesData);    
}

//Save Action Setting Data
$('.action-setting-tab').on('hide', function() {
  funnelDiagram.model.setDataProperty(editingNode.data['settingData'], 'actionName', $(this).find('#actionName').val());
  funnelDiagram.model.setDataProperty(editingNode.data['settingData'], 'actionDescription', $(this).find('#actionDescription').val());
  var sourceSelectData = "";
  funnelDiagram.nodes.each((n) => {
    sourceSelectData += "<option>" + n.data['cardTitle'] + "</option>";
  });
  $('#source-select').html(sourceSelectData);
});

//Add tracking element in Action Setting
$('.action-setting-tab .add-element-dropdown .add-btn').on('click', function() {
  newKey = $('.action-setting-tab .add-element-dropdown #key-input').val();
  newValue = $('.action-setting-tab .add-element-dropdown #value-input').val();

  newRow = '<tr><td>' + newKey + '</td>';
  newRow += '<td>' + newValue + '</td>';
  newRow += '<td><div class="dropdown"><i class="fa fa-cog" id="action-edit-btn" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></i><ul class="dropdown-menu" aria-labelledby="action-edit-btn"><li><a href="#"  class="edit-nav-item"><i class="fa fa-edit"></i> Edit</a></li><li><a href="#" class="delete-nav-item"><i class="fa fa-trash"></i> Delete</a></li></ul></div></td>';
  newRow += '</tr>'

  updatedElements = editingNode.data['settingData']['elements'];
  updatedElements.push([newKey, newValue]);
  $('.action-setting-tab table tbody').append(newRow);

  updatedEmbedCode = $('.action-setting-tab .embed-code-textarea').val();
  fstr = updatedEmbedCode.substr(0, updatedEmbedCode.indexOf("}"));
  bstr = updatedEmbedCode.substr(updatedEmbedCode.indexOf("}"));
  updatedEmbedCode = fstr + newKey + ": '" + newValue + "'," + bstr;
  $('.action-setting-tab .embed-code-textarea').val(updatedEmbedCode);

  funnelDiagram.model.setDataProperty(editingNode.data['settingData'], 'elements', updatedElements);
  funnelDiagram.model.setDataProperty(editingNode.data['settingData'], 'embedCode', updatedEmbedCode);
 
  $('.action-setting-tab .add-element-dropdown .add-dropdown-content').toggle();
});

//Edit tracking element in Action Setting
$('.action-setting-tab .edit-element-dropdown .add-btn').on('click', function() {
  editingRow = $('.action-setting-tab tbody tr')[editingRowId];
  oldKey = $($(editingRow).find('td')[0]).text();
  oldValue = $($(editingRow).find('td')[1]).text();
  newKey = $('.action-setting-tab .edit-element-dropdown #key-input').val();
  newValue = $('.action-setting-tab .edit-element-dropdown #value-input').val();
  $($(editingRow).find('td')[0]).text($('.action-setting-tab .edit-element-dropdown #key-input').val());
  $($(editingRow).find('td')[1]).text($('.action-setting-tab .edit-element-dropdown #value-input').val());
  updatedElements = editingNode.data['settingData']['elements'];
  updatedElements[editingRowId][0] = $('.action-setting-tab .edit-element-dropdown #key-input').val();
  updatedElements[editingRowId][1] = $('.action-setting-tab .edit-element-dropdown #value-input').val();
  funnelDiagram.model.setDataProperty(editingNode.data['settingData'], 'elements', updatedElements);
  oldEmbedCode = $('.action-setting-tab .embed-code-textarea').val();
  updatedEmbedCode = oldEmbedCode.replace(oldKey + ": '" + oldValue + "',", newKey + ": '" + newValue + "',");
  $('.action-setting-tab .embed-code-textarea').val(updatedEmbedCode);
  $('.action-setting-tab .edit-element-dropdown .add-dropdown-content').hide();
});

//Close sidebar
$(".close-sidebar-button").click(function() {
  $("#sidebar-wrapper").css("left", "0");
  $('.setting-tab.active').hide(900);
  $('.setting-tab.active').removeClass('active');
});

//config draggable item
$(".nav-item").draggable({
  stack: "#edit-div",
  revert: true,
  helper: "clone",
  revertDuration: 0
});

//Add card when dropped in the edit div
$("#edit-div").droppable({
  drop: function(event, ui) {
    closeOpenFloatingControls();
    var elt = ui.draggable.first();
    var text = $(elt[0]).find('.nav-item-txt').text();
    var x = ui.offset.left - $(this).offset().left;
    var y = ui.offset.top - $(this).offset().top;
    var p = new go.Point(x, y);
    var q = funnelDiagram.transformViewToDoc(p);
    var model = funnelDiagram.model;
    funnelDiagram.startTransaction("drop");
    if($(elt[0]).closest('.side-tab-content').hasClass('page-tab')) {
      model.addNodeData({
        key: text, category: "page-card", pageType:"Optin Page",
        headingIcon: "../../assets/img/optin-page-card.svg", cardTitle: text, screenshot: $(elt[0]).find('img').attr('src'), themeColor: Themes.BLUE,
        description: "",
        settingData: {
          pageName: text,
          pageURL: "www.MySite.com/page",
          pageDescription: "",
          embedCode: '<script type="text/javascript">window.onload = function() {window.funnelytics.events.trigger("video", {video: "Upsell Video",}, function() {// continue with process..});};</script>',
          params: [["a", "Yes", "Contain"], ["firstname", "John", "Contain"], ["lastname", "Smith", "Doesn't Contain"]],
          goals: [["Salesp Page", "$29", "Lead"], ["Order", "$30", "Sale"], ["Rep Page", "$40", "Application"]],
          notes: [["11/15/17", "Note Goes Here and it can be long more than 1 line."], ["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."],["12/15/17", "Note Goes Here and it can be long more than 1 line."]],
        },
        loc: go.Point.stringify(q)
      });
    } else if($(elt[0]).closest('.side-tab-content').hasClass('traffic-tab')) {
      model.addNodeData({
        key: text, category: "traffic-card", cardTitle: text, screenshot: $(elt[0]).find('img').attr('src').replace('png', 'svg'), themeColor: Themes.TEAL,
        description: "",
        settingData: {
          itemName: text,
          notes: []
        },
        loc: go.Point.stringify(q)
      });
    } else if($(elt[0]).closest('.side-tab-content').hasClass('action-tab')) {
      if($(elt[0]).index() == 0) {
        model.addNodeData({
          key: "Text" + (new Date().getTime()),
          category: "text-card",
          loc: go.Point.stringify(q)
        });
      } else {
        model.addNodeData({
          key: text, category: "action-card", cardTitle: text, screenshot: $(elt[0]).find('img').attr('src').replace('png', 'svg'), themeColor: Themes.ORANGE,
          description: "",
          settingData: {
            actionName: text,
            elements: [],
            notes: [],
          },
          loc: go.Point.stringify(q)
        });
      }
    } else {
      model.addNodeDataCollection(templateArray[text][0]);
      model.addLinkDataCollection(templateArray[text][1]);
      var coll = new go.Set();
      var copiedColl = new go.Map();
      templateArray[text][0].forEach(function(d) {
        coll.add(funnelDiagram.findPartForData(d));
      });
      templateArray[text][1].forEach(function(d) {
        coll.add(funnelDiagram.findPartForData(d));
      })

      copiedColl = funnelDiagram.copyParts(coll, funnelDiagram, false);
      funnelDiagram.removeParts(coll)
      coll.clear();

      copiedColl.each(function(kvp) {
        coll.add(kvp.value);
      });
        
      var bounds = funnelDiagram.computePartsBounds(coll);
      funnelDiagram.moveParts(coll, q.copy().subtract(bounds.center), false); 
      funnelDiagram.links.each((x) => {  
        x.fromNode.findObject("card-bg").stroke = null;
        x.fromNode.findObject("connect-btn").visible = false;
      })
    }
    var sourceSelectData = "";
    funnelDiagram.nodes.each((n) => {
      sourceSelectData += "<option>" + n.data['cardTitle'] + "</option>";
    });
    $('#source-select').html(sourceSelectData);
    funnelDiagram.commitTransaction("drop");
  }
})

// Toggle icon when click exit button in the header
$('.back-btn').click(function() {
  $(".back-btn i:nth-child(n+2)").toggleClass("fa-caret-down").toggleClass("fa-caret-up");
});

// Display notification when click save btn
$(".save-map").click(function(e){
  var message = $(this).attr("data-message");
  e.preventDefault();
  noty({
    text: message,
    layout: 'topCenter',
    type: 'success',
    timeout: 1000,
    closeWith: ['click', 'button'],
    animation: {
        open : 'animated fadeIn',
        close: 'animated fadeOut'
    }
  });
});

//display help video when click help video btn
$(".help-video-container").click(function() {
  $(".help-video-container .video-container").slideToggle();
  var hideVideo = $(".help-video-container .video-container .checkbox input").prop('checked');
  $('.yvideo').each(function() {
    var play = 0;
    if ($(this).hasClass("stopped")) {
      if (!hideVideo) {
        play = 1;
      } else {
        play = 0;
      }
      $(this).removeClass("stopped");
      $(this).show(0);
    } else {
      $(this).hide(0);
      play = 0;
      $(this).addClass("stopped");
    }
    var str = $(this).attr('src');
    str = str.substring(0, str.length - 1);
    $(this).attr('src', str + play);
    return false;
  });

  $(".help-video-container .line i:nth-child(n+2)").toggleClass("fa-caret-down").toggleClass("fa-caret-up");
});

//Click floating-btn
$(".floating-btn").click(function() {
  if ($(this).hasClass("active")) {
    closeOpenFloatingControls();
  } else {
    if ($(".floating-btn.active").length > 0) {
      closeOpenFloatingControls();
    } else {
      $(".floating-btn").removeClass("active");
      $('.side-tab-content').removeClass("active");
    }

    $(".floating-btn").addClass("no-hover");
    $(this).addClass("active");

    if ($(this).hasClass("left-menu-traffic-btn")) {
      $('.side-tab-content.traffic-tab').addClass("active");
    } else if ($(this).hasClass("left-menu-action-btn")) {
      $('.side-tab-content.action-tab').addClass("active");
    } else if ($(this).hasClass("left-menu-funnel-btn")) {
      $('.side-tab-content.funnel-tab').addClass("active");
    } else if ($(this).hasClass("left-menu-page-btn")) {
      $('.side-tab-content.page-tab').addClass("active");
    }
    $('.side-tab-content.active .searchWrapper input').val("");
    $('.side-tab-content.active .nav-item').css('display', 'block');

  }
});

//Close side tab
$(".content-side-header-btn.close-btn").click(function() {
  closeOpenFloatingControls();
});

function closeOpenFloatingControls() {
  $(".floating-btn.active").find(".active-btn-icon").css("display", "none");
  $(".floating-btn.active").removeClass("active");
  $('.side-tab-content.active').removeClass("active");
  $(".floating-btn").removeClass("no-hover");
  setTimeout(function() {
    $(".active-btn-icon").css("display", "inline-block");
  }, 500);
}

//Toggle setting slide header
$(".setting-tab .setting-slide-panel .setting-slide-header").click(function() {
  if($(this).parent().find(".setting-slide-content").hasClass('active')) {
    $(this).parent().find(".setting-slide-content").removeClass('active');
  } else {
    $(this).closest('.setting-tab').find('.setting-slide-content.active').slideToggle();
    $(this).closest('.setting-tab').find('.setting-slide-content.active').parent().find(".setting-expand-panel i").toggleClass("fa-angle-down").toggleClass("fa-angle-up");
    $(this).closest('.setting-tab').find('.setting-slide-content.active').removeClass('active');
    $(this).parent().find(".setting-slide-content").addClass('active');
  }
  $(this).parent().find(".setting-slide-content").slideToggle();
  $(this).find(".setting-expand-panel i").toggleClass("fa-angle-down").toggleClass("fa-angle-up");
});

//Character counts for forms
$('.counter-input').on('keyup', function(event) {
  var len = $(this).val().length;
  $(this).parent().find(".updateCounter").text(len);
});

//Sync card title with input field
$('.setting-tab .counter-input').on('keyup', function(event) {
  funnelDiagram.model.setDataProperty(editingNode.data, 'cardTitle', $(this).val());
});

//Sync description with input field
$('.desc-input').on('keyup', function(event) {
  funnelDiagram.model.setDataProperty(editingNode.data, 'description', $(this).val());
});

//Update UTM URL whenever one element changes
$('.traffic-setting-tab .utm-input').on('keyup', function(event) {
  console.log(oldUrl.search($(this).attr('id')+'='+oldValue));
  $('.traffic-setting-tab .utm-url-textarea').val(oldUrl.replace($(this).attr('id')+'='+oldValue, $(this).attr('id')+'='+$(this).val()));
  console.log($('.traffic-setting-tab .utm-url-textarea').val());
});
$('.traffic-setting-tab .utm-input').on('keydown', function(event) {
  oldValue = $(this).val();
  oldUrl = $('.traffic-setting-tab .utm-url-textarea').val();
});

//Define show/hide handler
(function ($) {
  $.each(['show', 'hide'], function (i, ev) {
    var el = $.fn[ev];
    $.fn[ev] = function () {
      this.trigger(ev);
      return el.apply(this, arguments);
    };
  });
})(jQuery);

//Init counter-input when settin-tab is shown
$('.setting-tab').on('show', function() {
  var len = $(this).find('.counter-input').val().length;
  $(this).find(".updateCounter").text(len);
})

//Init mCustomScrollbar 
$('.customScroll').mCustomScrollbar({
  theme: "minimal",
  axis: "y",
  scrollInertia: 100
});

// Switch goal
$('#goalSwitcher').change(function() {
  if ($(this).is(':checked')) {
    $(this).closest('#goals-tab').find('.switching-content').show();
  } else {
    $(this).closest('#goals-tab').find('.switching-content').hide();
  }
})

//Change card thumbnail
$(document).on('click', '.thumb-img', function() {
  if($(this).closest('.setting-tab').hasClass('page-setting-tab')) {
    funnelDiagram.model.setDataProperty(editingNode.data, 'screenshot', $(this).attr('src'));
  } else {
    funnelDiagram.startTransaction("change layout");
    if($(this).hasClass('6*7')) {
      editingNode.findObject("border").desiredSize = new go.Size(180, 230);
      editingNode.findObject("screenshot").desiredSize = new go.Size(120,140);
      editingNode.findObject("plus-btn-panel").position = new go.Point(133, 70);
    } else {
      editingNode.findObject("border").desiredSize = new go.Size(120, 150);
      editingNode.findObject("screenshot").desiredSize = new go.Size(60, 60);
      editingNode.findObject("plus-btn-panel").position = new go.Point(72, 30);
    }
    funnelDiagram.commitTransaction("change layout");
    settingMenu.css({left: funnelDiagram.transformDocToView(editingNode.location).x + editingNode.actualBounds.width / 2 * funnelDiagram.scale - $(settingMenu).width() / 2});
          settingMenu.css({top: funnelDiagram.transformDocToView(editingNode.location).y + editingNode.actualBounds.height * funnelDiagram.scale + 10});
    funnelDiagram.model.setDataProperty(editingNode.data, 'screenshot', $(this).attr('src').replace('png', 'svg'));
  }
})

// Init Clipboard
var clipboard = new Clipboard('.copy-btn');
var notyName;

$('.copy-btn').on('click', function() {
  notyName = $(this).attr('data-name');
});

clipboard.on('success', function(e) {
    e.clearSelection();
    copySuccess(notyName);
});

// Success Function to Show the Top Right Success Notification After Copying
function copySuccess (name) {
  var naughty = noty({
      text: name + ' Copied to Clipboard Successfully',
      layout: 'topCenter',
      type: 'success',
      timeout: 1000,
      closeWith: ['click', 'button'],
      animation: {
        open : 'animated fadeIn',
        close: 'animated fadeOut'
      }
  }).show();
}

// Check if diagram has at least one element before Save Template Modal
$('#saveTemplateBtn').on('click', function() {
  if(!funnelDiagram.nodes.count) {
    noty({
      text: "You Should Have At Least 1 Element To Save As Template",
      layout: 'topCenter',
      type: 'warning',
      timeout: 1000,
      closeWith: ['click', 'button'],
      animation: {
          open : 'animated fadeIn',
          close: 'animated fadeOut'
      }
    });
  } else {
    $('#save-template-modal').modal();
  }
})
//Init updateCounter in Save Template Modal
$('#save-template-modal').on('show.bs.modal', function(e) {
  $('#save-template-modal .counter-input').val("");
  $('#save-template-modal .updateCounter').text("0");
});


/*Template name validation in modal*/
$('#save-template-modal .counter-input').on('input', function() {
  var count = $(this).val().length;
  if (count > 0) {
    $(this).removeClass('error');
    $('#save-template-modal .validation').css("display","none");
    $('#save-template-modal .pageNameCount span').text(count);
  }
});

// Get clicks on the save button in the Save As Template popup modal
$(document).on('click' ,'#save-template-modal .btn-success', function() {
  var pageName = $(this).closest('.modal').find('.counter-input');
  var inputLength = pageName.val().length;
  validForm = false;
  if (inputLength == 0) {
    pageName.addClass('error');
    $('#save-template-modal .validation').css("display","block");
    validForm =false;
  }
  else {
    pageName.removeClass('error');
    vaildForm = true;
    $('#save-template-modal .validation').css("display","none");
    var img = funnelDiagram.makeSvg({
      scale: 1,
      background: "#E9E9E9",
    });

    var vb;
    $(img).each(function() {
      $.each(this.attributes, function() {
        if(this.specified) {
          if(this.name == "ZL") vb = this.value;
        }
      });
    });
    $(img).width("340px");
    $(img).height("auto");
    img.setAttribute("viewBox", vb);
    img.setAttribute("overflow", "visible");
    templateName = $("#save-template-modal .counter-input").val();
    templateItem = '<div class="nav-item"';
    templateItem += 'data-trigger="hover" data-toggle="popover" data-container="body" data-placement="right" data-html="true" data-content=' + "'" + img.outerHTML + "'>";
    templateItem += '<div class="nav-item-container"><img src="../../assets/img/funnel-template.png" class="nav-item-icon"><p class="nav-item-txt">';
    templateItem += templateName + '</p></div></div>';

    $('.funnel-tab .tab-content').append(templateItem);
    $('[data-toggle="popover"]').popover();
    $(".nav-item").draggable({
      stack: "#edit-div",
      revert: true,
      helper: "clone",
      revertDuration: 0
    });

    var parts = new go.Set();
    funnelDiagram.nodes.each((n) => {
      parts.add(n);
    });
    funnelDiagram.links.each((l) => {
      parts.add(l);
    });

    var nodesCnt = funnelDiagram.model.nodeDataArray.length;
    var linksCnt = funnelDiagram.model.linkDataArray.length;

    var copiedParts = new go.Map();
    copiedParts = funnelDiagram.copyParts(parts, funnelDiagram, false);
    templateArray[templateName] = [funnelDiagram.model.nodeDataArray.slice(nodesCnt), funnelDiagram.model.linkDataArray.slice(linksCnt)];
    copiedParts.each(function(kvp) {
      funnelDiagram.remove(kvp.value);
    })

    $("#save-template-modal .counter-input").val('');
    $("#save-template-modal").modal("hide");
  }
});

$('#colorSelector').ColorPicker({
  onShow: function() {
    settingMenu.hide();
  },
  onChange: function (hsb, hex, rgb) {
    editingNode.findObject('text-content').stroke = "rgb("+ rgb['r'] + ',' + rgb['g'] + ',' + rgb['b'] + ')';
  }
})

// Close floating control when background is clicked
$(document).mouseup(function(e){
    var container = $(".side-tab-content.active");
    // If the target of the click isn't the container
    if(!container.is(e.target) && container.has(e.target).length === 0){
        closeOpenFloatingControls();
    }
});