$("#contactPhone").intlTelInput();
$("#companyContactPhone").intlTelInput();
$("#businessPhone").intlTelInput();
$('#countryDDL').flagStrap();
$('#companyCountryDDL').flagStrap();

// form validation
// first override jquery validate plugin defaults
$.validator.addMethod("customemail",
  function(value, element) {
    return /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/.test(value);
  },
  "Please enter a valid email address."
);
$.validator.addMethod("phoneNumber",
  function(value, element) {
    if(value == '') return true;
    return /^[+]*[(]{0,1}[0-9]{1,4}[)]{0,1}[-\s\./0-9]*$/.test(value);
  },
  "Please enter a valid phone number."
);
$.validator.setDefaults({
  highlight: function(element) {
    if ($(element).is('select')) {
      $(element).parent().find('.btn-default').addClass('selectError');
    } else {
      $(element).closest('.form-group').addClass('has-error');
    }
  },
  unhighlight: function(element) {
    if ($(element).is('select')) {
      $(element).parent().find('.btn-default').removeClass('selectError');
    } else {
      $(element).closest('.form-group').removeClass('has-error');
    }
  },
  errorElement: 'span',
  errorClass: 'help-block',
  errorPlacement: function(error, element) {
    if (element.attr('type') === 'checkbox' || element.attr('type') === 'radio') {
      error.insertAfter(element.closest('.form-group').find('label'));
    } else if (element.parent('.input-group').length) {
      error.insertAfter(element.parent());
    } else if ($(element).is('select')) {
      element.next().after(error); // special placement for select elements
    } else {
      error.insertAfter(element);
    }
  }
});
// form validation rules (by the name tag)
function validateForm(formObj) {
  var jvalidate = formObj.validate({
    ignore: [],
    rules: {
      // Individual info
      firstName: {
        required: true,
      },
      lastName: {
        required: false,
      },
      email: {
        required: true,
        email: true,
      },
      contactPhone: {
        required: true,
        phoneNumber: true
      },
      website: {
        required: true,
        url: true
      },

      // Company Info
      companyName: {
        required: true,
        maxlength: 100
      },
      address: {
        maxlength: 100
      },
      city: {
        maxlength: 100
      },
      state: {
        maxlength: 100
      },
      postcode: {
        number: true
      },
      businessPhone: {
        required: true,
        phoneNumber: true
      },
      companyContactPhone: {
        required: true,
        phoneNumber: true,
      },
      businessWebsite: {
        required: true,
        url: true,
      }
    },
    messages: {
      agreement1: "You Must Agree To The Terms Of Service"
    }
  });
}

//Toggle Individual/Company tab
$('.samewidthx span').click(function() {
  if(!$(this).hasClass('active')) {
    $(this).addClass('active');
    if($(this).hasClass('local')) {
      $('.online').removeClass('active');
      $('#individualForm').show();
      $('#companyForm').hide();
    } else {
      $('.local').removeClass('active');
      $('#companyForm').show();
      $('#individualForm').hide();
    }
  } 
});

// any form that has a button with id nextBtn, will be validated and submitted. maybe too generic!
$(document).on('click', '.nextBtn', function(ev) {
  ev.preventDefault();
  var formObj;
  if($('.toggleStyle .local').hasClass('active')) {
    formObj = $("#individualForm");
  } else {
    formObj = $("#companyForm");
  }
  validateForm(formObj);
  if (formObj.valid() === true) {
  } else {
    // do not submit untill errors are corrected
  }
});

