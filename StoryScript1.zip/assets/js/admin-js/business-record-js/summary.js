//SLIDER
var slides = document.querySelectorAll('#slides .slide');
var currentSlide = 0;
var slideInterval = setInterval(nextSlide, 4000);

function nextSlide() {
  slides[currentSlide].className = 'slide';
  currentSlide = (currentSlide + 1) % slides.length;
  slides[currentSlide].className = 'slide showing';
}

// Init tags input
$('.form-group input.tag-box').tagsinput();

$(document).on('mouseenter', '.name-span', function() {
	if (this.offsetWidth < this.scrollWidth) {
		$(this).popover({
			container: 'body',
			content: $(this).text(),
			placement: 'top',
			trigger: 'hover',
		});
		$(this).popover('show');
	}
});

// Delete thumb
$('.delete-thumb-btn').click(function() {
  $(this).closest(".upload-thumb").find('.img-thumbnail').attr('src', '../../assets/img/thumb-upload-bg.png');
  $(this).closest(".upload-thumb").removeClass("uploaded");
  console.log("ok");
})
