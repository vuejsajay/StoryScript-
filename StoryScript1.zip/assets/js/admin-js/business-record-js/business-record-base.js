var youtubeReg = /(http:\/\/|https:\/\/|)?youtu(?:\.be|be\.com)\/(?:watch\?v=|embed\/)?([a-z0-9_\-]+)/i; 
var vimeoReg = /(http:\/\/|https:\/\/|)?vimeo.com\/([0-9a-z\-_]+)/i;

// Search Filter
function FilterAllConditions(obj) {
  var container = $(".tab-pane");
  filterType = $("#select-funnel-type").find(':selected').attr('data-filter');
  tag = $("#selectTag").length > 0 ? $("#selectTag").find(':selected').attr('data-filter') : "";
  var needle = "";
  //Start Reset Filter
  container.find(".item-container .col-xs-3").css('display', 'block');
  //Start Filtering
  var res = container.find(".banner-item");
  if ($(".searchWrapper input").val() != "") {
    needle = $(".searchWrapper input").val();
    var res1 = container.find(".banner-item").filter(function() {
      return ($(this).find(".top-title span").text().toLowerCase().indexOf(needle.toLowerCase()) != -1) || ($(this).find(".top-title span").text().toLowerCase() == needle.toLowerCase());
    });
    //Hide All Elements
    container.find(".item-container .col-xs-3").css('display', 'none');
    res1.parent().css('display', 'none');
    if(filterType == 'my-funnels') {
      res1.filter(function() {
        return $(this).find('.my-temp-icon').length != 0;
      }).filter(function() {
        return $(this).find(".tags").text().indexOf(tag) != -1;
      }).parent().css('display', 'block');
    } else {
      res1.filter(filterType).filter(function() {
        return $(this).find(".tags").text().indexOf(tag) != -1;
      }).parent().css('display', 'block');
    }
  } else {
    res.parent().css('display', 'none');
    if(filterType == 'my-funnels') {
      res.filter(function() {
        return $(this).find('.my-temp-icon').length != 0;
      }).filter(function() {
        return $(this).find(".tags").text().indexOf(tag) != -1;
      }).parent().css('display', 'block');
    } else {
      res.filter(filterType).filter(function() {
        return $(this).find(".tags").text().indexOf(tag) != -1;
      }).parent().css('display', 'block');
    }
  }
  $('.from-scratch').parent().show();
}

// Real time filter
$(".searchWrapper input").on("keyup", function() {
  $(this).parents(".searchfunnel").find("input").attr("placeholder", "Search Templates...");
  FilterAllConditions($(this));
  //Hide dropdown
  var container = $(".searchfunnel:visible");
  container.find(".dropdown-menu.inner").hide();
  //return false;
});

// Init validator
$.validator.setDefaults({
  highlight: function(element) {
    if ($(element).is('select')) {
      $(element).parent().find('.btn-default').addClass('selectError');
    } else {
      $(element).closest('.form-group').addClass('has-error');
    }
  },
  unhighlight: function(element) {
    if ($(element).is('select')) {
      $(element).parent().find('.btn-default').removeClass('selectError');
    } else {
      $(element).closest('.form-group').removeClass('has-error');
    }
  },
  errorElement: 'span',
  errorClass: 'help-block',
  errorPlacement: function(error, element) {
    if (element.attr('type') === 'checkbox' || element.attr('type') === 'radio') {
      error.insertAfter(element.closest('.form-group').find('label'));
    } else if (element.parent('.input-group').length) {
      error.insertAfter(element.parent());
    } else if ($(element).is('select')) {
      element.next().after(error); // special placement for select elements
    } else {
      error.insertAfter(element);
    }
  }
});

$.validator.addMethod("youtubeORvimeo", function(value, element) {
  return youtubeReg.test(value) || vimeoReg.test(value);
}, "");

// form validation rules (by the name tag)
function validateForm(formObj) {
  var jvalidate = formObj.validate({
    ignore: [],
    rules: {
      // Individual info
      templateName: {
        required: true,
      },
      description: {
        required: true,
      },
      videoUrl: {
        required: true,
        youtubeORvimeo: true,
      }
    },
  });
}

// Show Save As Template page
$('.sat-btn').on('click', function() {
  $('#mainPage').toggle();
  $('#saveAsTemplatePage').toggle();
  $('body').toggleClass('sat-opened');
});

// Show Save As Template page
$('.saat-btn').on('click', function() {
  $('#mainPage').toggle();
  $('#saveAsAdminTemplatePage').toggle();
  $('body').toggleClass('sat-opened');
});

// Hide Save As Template Page
$('#saveAsTemplatePage .backBtn').click(function() {
  $('#mainPage').toggle();
  $('#saveAsTemplatePage').toggle();
  $('body').toggleClass('sat-opened');
})

$('#saveAsAdminTemplatePage .backBtn').click(function() {
  $('#mainPage').toggle();
  $('#saveAsAdminTemplatePage').toggle();
  $('body').toggleClass('sat-opened');
})

// Click save template btn
$('.save-template-btn').click(function(e) {
  e.preventDefault();
  var formObj= $("#saveTemplateForm");
  validateForm(formObj);
  if (formObj.valid() === true) {
    $('#mainPage').toggle();
    $('#saveAsTemplatePage').toggle();
    $('body').toggleClass('sat-opened');
    formObj.submit();
  } else {
    $("#saveTemplateForm .valid-mark").css('visibility', 'visible');
    if($("#videoUrl").closest('.form-group').hasClass("has-error")) {
      $("#saveTemplateForm .valid-mark").removeClass("valid").addClass("invalid");
      $("#saveTemplateForm .valid-mark i").removeClass("fa-check").addClass("fa-times");
    } else {
      $("#saveTemplateForm .valid-mark").removeClass("invalid").addClass("valid");
      $("#saveTemplateForm .video-icon").css("visibility", "visible");
      $("#saveTemplateForm .valid-mark i").removeClass("fa-times").addClass("fa-check");
    }
  }
})

// Validate video url
$("#saveTemplateForm #videoUrl, #saveAdminTemplateForm #videoUrl").on('keyup', function() {
  
  if(youtubeReg.test($(this).val())) {
    $(this).closest(".saveTemplateForm").find(".video-icon").css("visibility", "visible");
    $(this).closest(".saveTemplateForm").find(".video-icon i").removeClass("fa-vimeo").addClass('fa-youtube');
  } else if(vimeoReg.test($(this).val())) {
    $(this).closest(".saveTemplateForm").find(".video-icon").css("visibility", "visible");
    $(this).closest(".saveTemplateForm").find(".video-icon i").removeClass("fa-youtube").addClass('fa-vimeo');
  } else {
    $(this).closest(".saveTemplateForm").find(".video-icon").css("visibility", "hidden");
  }
})


// Update counter for real time
$('.counting-field').on('keyup', function(event) {
  var len = $(this).val().length;
  $(this).closest(".formField").find(".update-counter").text(len);
});

// Responsive dropdown
$(document).on("shown.bs.dropdown", ".dropdown", function () {
  // calculate the required sizes, spaces
  var $ul = $(this).children(".dropdown-menu");
  var $button = $(this).children(".dropdown-toggle");
  var ulOffset = $ul.offset();
  // how much space would be left on the top if the dropdown opened that direction
  var spaceUp = (ulOffset.top - $button.height() - $ul.height()) - $(window).scrollTop();
  // how much space is left at the bottom
  var spaceDown = $(window).scrollTop() + $(window).height() - (ulOffset.top + $ul.height());
  // switch to dropup only if there is no space at the bottom AND there is space at the top, or there isn't either but it would be still better fit
  if (spaceDown < 0 && (spaceUp >= 0 || spaceUp > spaceDown)){
    $(this).addClass("dropup");
    // $('.dropup .dropdown'
  }
}).on("hidden.bs.dropdown", ".dropdown", function() {
    // always reset after close
    $(this).removeClass("dropup");
});

$(document).ready(function() {
  //Fire filter function when selected funnel type
  $('#select-funnel-type').on('change', function(e) {
    FilterAllConditions();
  });

  $('#selectTag').on('change', function(e) { 
    FilterAllConditions();
  });

  $('.tabs-nav > ul > li > a').on('click', function() {
    if($(this).attr('href') == '#funnelLibrary') {
      $('#select-funnel-type').parent().find('ul.dropdown-menu > li:nth-child(3)').show();
    } else {
      $('#select-funnel-type').parent().find('ul.dropdown-menu > li:nth-child(3)').hide();
    }

  })
})